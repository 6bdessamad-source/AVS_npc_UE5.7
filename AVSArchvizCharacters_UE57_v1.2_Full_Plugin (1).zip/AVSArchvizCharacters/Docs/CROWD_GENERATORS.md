# Crowd Generators

## Mixed male/female pools

Generators select a Character Profile first. Their Animation Profiles array is then filtered by sex tag, Rig ID and exact target Skeleton. If no compatible animation exists, AVS logs the selected character instead of assigning a random incompatible profile.

For stricter authoring, use an `AVSCharacterLibrary` with one validated Character/Animation pair per row.

## Crowd Zone

Use `AAVSCrowdZone` for dispersed people.

- Resize Spawn Volume.
- Set NPC Count and profile pools.
- **AVS Idle Percentage Weight** controls the initial idle share. Lower it to make the crowd more active.
- Keep `Project To NavMesh` enabled for walkable placement.
- `Route Decision Chance` lets each person choose a contained path instead.
- Enable `Auto Discover Contained Routes`, or add weighted `Route Choices` manually.

## Closed-spline crowd surface

Use `AAVSSplineCrowdZone` when a rectangular volume does not fit the plaza, lobby, garden or terrace.

1. Edit **Surface Spline** as a closed top-down outline.
2. Set NPC Count and the character/animation pools.
3. Keep **Project To NavMesh** enabled.
4. Tune **Surface Sample Spacing** and **Max Spawn Attempts Per NPC** for complex outlines.
5. Use the same contained-route settings as a box zone.

Spline zones expose the same **AVS Idle Percentage Weight** control.

The sampled spline polygon controls spawn positions. The NavMesh still controls reachable walking. Use exclusion masks for holes such as pools, planters and restricted areas.

## Crowd Route and simple path

`AAVSCrowdRoute` supports two workflows:

1. **Generated walkers:** set NPC Count and profile pools. The generator spawns and pools the walkers.
2. **Placed NPCs:** set NPC Count to zero if generation is unwanted, add level NPCs to **Placed NPCs**, edit the spline and enable **Start Placed NPCs On Begin Play**.

Use `Assign NPC To Route`, `Remove NPC From Route` and `Start Placed NPCs` from Blueprint. A newly assigned NPC starts at its nearest sampled route point instead of returning to point zero.

`Route Point Spacing` controls AI targets, `Lane Half Width` is the usable lateral half-width and `Loop Route` controls whether the path repeats. The NPC retains its lateral offset while walking instead of converging back to the spline center.

### Path versus crowd-zone connector

**Route Purpose** is explicit:

- **Path Only**: generated or placed walkers use the spline; crowd zones do not auto-discover it as a connector.
- **Crowd-Zone Connector Only**: the route generates zero walkers and may be selected by every touched crowd zone.
- **Path + Crowd-Zone Connector**: both workflows remain active.

A connector may auto-discover several box/spline zones or use the manual **Connected Crowd Zones** list. Use an open, non-looping spline. A person enters at the nearest route sample, reaches the end, then is handed to the destination zone and resumes wandering. Use a second reversed connector for intentional two-way traffic.

### Couples

Enable **Couples** and tune:

- **Couple Chance**: deterministic chance per generated pair;
- **Couple Spacing**: side-to-side distance;
- **Minimum Route Width For Couples**: pairs are disabled if `Lane Half Width × 2` is narrower;
- **Couple Gender Mode**: Any, Same Sex or Different Sex.

Both people start at the same longitudinal route point with opposite lateral offsets. Same/Different Sex filtering uses each Character Profile's Sex and then selects a compatible Animation Profile for that body.

### Crossing routes and open ends

Enable **Auto Discover Route Connections** to connect sampled points on other `AVSCrowdRoute` actors inside **Connection Radius**. At a crossing, **Route Transfer Chance** decides whether the NPC continues or transfers. A transfer is allowed only if the destination route accepts that NPC's current Character/Animation pair. Use **Manual Connections** when an interchange must be exact or when two splines are visually near but should not connect.

For an exit route:

1. disable **Loop Route**;
2. enable **Despawn At End**;
3. optionally bind **On NPC Reached End** for doors, elevators or custom triggers.

Generated people return to the AVS pool at the last point. `Set Despawn At End` can toggle the option from Blueprint at runtime.

When a box or spline zone auto-discovers a Connector or Path + Connector route, each newly activated NPC independently decides whether to wander/idle or take it. **Connector Only** forces an effective NPC Count of zero automatically.

## Groups and following

Use `AAVSNPCGroup` for small groups. The first generated NPC can lead, or every member can follow an External Leader. Choose Side by Side, V Formation, Line or Circle. Spawn offsets and live Follow Actor offsets use the same formation calculation, so a group no longer reforms into an unrelated shape after it starts. Followers can suppress random idle activities and use lightweight RVO separation. For one character, call `Follow Actor` with a local offset.

## Points of interest

An `AAVSPointOfInterest` is a reservable activity destination. It can use its overlap-based automatic trigger, or a Blueprint/Behavior Tree can call `Use Point Of Interest` (or `Queue At Point Of Interest`) on a selected NPC.

Set capacity, queue spacing, activity slot, use duration, loop choice and facing behavior on the POI. On arrival the NPC plays the activity, optionally faces the POI, then automatically releases the reservation and returns to its previous Wander, Follow Route or Follow Actor behavior after a random duration. **Use Smart Missing Transition Fallback** lets the POI reuse a Start clip backward as End, or an End clip backward as Start, when the matching Animation Profile and row switches are also enabled.

When full, manual requests create an ordered queue. With **Auto Trigger Only When Completely Clear**, automatic passers ignore an occupied/clearing POI instead of joining it. Route and conversation users are ignored by the default automatic-trigger safety settings.

For each character Skeleton, the selected Animation Profile row supplies optional Start, main Activity/Loop and End assets; AVS returns to Idle after End. The editor preview has separate Idle, Start, Activity Loop and End fields and a Preview Phase selector.

## Editor visibility

NPCs, all generator types and POIs include editor-only billboard components. They are hidden in game and stripped from non-editor builds.
