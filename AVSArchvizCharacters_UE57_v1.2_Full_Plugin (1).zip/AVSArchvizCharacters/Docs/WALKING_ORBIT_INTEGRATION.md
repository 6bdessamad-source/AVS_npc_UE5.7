# Walking and Orbit Integration

## Direct integration with the supplied pawn

`UAVSArchvizCrowdComponent` reads `CurrentState` and `ORB_TargetZoom` through Unreal reflection. This keeps the plugin independent from the project module while matching the supplied `UnifiedArchvizCharacter` source.

In Walking mode:

- a generator activates when the camera enters its Walking Activation Radius;
- people continue to stream around the viewer as the pawn moves;
- Orbit zoom does not disable the crowd.

In Orbit mode:

- the bridge disables crowd simulation beyond its Deactivation Zoom;
- each generator also checks its Orbit Activation Radius and local zoom thresholds;
- separate activation and deactivation values provide hysteresis.

## Blueprint-driven alternative

Disable **Read Owner Properties** when property names differ. Call these nodes from the pawn:

- `Set Viewer Mode` after changing between Walking and Orbiting;
- `Set Orbit Zoom` whenever the orbit arm target changes;
- `Set Crowd Enabled` for cinematic or UI overrides.

The pawn's existing `OnCrossedInnerZoomThreshold` and `OnCrossedOuterZoomThreshold` Blueprint events can call `Set Crowd Enabled`, but this is optional when automatic property reading is active.

## Other ArchViz pawns

For another pawn, either use the three nodes above or expose compatible mode and zoom properties and enter their names in the component. The Runtime module never casts to a project class.
