# v1.2 — UE 5.7 compiler and linker fixes

This complete package retains the v1.10.0 animation, POI, crowd and lifecycle rework. Its requested display label is **1.2**; the monotonically increasing numeric descriptor revision is **18**.

## Changes from the delivered v1.10.0 source

| Reported diagnostic | Cause | Correction |
|---|---|---|
| C2027: undefined `UAVSNPCBehaviorComponent`; C2039: `SetBehaviorState` | `AVSCrowdGenerator.cpp` called a method while only the forward declaration was visible | Include `AVSNPCBehaviorComponent.h` directly |
| C2440: cannot construct `FPathFollowingRequestResult` from the enum | Controller used an unsupported enum-taking constructor | Default-construct the result and set its public `Code` to `Failed` |
| C4390: empty controlled statement | Additional diagnostic at the same invalid return branch | Replace the invalid expression and wrap the failure branch in braces |
| CS8981: engine lowercase type names | C# warnings in Unreal's ThirdParty build rules | No plugin or engine renaming; these were not the fatal errors in the supplied log |
| MSB3073 / Rebuild code -1 | Build command failed after the C++ errors above | Rebuild after installing the corrected source |
| Unresolved external `LogAVSArchvizCharacters`; Build code 6 | Editor uses the Runtime log category, whose existing definition was not exported from the Runtime DLL | Add `AVSARCHVIZCHARACTERS_API` to the public declaration and include `Logging/LogMacros.h` directly; retain the single existing Runtime definition |

Two plugin C++ files and the public module header change from v1.10.0. Reflected headers, Blueprint signatures, enum order, retargeting and animation policy are retained. The linker update changes only the module header compared with the first delivered v1.2 package; Editor already declares its Runtime module dependency.

## Install

1. Close Unreal Editor and Visual Studio.
2. Replace the whole `<Project>/Plugins/AVSArchvizCharacters` directory with the folder in this ZIP; remove the plugin's old `Binaries` and `Intermediate` directories when replacing it.
3. Regenerate the `.uproject` project files and build `AVS_labsEditor`, **Development Editor / Win64**.
4. Once the native build succeeds, run the [UE acceptance checklist](ACCEPTANCE_CHECKLIST.md) with the actual meshes, animation profiles and NavMesh.

The supplied compiler log completed UHT processing for the previous source but failed the native build. Subsequent feedback reported the unresolved Runtime log symbol during linking. Unreal is unavailable in the source-edit environment, so a successful compilation or DLL link of this corrected package is not claimed. Portable policy tests do not compile these Unreal C++ translation units. The [rework setup guide](V1_10_MIGRATION_AND_SETUP.md) still describes the retained features and controls.
