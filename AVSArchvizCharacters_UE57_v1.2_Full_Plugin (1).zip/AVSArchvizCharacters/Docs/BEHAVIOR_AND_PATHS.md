# Behavior, Controller, Paths and Activities

## Controller startup

`AAVSArchvizNPCAIController` has two behavior modes:

| Setup | Result |
|---|---|
| Behavior Tree Asset assigned and Run Behavior Tree On Possess enabled | Unreal runs that Behavior Tree |
| No tree, or tree startup fails, and fallback enabled | AVS starts wandering around the possession location |
| Both disabled | NPC waits for Blueprint or C++ commands |

A successfully running project Behavior Tree suppresses autonomous AVS decisions. Stop the tree and explicitly disable external ownership before handing decisions to the AVS state machine. The custom controller still gates MoveTo through compatible locomotion and completed activity exits. The Behavior Tree remains project-authored. Its Blueprint Tasks can call `Start Wandering`, `Follow Actor`, `Follow Route`, `Use Point Of Interest`, `Start Random Idle Activity` or `Set Behavior State` on the NPC's Behavior component.

## Built-in state machine

| State | Trigger and exit |
|---|---|
| Idle | Stops movement; may schedule an available weighted idle activity |
| Activity | Plays for its configured random duration, then returns to Idle |
| Wander | Periodically selects reachable NavMesh destinations in radius |
| Follow Actor | Repaths to the target plus local offset |
| Follow Route | Keeps a lane offset, advances through spline samples, skips masked destinations, can transfer at compatible route intersections, and loops/returns/despawns as configured |
| Queue | Follows the current index behind a full POI |
| At Point Of Interest | Moves to POI, plays its slot, then optionally auto-leaves |
| Conversation | Stops, faces the average position of its partners, plays a random Talk variant or Idle fallback, then pauses and returns to Wander |
| Paused / Inactive | Stops movement and waits for an explicit command |

Idle activities are only considered when the current Animation Profile contains their slot. Missing Phone, Texting or Stretch entries are skipped safely.

Movement requests are checked against every `AVSCrowdExclusionMask`. The default mask boundary is also Pawn-blocking and navigation-relevant, so an otherwise valid destination cannot route straight through a forbidden polygon.

Before any AI move, AVS prepares a compatible Walk animation. If none exists for the current body Skeleton, movement stops and a warning is logged. Stationary Idle/activity clips are not allowed to slide as a locomotion fallback.

## Points of interest

POIs may use their lightweight overlap trigger, or may be called from a Blueprint, timed manager, Behavior Tree task or custom selection rule:

1. get the AVS NPC's `Behavior` component;
2. call `Use Point Of Interest` with the target POI;
3. the POI reserves capacity, otherwise the NPC joins its ordered queue;
4. the NPC walks to the use transform, faces the configured direction and plays the configured slot;
5. after the randomized duration it releases the reservation and returns to the previous supported state.

Enable **Auto Trigger Only Idle Or Wandering** so route/follow/group walkers are not interrupted. Enable **Auto Trigger Only When Completely Clear** to ignore the POI while another person is using/queued for it and for the configured clearance time after release.

For runtime Start → Loop → End, configure the selected Animation Profile row. A missing End can reuse Start in reverse, a missing Start can reuse End in reverse, and a loop-only row simply loops. Enable the profile's **Smart Missing Transition Fallback**, the row's **Allow Reverse Transition Fallback**, and the POI's **Use Smart Missing Transition Fallback** to use this policy. After the real or inferred End, AVS returns to that profile's Idle.

POI navigation uses configurable distance/yaw tolerances, smooth yaw interpolation, arrival/alignment/queue timeouts and a vertical guard. It never snaps the capsule to the use transform. Entry waits for path stopping/braking. Reservations remain owned through the composed exit; cancellation, failed resolution, destruction and pool return release them.

Assign a **Preview Skeletal Mesh** and **Preview Animation Profile** for profile-driven full sequence preview, including contact hold and reversed segments. Clearly labeled compatible **Runtime Animation Overrides** merge over the profile row in runtime and preview. Legacy preview-only clips remain labeled pose inspection and never make runtime clips available. Use Refresh / Restart Preview after editing the referenced profile; Preview Exit / Get Up exercises graceful exit.

## Proximity conversations

The World Subsystem searches only at the Global Controller evaluation interval, at configurable global/zone cadence, with a spatial grid, vertical guard and rotating leader budget. Eligible Idle/Wander NPCs form groups of 2 up to **Max Conversation Group Size**, stop, turn toward one another and draw a compatible Idle/Talk category first (50% each by default), then weighted variants inside that category. Missing categories normalize; unchanged singleton draws keep playing without restart. Intervals vary, and every variant change waits for the current composed exit. Members have independent random durations, so larger groups disperse naturally; the final participant exits when no partner remains. Each member then idles briefly and resumes wandering.

Follow Route, Follow Actor, Queue, POI, Activity, Paused and Inactive NPCs are never selected. Occupied routes may also reserve a configurable clearance band, and route leavers receive a short re-engagement delay.

## Simple follow path

1. Place `AVSCrowdRoute`.
2. Edit Route Spline.
3. Place AVS NPC Characters.
4. Add them to **Placed NPCs**.
5. Enable **Start Placed NPCs On Begin Play**.
6. Build NavMesh and play.

The same route actor can also generate pooled walkers. Set NPC Count to zero when it should control only placed characters.

## Behavior Tree authoring recommendation

Keep expensive environment decisions in services or decorators and call the AVS component for movement modes. Unreal Behavior Trees are event-driven and use a Blackboard for shared decision data; see Epic's [Behavior Tree User Guide](https://dev.epicgames.com/documentation/unreal-engine/behavior-tree-in-unreal-engine---user-guide).
