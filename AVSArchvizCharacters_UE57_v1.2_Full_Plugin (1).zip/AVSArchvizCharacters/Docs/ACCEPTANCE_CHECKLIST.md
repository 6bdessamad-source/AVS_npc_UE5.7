# Version 1.2 Acceptance Checklist

This compiler-fix package retains the v1.10.0 rework. Rebuild the corrected source first using [the compiler-fix guide](V1_2_COMPILER_FIX.md); the supplied previous-source UHT/build log is not a successful build of this package.

Portable tests exercise production control logic, not engine integration. No Unreal installation was found in the execution environment, so none of the UE gates below has passed here.

## Available results

| Check actually run | Result |
|---|---|
| C++17 production composed policy | 102 assertions passed |
| C++17 production probabilities | 36 checks, 200000 deterministic trials; Idle100270/Talk99730 |
| AddressSanitizer/UndefinedBehaviorSanitizer | Both suites passed with detect_leaks=0; no LeakSanitizer coverage |
| Source metadata/include/diff/manifest/ZIP checks | Recorded in BUILD_AND_TEST_LOG.md; static only |

## Minimum UE 5.7 release gates

1. Back up the project, replace plugin, clear old plugin Binaries/Intermediate, regenerate and build the actual UE 5.7 Editor target. Confirm UHT plus both Runtime and Editor compile/link. Build a packaged Development target too.
2. Run editor automation `Automation RunTests AVS.`. Record output for `AVS.Animation.ComposedPolicy` and `AVS.POI.ReservationLifecycle` (added but never compiled/run here).
3. Use Tools → AVS → Validate Scene / Profiles. Fix mandatory positive-weight standing Idle/Walk, body/clip/ABP Skeleton mismatches, modular parts, missing or inactive Slots and unreachable POI positions. Confirm generated retarget profiles retain smart/reverse/hold and row controls; verify weighted head randomization remains.
4. With real male/female assets, exercise all eight matrix cases in Docs/V1_10_MIGRATION_AND_SETUP.md. Check selected hold positions 0/0.7/1, rate0.5/2, non-loop main, root-motion reverse rejection/explicit pose-only opt-in, notifies and held-pose cleanup.
5. Cancel/disable during Start, Hold/Loop and End. Reissue movement/POI commands repeatedly. Observe complete get-up before Walk/pathing, no restart of active exit, no active capsule teleport, safe compatible Idle on rejected clips and no reservation leaks.
6. Compare full POI runtime and profile-driven editor sequence preview (including overrides). Ensure preview-only legacy assets never make runtime playable. Test blocked paths, pending local tiles, unreachable use offsets, wrong-floor positions, smooth facing, braking, arrival/alignment/queue timeout, destruction, cancellation and pool return. Use separate Capacity1 POIs for different chairs.
7. Form groups of2–4 from eligible Idle/Wander agents. Measure category draw logs/distribution over enough choices; one Idle plus many Talk rows should select about50% Idle and50% all Talk combined. Observe randomized intervals, no repeated montage restarts, no route/follow/activity/POI/queue interruption, individual exits, cooldown and post-chat idle/wander. Test separate floors and vanished agents.
8. Check independent ambient weights and conversation percentage at0/50/100 with missing categories/zero-weight rows; check project/global-controller/box/spline precedence. Confirm zone initial idle percentage and route chance retain separate meanings.
9. Recycle agents from near/far custom tiers: body and modular tick/pause flags restore, old paths/groups/POIs/timers clear, placement remains hidden and invalid profiles remain hidden. Disable animation while moving/holding, drain exit safely, then upgrade quality and verify movement/animation resume together. Test tree ownership and pool brain restart.
10. Profile crowd counts representative of the real project. Observe path request/backoff frequency, rotating global budgets, single viewer invoker, local tile generation, occupied-route clearance and packaged runtime/editor separation. No performance budget was measured here.

Record the actual UE build version, project assets, automation output, PIE results and packaged platform. Historical v1.0.2 user-reported success does not validate v1.10.0.
