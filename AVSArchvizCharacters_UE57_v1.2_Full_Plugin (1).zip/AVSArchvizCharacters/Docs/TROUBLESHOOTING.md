# Troubleshooting

## Large map: no green NavMesh near the viewer

When **Enable Viewer Navigation Invoker** is active, verify all three requirements: a `NavMeshBoundsVolume` covers the current location, NavMesh Runtime Generation is **Dynamic**, and Navigation System → **Generate Navigation Only Around Navigation Invokers** is enabled. Press `P` in PIE; tiles should appear near the real camera location. Increase the controller's generation radius when generators activate beyond the green region.

If navigation surfaces disappeared after applying the channel filter, make the required floor/wall component Block **Navigation Geometry Channel**, re-enable **Can Ever Affect Navigation** on that component, and rebuild or restart PIE.

## Build.bat exits with code 6

Code 6 is only the final Unreal Build Tool failure code; the useful message is the first `error Cxxxx` or UnrealHeaderTool error above it in the Output window. Build from **Tools → Build → Build Solution**, open **View → Output**, select **Build**, and copy the first AVS source error with its file and line.

Visual Studio Error List can show `TIsContiguousContainer`, `TUEStaticAssertTypeCheckerBase` and “array size must be greater than zero” while it mis-parses Unreal macros. If those messages have no AVS file/line and do not occur in the Unreal Build output, clear the Error List filter or ignore them; they are normally cascade noise rather than the root failure.

## NPC does not move

- Add and build a `NavMeshBoundsVolume`.
- Confirm the controller possesses the character.
- For the built-in behavior, enable **Start Wandering Without Behavior Tree**.
- For a custom tree, confirm the controller's Behavior Tree Asset is assigned and the task calls an AVS Behavior function.
- Click **Validate And Log** on the NPC's Animation Profile. AVS requires at least one Walk row whose actual animation Skeleton equals the current body Skeleton.

## Female appears but remains static

- Confirm the female Character Profile Sex is Female and note its Body Mesh Skeleton.
- Confirm the female Animation Profile uses the same Target Skeleton.
- Validate the profile: every individual Idle/Walk/Start/End sequence must also use that Skeleton. A row with a name such as `A_ma_...` inside a female profile is not converted merely because the profile targets a female Skeleton.
- Retarget the source sequence in Unreal, replace the row with the generated female-Skeleton copy, then validate again.
- If no compatible Walk remains, AVS deliberately blocks movement instead of sliding an idle/push-up pose.

## Body floats above the capsule or faces sideways

Open the `AVSCharacterProfile`, then edit **Body → Capsule Alignment → Body Mesh Relative Transform**. Typical starting values are Z `-88` and Yaw `-90`. This is stored per body, so male and female meshes can use different alignment.

## No compatible Animation Profile warning

Check all three compatibility layers:

1. Character Sex versus Animation Compatible Sex;
2. Rig ID when both are set;
3. Character Body Skeleton versus Animation Target Skeleton.

`Unisex / Any` on the animation is compatible with all character sexes, but it never bypasses Skeleton matching.

## Parts are missing

- Check the part is Enabled.
- Check its Compatible Sex matches the Character Profile, or use Unisex/Any.
- Check Selection Weight is positive.
- Check whether a weighted No Part row was selected.
- Validate that the part shares the Body Skeleton.

## Parts are deformed or detached

Body and modular pieces must share a Skeleton and compatible reference hierarchy. Retargeting animation does not re-skin a modular mesh.

## Animation does not play

- Validate the Animation Profile.
- Assign Idle, Walk and Run to the exact Target Skeleton.
- Retarget any different-Skeleton source animation first.
- If a custom Animation Blueprint controls the body, disable `Drive Single Node Locomotion` and drive its variables in Blueprint.
- A Target Skeleton on the profile is a compatibility declaration, not runtime retargeting. Retarget wrong-Skeleton sequence assets first.

## NPC slides while playing a push-up or stationary idle

- Put the clip in Idle, Stretch or Custom—not Walk or Run.
- Put genuine moving clips in Walk/Run; root-motion clips are also recognized as movement-capable.
- Version 1.4 prepares Walk before each AI movement request and blocks movement if no compatible Walk exists.

## Placed NPC does not follow the spline

- Add it to the route's Placed NPCs array.
- Enable Start Placed NPCs On Begin Play or call Start Placed NPCs.
- Ensure the spline lies on built NavMesh.
- Set NPC Count to zero only if no generated walkers are wanted; it does not disable placed NPCs.

## Billboards are missing

Billboards are editor visualization components. Enable editor sprite visualization and confirm Engine Content is available. They are intentionally hidden in game.

## Crowd flickers at zoom threshold

Set Deactivation Zoom higher than Activation Zoom. A 100–500 unit gap is a useful starting point.
