# Global Controller and Exclusion Masks

## One controller per level

Place one `AVSCrowdGlobalController`. The most recently registered controller is used if several are present, so one authoritative actor is recommended.

Choose Cinematic, High, Balanced or Performance and click **Apply Selected Quality Preset**. Changing the enum alone does not overwrite edited fields. Choose Custom to keep your own values.

The controller owns:

- global on/off and density scale;
- maximum active NPCs and warm pool size;
- crowd evaluation interval;
- global shadow, collision and lightweight-avoidance permission;
- animation update-rate optimization;
- optional global draw-distance cap;
- distance tiers for tick rate, movement, animation, collision, visibility ticking and forced LOD.
- proximity-conversation radius, probability, size, duration, cooldown, facing and occupied-route clearance.
- one camera-following Navigation Invoker for local large-world tile generation;
- duplicate path-request suppression and an editor collision-channel filter.

`Get Active NPC Count`, `Get Pooled NPC Count`, `Set Global Crowd Enabled`, `Set Global Density Scale` and `Clear All Generated Crowds` are Blueprint-callable.

Conversation matching is centralized on the controller evaluation interval. Only Idle/Wander NPCs participate. A compatible looping **Talk** slot is used when available; otherwise the NPC holds a normal Idle. Keep the occupied-route guard enabled to avoid stopping pedestrians beside a route that still has users.

Conversation candidates are stored in a temporary spatial grid during each evaluation. Each person checks only its own and neighboring cells, avoiding an all-against-all crowd scan.

For a large map, enable **Viewer Navigation Invoker** and configure Unreal for invoker-only dynamic generation. AVS automatically creates one transient anchor at the real camera location and moves it only after **Navigation Invoker Move Threshold**. See [Large-world navigation](LARGE_WORLD_NAVIGATION.md).

## Universal exclusion masks

Place `AVSCrowdExclusionMask` around a forbidden region. Set **Shape** to **Spline** for a free-form closed polygon or **Box** for a simple oriented box whose extent can be edited directly. One mask affects every AVS crowd generator and behavior component in the world.

The two logical checks are independent:

- **Block Spawning** rejects generator spawn positions inside the polygon.
- **Block Movement Destinations** rejects wander, path, follow, POI and queue destinations inside it.

Keep **Build Collision Boundary** enabled when NPCs must also be unable to cross the polygon while moving to a legal destination on its other side. The actor samples the spline into invisible Pawn-blocking box segments. **Affect Navigation** makes those segments participate in navigation updates. Rebuild navigation after changing static masks.

For Spline shape, use Min/Max Height Offset to keep a mask scoped to the intended floor in multi-storey scenes. Decrease Boundary Sample Spacing for tighter curves at the cost of more components. For Box shape, the Box component's three-dimensional extent defines both logical containment and its optional Pawn/navigation collision.

## Lightweight crowd avoidance

Each AVS NPC enables Character Movement RVO with configurable **Avoidance Consideration Radius** and **Avoidance Weight**. It provides local separation without running pairwise Blueprint traces. The Global Controller can disable it, and every quality tier has **Enable Avoidance**; far tiers and the Performance preset disable it automatically. Keep collision and avoidance enabled only for the near/medium ranges where viewers can see contact quality.

## Typical ArchViz layout

- One Global Controller near the level origin.
- Box zones for rectangular rooms.
- Spline zones for irregular plazas and gardens.
- Route actors through selected zones, with route NPC Count set to zero when used only as optional paths.
- Exclusion masks around water, roads, counters, exhibits and private rooms.
- A NavMesh Bounds Volume covering every legal pedestrian surface.
