# Character Profiles and Random Modular Parts

`UAVSCharacterProfile` defines one body family. Its Body Mesh drives skinned parts through Leader Pose.

## Identity and compatibility

| Field | Purpose |
|---|---|
| Sex | Male, Female, Unisex/Any or Custom selection boundary |
| Rig ID | Optional readable family key used in addition to exact Skeleton matching |
| Body Mesh | The leader Skeletal Mesh |
| Body Mesh Relative Transform | Body alignment below the Character capsule; commonly Z -88 and Yaw -90 |
| Require Same Skeleton | Rejects incompatible skinned parts; keep enabled |

Sex tags do not alter geometry. They prevent an item or animation marked Female from being automatically selected for a Male profile, and vice versa. `Unisex / Any` is explicitly compatible with every character.

## Capsule alignment

The setting formerly adjusted directly on a Blueprint Mesh component now lives in each Character Profile at **Body → Capsule Alignment → Body Mesh Relative Transform**. Start with Location `(0, 0, -88)` and Rotation `(0, -90, 0)` for a typical Unreal humanoid. If a body floats above the capsule like the supplied female example, lower the Z value; if it faces sideways, correct Yaw. All modular parts follow the body leader pose, so adjust the body only.

## Weighted random clothing

Each Modular Parts row has:

- Slot;
- Compatible Sex;
- Enabled;
- Selection Weight;
- optional **No Part**;
- Skeletal Mesh and material overrides.

Add multiple compatible rows with the same Slot. When **Randomize Modular Parts** is enabled, AVS selects one weighted row per slot. A **No Part** row makes hats, hair, glasses or accessories optional. The seed is repeatable; `Random Seed Offset` on the component can vary instances.

Call `Randomize Modular Parts` on the NPC's `ModularCharacter` component at runtime or with Call In Editor.

## Skeleton rule

Body and modular skinned pieces must use the same Skeleton asset and compatible bone hierarchy. Animation retargeting does not re-skin clothing. AVS rejects incompatible parts and logs the slot rather than showing a broken pose.

## Props

Right and left props are Static Meshes attached to an exact body socket such as `hand_r_socket`. Adjust Relative Transform in the profile.

## Runtime changes

Call `Apply Profiles` on the AVS NPC when changing both appearance and animation. It validates sex, Rig ID and target Skeleton before applying. Call `Apply Profile` on the modular component only when changing appearance without animation.

## Character Library

`UAVSCharacterLibrary` stores already-compatible Character/Animation pairs plus selection weight. Invalid pairs are ignored during selection and reported by validation.
