# Large-World Navigation

## Recommended architecture

Do not spawn and resize `NavMeshBoundsVolume` actors while the experience is running. Keep one large bounds volume over every possible pedestrian region, but generate tiles only around the current viewer with Unreal Navigation Invokers.

AVS creates one transient invoker anchor automatically. It follows the real camera location rather than blindly following the Pawn origin, so it also works when an Orbit camera is offset from the character. The anchor moves only after the configured threshold and is updated on the existing Global Controller evaluation interval; it does not tick every frame.

## Required Unreal settings

1. Place one `NavMeshBoundsVolume` covering every place where a pedestrian may eventually walk.
2. Open **Project Settings → Navigation Mesh → Runtime** and set **Runtime Generation** to **Dynamic**.
3. Open **Project Settings → Navigation System** and enable **Generate Navigation Only Around Navigation Invokers**.
4. Place one `AVSCrowdGlobalController`.
5. Enable **Navigation → Local Generation → Enable Viewer Navigation Invoker**.
6. Start with Walking Generation Radius `12000`, Orbit Generation Radius `32000`, Removal Padding `4000`, and Move Threshold `500`.

Those defaults intentionally exceed the default generator activation radii. If a generator activates farther away than the generated navigation radius, either reduce its activation radius or increase the corresponding navigation generation radius.

When the crowd or viewer bridge is disabled, AVS destroys its transient invoker and Unreal can remove tiles outside every remaining invoker's removal radius.

## Collision-channel filtering

Recast NavMesh does not expose one universal "collision trace channel" switch. AVS therefore supplies a safe one-time editor filter:

1. In **Project Settings → Collision**, create a Trace Channel such as `AVSNavigationGeometry`.
2. Set floors, stairs, ramps, walls and required obstacles to **Block** that channel.
3. Set decoration, vegetation, glass, furniture, cars and irrelevant detail to **Ignore**.
4. Select the Global Controller and choose that channel under **Navigation Geometry Channel**.
5. Click **Apply Navigation Collision Channel Filter**.

The button scans placed primitive components once and disables **Can Ever Affect Navigation** on components that do not Block the selected channel. Explicit Unreal volumes and AVS Exclusion Masks are skipped, so their own navigation settings remain authoritative. The filter never enables navigation on a component, so intentionally disabled components stay disabled. Use Undo immediately if the result is not intended; otherwise individual components can be re-enabled manually.

AVS NPC capsules, body meshes, modular body parts and hand props are always navigation-irrelevant. They use RVO/collision for local separation instead of forcing navigation tile rebuilds.

## Runtime path-request optimization

The Global Controller suppresses identical `MoveTo` requests for a configurable interval. A request is still sent immediately when an NPC changes route point or a Follow target moves beyond **Path Destination Change Threshold**.

Quality presets configure this automatically:

| Preset | Minimum repeated-path interval | Destination-change threshold |
|---|---:|---:|
| Cinematic | 0.75 s | 75 cm |
| High | 1.0 s | 100 cm |
| Balanced | 1.5 s | 150 cm |
| Performance | 2.5 s | 250 cm |

Proximity-conversation searches use a spatial grid, so eligible NPCs compare only with people in their current and neighboring cells rather than scanning the whole crowd against every NPC.

## Debugging

- Press `P` to display generated navigation.
- In PIE, green tiles should exist only near the current camera/viewer.
- If no tiles appear, confirm the two Project Settings above and verify that the invoker is inside the large bounds volume.
- If a crowd zone activates outside the green area, increase the AVS generation radius or reduce that generator's activation radius.
- If important floors disappear after channel filtering, make those components Block the chosen channel and re-enable **Can Ever Affect Navigation** before rebuilding.
