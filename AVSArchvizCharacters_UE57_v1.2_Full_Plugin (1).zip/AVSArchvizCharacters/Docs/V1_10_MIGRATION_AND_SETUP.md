# v1.10 migration and setup

Version 1.10.0 preserves existing public classes, Blueprint command signatures, property names, enum order and profile arrays. Back up your project, replace the entire plugin directory, delete its old Binaries/Intermediate, regenerate project files, and build your UE 5.7 Editor target. No generated assets are included.

## Start with a small test scene

1. Use one body and one target-specific Animation Profile with positive-weight, compatible standing Idle and Walk rows. Keep contact activities out of Idle/Walk/Run. Run **Tools → AVS → Validate Scene / Profiles**; inspect actionable Output Log diagnostics.
2. Place/build a NavMeshBoundsVolume. Local navigation still requires Dynamic generation and Generate Navigation Only Around Navigation Invokers; the AVS camera invoker is centralized. Start with Desired Walk Speed 125 cm/s, Acceleration 160, Deceleration 220. Check actual feet at your authored reference speed.
3. Assign sit/lean clips to a Custom row and its matching name. Enable profile Smart Missing Transition Fallback, Reverse Transition Fallback and Hold Pose Fallback as needed, then row permissions. Start-only/End-only rows now work without a fabricated loop asset.
4. Place a POI with a navigation-reachable Use Transform. AVS walks to its distance/height tolerance and smoothly faces its yaw; it never snaps the capsule into furniture. Tune arrival, alignment and queue timeouts. A failed clip/path exits safely and releases its reservation.
5. Set **Preview Skeletal Mesh** and **Preview Animation Profile** on the POI. Use the resolved sequence preview to inspect the same start/hold/loop/exit as runtime. Runtime override fields are explicitly labeled and Skeleton-filtered. Legacy editor-only clips are labeled **pose-only**, and cannot make a runtime activity valid.
6. Try a male and female body/profile pair separately; each clip, including transitions and runtime overrides, must match its body Skeleton exactly. Retarget generated profiles copy all new settings and row flags. Modular head randomization remains unchanged.

## Limited animation matrix

| Compatible clips | Smart policy |
|---|---|
| Start + Loop + End | Start, timed Loop, End |
| Start + Loop | Start, timed Loop, reverse Start |
| Loop + End | Reverse End, timed Loop, End |
| Loop only | Timed Loop |
| Start only | Start to contact, timed hold, reverse only the traversed segment |
| End only | Reverse End to contact, timed hold, forward to the standing end |
| Start + End without Loop | Start to contact, timed hold, supplied End |
| None | Reject; return to compatible standing Idle and release reservation |

**Hold Pose Normalized Position** `-1` means final Start frame or first End frame. Other values clamp to 0–1; for example `0.7` traverses/holds 70% of Start, then reverses exactly that 70%. Duration measures the use body after entry; playback rates and traversal lengths determine transition time. Reverse and hold can be disabled independently on profile, row and POI. A transition-only row with no permitted safe exit is rejected. A non-loop effective main plays once then retains its final pose until its use duration/exit. POI Loop Activity and configured Idle Activities Loop explicitly override profile bLoop; synthesized ambient choices and conversations preserve it.

Composed activities and previews sample in-place clip positions deterministically. They do not set global animation pause flags and do not extract root-motion translation. Reversed root-motion clips are rejected by default; **Allow Reverse Root Motion** opts into pose sampling only, after visual validation. Reverse notifies are suppressed by default; **Allow Reverse Notifies** permits sampled notify traversal and requires project-specific checking. These controls cannot guarantee props, cloth, contact poses or gameplay notifies are suitable in reverse. Supplied different exits wait for entry contact on cancellation; inferred exits reverse the current traversed position. Repeated commands cannot restart an exit or bypass its movement gate.

Locomotion retains dynamic montage blending when the actual configured Animation Blueprint has the named compiled Slot. Otherwise it uses single-node playback and optional locomotion transition clips. A Slot's output must still be connected and active in your authored graph; Validate Scene reports missing Slot nodes but real graph/asset playback is a UE acceptance gate.

## Ambient settings examples

Project Settings → AVS supplies defaults. A Global Controller can explicitly override the new ambient/conversation structs, and box/spline zones can override them locally. Existing Global Controller social controls retain their authority until the new override is enabled.

Activity category weights choose **normal Idle / Smoking / Stretching / Custom** first, then compatible configured rows within the selected category. Missing categories and zero weights are excluded; available weights normalize. Idle Activities remain the variant/duration library; Custom covers other configured activity slots too. These weights are independent of initial zone Idle Percentage Weight, route decisions and conversation formation.

| Example | Idle | Smoking | Stretching | Custom | Conversation formation |
|---|---:|---:|---:|---:|---:|
| Quiet lobby | 80 | 0 | 10 | 10 | 10% |
| Social courtyard | 50 | 15 | 15 | 20 | 35% |
| No ambient actions | 100 | 0 | 0 | 0 | 0% |

Conversations draw **50% compatible standing Idle / 50% all compatible Talk variants combined** by default. Category selection occurs before weighted variants; adding ten Talk rows does not multiply the Talk probability. Missing categories normalize. Immediate variant repeats are avoided when that category has alternatives; a sole unchanged Idle remains playing without a restart. Intervals and each member's overall duration vary. Only eligible Idle/Wander agents participate, within a vertical tolerance; route/follow/queue/POI/activity agents retain ownership. Members complete exits, idle briefly and wander away individually.

## Migration differences to review

- Selection Weight 0 now disables a row; it no longer becomes a uniform fallback when all rows have weight 0. Give mandatory Idle/Walk rows positive finite weights.
- Start-only and End-only now mean literally no main clip; the old documentation's “Start-only” meant a missing transition partner while a main existed. New smart hold resolves the literal transition-only case.
- POI runtime clips come from its runtime profile row or clearly labeled compatible runtime overrides. Editor-only preview clips remain pose-only.
- Activity exits own movement. State changes can be deferred until exit completion, so Blueprint code should listen for state changes rather than assume a command always takes effect in the same frame.
- A running project Behavior Tree suppresses autonomous AVS decisions; its AI MoveTo still uses the animation safety gate. Use one owner for movement. For project-authored AVS behavior tasks, disable external ownership explicitly and stop the tree before handing ownership back.
- Failed pooled spawns stay hidden and are rejected by the subsystem. Pool reactivation restores mesh/part ticks, movement mode, montage state and quality defaults before visibility.

Run the [acceptance checklist](ACCEPTANCE_CHECKLIST.md) before deploying this source release. UHT, UE 5.7 compilation, editor preview, PIE, real assets and packaging have not run in the source-work environment.
