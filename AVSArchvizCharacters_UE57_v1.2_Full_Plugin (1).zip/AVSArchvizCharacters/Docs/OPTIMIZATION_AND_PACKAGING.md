# Optimization and Packaged Builds

## Pooling

`UAVSCrowdSubsystem` owns active and pooled plugin NPCs. Deactivated generators release NPCs; later generators reuse compatible classes. `Warm Pool Size` limits retained inactive actors and `Max Active NPCs` provides a global cap.

## Quality tiers

Project Settings → Plugins → AVS ArchViz Characters contains fallback distance tiers. A placed `AVSCrowdGlobalController` overrides them per level and offers Cinematic, High, Balanced and Performance presets. Each tier controls:

- component tick interval;
- movement updates;
- animation updates;
- skeletal and modular-part shadows;
- collision;
- lightweight RVO avoidance;
- animation update-rate optimization and visibility-based ticking;
- forced skeletal LOD;
- maximum draw distance.

Keep tiers ordered from nearest to farthest. The final tier is used beyond every listed distance.

RVO is enabled only when the NPC setting, the chosen quality tier and the Global Controller permission all allow it. Balanced/High keep avoidance where interaction is visible and disable it in the far tier; Performance disables it globally. Route connection discovery runs when routes begin play or when manually refreshed, not every frame.

AVS NPC collision, body meshes, modular pieces and props do not affect navigation generation. The Global Controller also suppresses repeated path requests to nearly identical destinations; the interval and movement threshold are preset-aware. Conversation matching uses a local spatial grid rather than comparing every eligible NPC with the full crowd.

For maps where one static NavMesh would be too large, use the controller-managed local invoker described in [Large-world navigation](LARGE_WORLD_NAVIGATION.md). One large bounds volume defines where navigation is allowed, while only tiles near the current viewer are generated and retained.

## Suggested ArchViz presets

| Preset | Active cap | Near | Medium | Far |
|---|---:|---:|---:|---:|
| Desktop cinematic | 120 | 4,000 | 10,000 | 20,000 |
| Pixel Streaming | 70 | 3,000 | 7,000 | 14,000 |
| VR | 40 | 2,500 | 6,000 | 10,000 |

Tune the values from the measured project, skeletal complexity and animation cost.

## Packaging

The Runtime module has no dependency on the Editor module or the original game module. Character and Animation Profiles referenced by placed generators are cooked normally. Soft-referenced meshes and animations in those Data Assets are loaded when an NPC is activated.

Before packaging:

1. validate every profile;
2. verify referenced assets are inside the project Content folder;
3. for static navigation, build persistent-level navigation; for local invoker navigation, verify Dynamic + Generate Only Around Invokers and test tile appearance in PIE;
4. test Walking and Orbit transitions in Standalone Game;
5. package Development once before Shipping so missing cooked references remain visible in logs.
