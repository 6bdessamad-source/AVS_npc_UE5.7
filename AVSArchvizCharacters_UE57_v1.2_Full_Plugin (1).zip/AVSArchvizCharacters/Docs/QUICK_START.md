# Quick Start

## 1. Connect the ArchViz pawn

Open the player Pawn Blueprint and add **AVS ArchViz Crowd Bridge**. The player can be first-person, third-person or custom; `UnifiedArchvizCharacter` is optional.

If the pawn exposes `CurrentState` and `ORB_TargetZoom`, leave **Read Owner Properties** enabled and configure the reflected names. Otherwise disable it and set Viewer Mode, Orbit Zoom and Crowd Enabled from Blueprint.

Use different activation/deactivation zoom values, for example `1950` and `2050`, to prevent threshold flicker.

## 2. Create male and female Character Profiles

Create **Miscellaneous → Data Asset → AVSCharacterProfile** for each body.

For every profile:

1. Set **Sex** to Male, Female, Unisex/Any or Custom.
2. Set an optional **Rig ID**, for example `AVS_Male_A`.
3. Assign **Body Mesh**.
4. Set **Body → Capsule Alignment → Body Mesh Relative Transform**. For many Unreal humanoids start with Location Z `-88` and Rotation Yaw `-90`; adjust once per body profile if the feet do not meet the capsule floor.
5. Add modular choices. Every row has a Slot, Compatible Sex, Weight and mesh.
6. Add several rows with the same Slot to randomize clothes.
7. Add a weighted **No Part** row for optional hats, glasses or accessories.
8. Keep **Require Same Skeleton** enabled.
9. Use **Randomize Modular Parts** on the NPC component to preview another combination.

## 3. Create target-specific Animation Profiles

Create one `AVSAnimationProfile` per target Skeleton and sex/rig family.

1. Set **Compatible Sex**.
2. Use the same **Rig ID** as the matching Character Profile.
3. Assign the body's exact **Target Skeleton**.
4. Add Idle and Walk rows at minimum; add Run and activities as needed. Movement is intentionally blocked when no compatible Walk exists.
5. Add more than one row with the same slot to create weighted, non-repeating variants.
6. Fill **Start Animation** / **End Animation** as available. Smart fallback supplies a reversed missing transition around a configured main. Literal Start-only or End-only activities can hold a selected contact pose without a main, then retrace to standing. Enable Hold Pose Fallback and safe reverse permissions, or supply a real exit. See [v1.10 setup](V1_10_MIGRATION_AND_SETUP.md) for the complete matrix.
7. Set transition blend times. For true cross-fades, assign an Animation Blueprint containing a Slot node named like **Montage Slot Name** (default `DefaultSlot`).
8. Optionally add Walk Start/Stop and Run Start/Stop rows as a second locomotion fallback.
9. Under **Locomotion → Movement Match**, start with Desired Walk Speed `125`, Acceleration `160`, Deceleration `220`, and enable speed-matched play rate. On each Walk row, set Authored Ground Speed to the speed where its feet look planted, or leave zero to use the profile reference.
10. Keep PushUp, SitUp and similar activities out of the Idle slot. Use Custom names and add them to the NPC Behavior component's Idle Activities list.
11. Run **Validate And Log** on every Animation Profile and on the Character Library.

If an animation uses a different Skeleton, retarget it first. See [Animation compatibility and retargeting](ANIMATION_AND_RETARGETING.md).

## 4. Configure the AI Controller

Create a Blueprint subclass of `AVSArchvizNPCAIController`.

- Optional: assign an Unreal **Behavior Tree Asset**.
- Or leave it empty and keep **Start Wandering Without Behavior Tree** enabled.
- To centralize setup, enable **Auto Select Compatible Profiles On Possess**, then add all male/female Character Profiles and all Animation Profiles to the two arrays.
- Set the NPC Blueprint's **AI Controller Class** to this controller.

The controller chooses a character first and then filters the mixed animation list. Sex, Rig ID and exact Skeleton must be compatible.

## 5. Add people

- Dispersed crowd: place `AVSCrowdZone`.
- Free-form crowd surface: place `AVSSplineCrowdZone` and close/edit its spline around the spawn area.
- Generated spline crowd: place `AVSCrowdRoute`, assign pools and set NPC Count.
- Simple placed path: place individual AVS NPCs, add them to the route's **Placed NPCs** array, edit the spline and enable **Start Placed NPCs On Begin Play**.

For a zone that sometimes feeds a path, put an `AVSCrowdRoute` through the box/spline zone, set the route's NPC Count to zero if it should not generate its own people, enable **Auto Discover Contained Routes**, and tune **Route Decision Chance**. Non-looping route walkers return to zone wandering.

Use **AVS Idle Percentage Weight** on each box/spline zone to control the initial stationary share. `0` means everybody starts wandering; `10` means roughly ten percent start idle.

For a route linking several crowd zones, set **Route Purpose** to **Crowd-Zone Connector Only** or **Path + Crowd-Zone Connector**, disable **Loop Route**, and let **Auto Discover Connected Crowd Zones** find every touched zone. Connector Only generates no route-owned walkers. At the open end, the walker is handed to the destination zone and continues wandering there.

On a route, use **Couples** to enable side-by-side pairs when `Lane Half Width × 2` is large enough. Use **Network** to discover crossing routes and transfer compatible NPCs. For a one-way exit, disable **Loop Route**, enable **Despawn At End**, and optionally bind **On NPC Reached End**.

## 6. Add global control and masks

Place one `AVSCrowdGlobalController`, choose a preset and click **Apply Selected Quality Preset**. It controls global density, active/pool limits, evaluation interval, collision, shadows, animation update optimization, LOD and draw distance.

Under **Social Conversations**, enable proximity conversations and tune radius, start chance, group size, duration, cooldown and post-chat idle time. Add one or more looping **Talk** rows to every target-specific Animation Profile. Missing Talk safely falls back to Idle. Keep **Wait For Occupied Routes Before Conversation** enabled so people using or clearing a route are not interrupted.

Place `AVSCrowdExclusionMask` actors around pools, roads, furniture or private areas. Choose **Shape = Spline** for a polygon or **Shape = Box** for a fast resizable volume. By default AVS rejects spawn and movement destinations inside it and builds an invisible Pawn-blocking, navigation-relevant boundary.

For a normal-sized level, add and build a `NavMeshBoundsVolume`, then Play In Editor.

For a very large map, keep one large bounds volume but avoid generating all of it: set NavMesh Runtime Generation to **Dynamic**, enable **Generate Navigation Only Around Navigation Invokers**, then enable **Viewer Navigation Invoker** on the Global Controller. AVS creates one local tile-generation anchor at the real camera location. See [Large-world navigation](LARGE_WORLD_NAVIGATION.md).


For limited-animation POIs, normalized ambient category weights, independent formation percentages and matched runtime preview, follow [v1.10 migration and setup](V1_10_MIGRATION_AND_SETUP.md).
