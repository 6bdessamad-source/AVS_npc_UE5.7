# Animation Compatibility and Retargeting

## What is automatic

AVS automatically:

1. selects a Character Profile;
2. filters the mixed animation pool by Compatible Sex;
3. filters by Rig ID when both sides provide one;
4. requires the Animation Profile Target Skeleton to equal the body's Skeleton;
5. rejects a wrong-Skeleton animation again immediately before playback.
6. removes wrong-Skeleton rows from weighted variant selection, even if another row in the same profile is valid;
7. refuses AI movement when the current body has no compatible Walk row, preventing a stationary pose from sliding across the floor.

This means one controller or generator can hold male and female profiles together without randomly crossing incompatible animation sets.

## What requires one-time rig setup

Unreal cannot infer every imported character's intended chains, retarget pose, twist bones and proportions safely from a mesh alone. For each source/target Skeleton pair:

1. enable Unreal's **IK Rig** plugin;
2. create source and target IK Rig assets;
3. set retarget roots and verify corresponding limb/spine chains;
4. create an IK Retargeter;
5. correct the target retarget pose;
6. preview Idle, Walk, Run and contact-heavy activities;
7. export retargeted animation copies to a target-specific folder;
8. create an AVS Animation Profile for that target Skeleton and add the copies one by one.

After this one-time setup, AVS selection is automatic. It never silently plays the source animation on an incompatible body.

AVS does not create or repair an IK Retargeter at runtime. “Automatic” here means automatic selection and playback of copies that were already retargeted to the target Skeleton. Runtime auto-rigging arbitrary assets would be less reliable and more expensive for an ArchViz crowd.

Epic references:

- [IK Rig Animation Retargeting](https://dev.epicgames.com/documentation/unreal-engine/ik-rig-animation-retargeting-in-unreal-engine)
- [Runtime IK Retargeting](https://dev.epicgames.com/documentation/unreal-engine/runtime-ik-retargeting-in-unreal-engine)

Runtime retargeting through `Retarget Pose From Mesh` is possible, but it requires a source mesh, a target Animation Blueprint and an IK Retargeter. For optimized ArchViz crowds, exported target animations are normally cheaper and easier to validate.

## Animation slots

Enter each asset manually in `UAVSAnimationProfile`:

- locomotion: Idle, Walk, Run;
- optional transition clips: Walk Start, Walk Stop, Run Start, Run Stop;
- activities: Talk, Phone Start/Loop/End, Texting, Drink, Smoke, Stretch;
- named project actions: Custom plus Custom Name.

The default driver selects locomotion from horizontal speed. Speed hysteresis prevents rapid Idle/Walk/Run switching near a threshold. `Play Animation Slot` temporarily overrides locomotion; `Resume Locomotion` returns to speed-based playback.

AI movement is allowed only when a compatible Walk exists. During playback an animation is movement-capable when its row is a Walk/Run/locomotion-transition slot and a compatible sequence is actually active. An Idle, Stretch, Phone or Custom stationary row is never used as a locomotion substitute. Before any stationary composed row can move, AVS plays its End clip completely, then starts Walk, then releases the pending AI move.

Do not author phone, push-up and sit-up rows as ordinary **Idle** variants. Use their dedicated slot when available, or **Custom** with names such as `PushUp` and `SitUp`, then add those same slot/name pairs to the NPC Behavior component's **Idle Activities** list. Keep the Idle slot for standing neutral variations.

## Smooth transitions and variants

Every row has a **Selection Weight**. Add several rows with the same Slot and Custom Name to create a variant set. AVS chooses weighted variants and avoids immediately repeating the last choice when another choice is available. Idle variants rotate after a random duration set by **Idle Variant Min/Max Time**.

## Walking speed and foot matching

The Animation Profile's **Locomotion → Movement Match** section controls physical movement and playback together:

- **Desired Walk Speed** is the AI capsule's maximum walking speed; `125 cm/s` is a relaxed ArchViz pace;
- **Movement Acceleration / Deceleration** make starts and stops gradual;
- **Use Acceleration For Paths** prevents AI path following from assigning full velocity immediately;
- **Match Locomotion Play Rate To Speed** adjusts Walk/Run playback from actual horizontal velocity;
- each Walk/Run row can set **Authored Ground Speed**; zero uses the profile fallback reference speed.

For a Walk animation that looks correct at `110 cm/s`, set its Authored Ground Speed to `110`, set Desired Walk Speed near `110`, and keep row Play Rate at `1.0`. During acceleration AVS interpolates the live play rate from the character's real speed, clamped by the profile Min/Max Dynamic Locomotion Play Rate.

Every row also supports a composed sequence:

| Field | Purpose |
|---|---|
| Start Animation | Optional one-shot preparation, such as phone pickup, sit down or walk start |
| Animation | Main pose/loop; optional for transition-only contact holds |
| End Animation | Optional one-shot exit, such as phone put-away, stand up or walk stop |
| Allow Reverse Transition Fallback | Allows this row to reuse its only transition backward when its partner is missing |
| Allow Hold Pose Fallback / Hold Pose Normalized Position | Timed contact hold when no main exists; -1 selects final Start/first End frame |

The profile-level **Enable Smart Missing Transition Fallback** is the master switch. With it enabled, the driver resolves each row as follows:

| Assets supplied | Playback |
|---|---|
| Start + main + End | Start forward → main → End forward |
| Start + main | Start forward → main → Start reversed |
| Main + End | End reversed → main → End forward |
| Main only | Main only; no artificial transition |
| Start only, hold permitted | Start to selected contact → hold → reverse traversed Start segment |
| End only, hold permitted | Reverse End to contact → hold → forward to standing end |
| Start + End, no main, hold permitted | Start to contact → hold → supplied End |
| None compatible | Reject, release activity state, compatible standing Idle |

This applies to normal activities, Talk/custom rows and POI activities because they all use the same animation driver. Start and End must use the same Target Skeleton and the row's Play Rate. For activities and POIs, the body duration starts after entry and controls when the exit begins. Holds and partial traversal are resolved by one production policy shared with preview. For locomotion, velocity/state changes control it.

Reverse fallback is intended for in-place clips such as picking up/putting down a phone or sitting/standing. Disable **Allow Reverse Transition Fallback** on a row when the reversed clip has unwanted root displacement, directional notifies, asymmetric prop handling or visible cloth problems. Turning off the profile master switch restores explicit-only Start/End behavior for every row in that profile.

For real animation cross-fades:

1. assign an Animation Blueprint in the Character Profile;
2. add a Slot node to its Anim Graph (normally `DefaultSlot`) on the output path;
3. set the same name in the Animation Profile's **Montage Slot Name**;
4. tune **Blend In Time** and **Blend Out Time**.

AVS plays locomotion sequences as dynamic montages only when that configured Slot exists in the compiled Animation Blueprint. Composed activities use deterministic in-place pose sampling for exact contact holds and partial reversals; they do not extract root-motion translation. Reversed root-motion clips require explicit row opt-in and reverse notifies are disabled by default. See [v1.10 migration](V1_10_MIGRATION_AND_SETUP.md) for permissions and cancellation details. Without an Animation Blueprint/Slot, Unreal's single-node player cannot cross-fade two arbitrary sequences. In that setup AVS can play the optional Start/Stop clips before changing locomotion, but the final sequence switch is still single-node playback.

## Female spawns but remains static

This means the Character Profile was accepted but no playable row matched the female body's exact Skeleton. In the supplied setup, the Female Animation Profile targets `SKEL_CitizenNPC_fe`, while at least one row named `A_ma_ThirdPersonWalk` strongly indicates a male-Skeleton source. A correct profile-level Target Skeleton does not convert the individual sequence.

1. Open the female Animation Profile and click **Validate And Log**.
2. Retarget every reported row—including Start and End assets—to `SKEL_CitizenNPC_fe`.
3. Replace the source rows with those female-Skeleton copies.
4. Ensure at least one compatible Idle and one compatible Walk row remain.
5. Validate the Character Library too; it now includes the detailed animation-row validation.

Invalid rows are skipped rather than chosen randomly. If no valid Walk remains, AVS keeps the NPC still on purpose and logs that movement was blocked.
