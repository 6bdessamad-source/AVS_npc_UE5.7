# Tests

Run `python3 Tests/run_portable_tests.py` from any directory with a C++17 compiler (`CXX` overrides the compiler).

- `composed_policy.cpp` exercises the actual production resolver and state machine used by runtime and editor preview: the full clip matrix, independent fallback permissions, partial positions/rates, non-loop main, cancellation during entry/hold/end, repeated requests, missing clips, safe movement gates and reset/reactivation. 102 assertions passed on 2026-10-01.
- `social_probability.cpp` exercises the production probability helper used by behavior and subsystem: availability normalization, percentages 0/50/100, invalid inputs, weighted rows and the independent category draw. 36 checks and 200,000 deterministic trials passed; Idle=100270, Talk=99730.

Both also passed g++ address/undefined sanitizers with `ASAN_OPTIONS=detect_leaks=0`. LeakSanitizer could not run in the managed execution environment, so no leak-coverage claim is made.

UE automation sources are registered as `AVS.Animation.ComposedPolicy` and `AVS.POI.ReservationLifecycle`. Compile the UE 5.7 Editor target and run `Automation RunTests AVS.` in the editor/automation commandlet. The second test uses a transient world to check POI capacity, idempotent reservations/queues, destroyed users, hidden pool entries and reactivation. Neither UE test was compiled or run here because Unreal is absent.

These portable tests validate production control/probability logic, not Unreal asset playback, root-motion/notifies, navigation, rendered graph Slots, async animation evaluation, UHT, or packaged runtime behavior. Complete Docs/ACCEPTANCE_CHECKLIST.md with real project assets.
