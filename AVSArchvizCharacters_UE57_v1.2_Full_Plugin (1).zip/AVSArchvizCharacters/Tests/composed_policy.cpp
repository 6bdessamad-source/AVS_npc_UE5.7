#include "AVSComposedAnimationPolicy.h"
#include <iostream>
#include <limits>
#include <stdexcept>
using namespace AVS::Composed;
static int Checks = 0;
static void Check(bool Pass, const char* Message) { ++Checks; if (!Pass) throw std::runtime_error(Message); }
static bool Near(double A, double B) { return std::abs(A-B) < 1e-8; }
int main()
{
    try
    {
        Options O; O.Duration = 5; O.Rate = 2;
        const Clips Matrix[] = {{2,4,3},{2,4,0},{0,4,3},{0,4,0},{2,0,0},{0,0,3},{2,0,3},{0,0,0}};
        for (int I = 0; I < 8; ++I)
        {
            const Plan P = Resolve(Matrix[I], O);
            Check(P.Valid == (I != 7), "clip matrix validity");
            if (!P.Valid) continue;
            Check(P.Hold == (I >= 4), "clip matrix loop or hold");
            Playback S; Check(S.Begin(P), "valid plan starts");
            Check(!S.CanMove(), "movement blocked throughout use");
            Check(!S.Begin(P), "repeated begin cannot restart");
            S.Advance(100); Check(!S.IsActive() && S.CanMove(), "large delta completes all phases");
            S.Reset(); Check(S.Begin(P), "pool reset supports fresh activation");
        }
        Check(Resolve(Matrix[1], O).Exit.Rate < 0, "Start+Loop reverses Start exit");
        Check(Resolve(Matrix[2], O).Entry.Rate < 0, "Loop+End reverses End entrance");
        for (int I : {4,5,6})
        {
            Options Disabled = O; Disabled.Hold = false;
            Check(!Resolve(Matrix[I], Disabled).Valid, "hold-disabled transition-only rejects");
            Disabled = O; Disabled.Smart = false;
            Check(!Resolve(Matrix[I], Disabled).Valid, "smart-disabled transition-only rejects");
        }
        Options NoReverse = O; NoReverse.Reverse = false;
        Check(!Resolve(Matrix[4], NoReverse).Valid && !Resolve(Matrix[5], NoReverse).Valid, "missing safe exit rejects without reverse");
        Check(Resolve(Matrix[6], NoReverse).Valid, "supplied start/end hold usable without reverse");
        Check(Resolve(Matrix[1], NoReverse).Exit.Source == Clip::None, "reverse toggle affects exit only");
        Check(Resolve(Matrix[2], NoReverse).Entry.Source == Clip::None, "reverse toggle affects entry only");
        for (double Position : {-9.,0.,.25,.6,1.,9.})
        {
            Options H = O; H.HoldPosition = Position;
            const Plan P = Resolve(Matrix[4], H);
            const double Expected = std::max(0.,std::min(1.,Position));
            Check(Near(P.Body.From, Expected), "hold position clamp");
            Check(Near(P.Entry.Seconds, Expected) && Near(P.Exit.Seconds, Expected), "partial traversal accounts rate");
            Playback S; S.Begin(P); S.Advance(P.Entry.Seconds);
            Check(S.GetPhase() == Phase::Body && Near(S.GetPosition(), Expected), "selected contact hold");
            S.RequestExit(); S.RequestExit(); S.Advance(100);
            Check(S.CanMove(), "zero-length or repeated exit completes");
        }
        for (int I : {4,5})
        {
            Playback S; const Plan P = Resolve(Matrix[I], O); S.Begin(P); S.Advance(.2);
            const double Contact = S.GetPosition(); S.RequestExit();
            Check(S.GetPhase() == Phase::Exit && Near(S.GetPosition(), Contact), "mid-entry cancellation preserves current pose");
            S.Advance(.1); const double Position = S.GetPosition(); S.RequestExit();
            Check(Near(S.GetPosition(), Position), "repeated cancellation cannot reset traversal");
            S.Advance(10); Check(S.CanMove(), "partial cancellation finishes before move");
        }
        Playback Supplied; const Plan Separate = Resolve(Matrix[0], O); Supplied.Begin(Separate); Supplied.Advance(.1); Supplied.RequestExit();
        Check(Supplied.GetPhase() == Phase::Entry, "supplied unrelated exit waits for contact");
        Supplied.Advance(.9); Check(Supplied.GetPhase() == Phase::Exit, "cancel at contact uses supplied exit");
        Supplied.Advance(1.5); Check(Supplied.CanMove(), "supplied end finishes before move");
        Options Infinite = O; Infinite.Duration = -1;
        Playback Loop; Loop.Begin(Resolve(Matrix[3], Infinite)); Loop.Advance(100);
        Check(Loop.IsActive(), "caller-owned looping doesn't expire");
        Loop.RequestExit(); Check(Loop.CanMove(), "loop-only cancellation safe");
        Options OneShot = Infinite; OneShot.Loop = false;
        Playback Main; Main.Begin(Resolve(Matrix[3], OneShot)); Main.Advance(100);
        Check(Near(Main.GetPosition(),1), "non-loop main holds final frame without replay");
        Options Invalid = O; Invalid.Rate = std::numeric_limits<double>::quiet_NaN(); Invalid.Duration = std::numeric_limits<double>::infinity(); Invalid.HoldPosition = std::numeric_limits<double>::quiet_NaN();
        const Plan SafePlan = Resolve(Matrix[4], Invalid);
        Check(SafePlan.Valid && Near(SafePlan.Entry.Rate,1) && Near(SafePlan.Duration,8), "nonfinite fields use safe defaults");
        Invalid = O; Invalid.Rate = -90; Invalid.Duration = 0;
        Check(Near(Resolve(Matrix[0], Invalid).Entry.Rate,.01), "negative rates clamped");
        Check(Near(Resolve(Matrix[0], Invalid).Duration,.01), "zero use duration bounded");
        Playback Bad; Check(!Bad.Begin(Resolve({}, O)) && Bad.CanMove(), "missing assets never lock movement");
        std::cout << "PASS: " << Checks << " composed-policy assertions\n";
        return 0;
    }
    catch (const std::exception& Error) { std::cerr << "FAIL after " << Checks << ": " << Error.what() << '\n'; return 1; }
}
