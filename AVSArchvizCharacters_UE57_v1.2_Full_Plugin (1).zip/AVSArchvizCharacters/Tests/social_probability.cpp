#include "AVSActivityProbability.h"

#include <cmath>
#include <iostream>
#include <limits>
#include <random>
#include <stdexcept>

namespace
{
int Checks = 0;
void Check(bool Condition, const char* Description)
{
	++Checks;
	if (!Condition) { throw std::runtime_error(Description); }
}
}

int main()
{
	using namespace AVSActivityProbability;
	const double NaN = std::numeric_limits<double>::quiet_NaN();
	const double Infinity = std::numeric_limits<double>::infinity();
	Check(AvailableWeight(-5) == 0, "negative weights excluded");
	Check(AvailableWeight(50, false) == 0, "missing category excluded");
	Check(AvailableWeight(NaN) == 0, "NaN excluded");
	Check(AvailableWeight(Infinity) == 0, "infinity excluded");
	Check(AvailableWeight(50) == 50, "positive weight preserved");
	Check(!PassesPercentage(0, 0), "zero percentage never succeeds including zero sample");
	Check(!PassesPercentage(-1, 0), "negative percentage never succeeds");
	Check(PassesPercentage(100, 0), "100 percent includes zero");
	Check(PassesPercentage(100, 1), "100 percent includes unit upper endpoint");
	Check(PassesPercentage(50, 0.4999), "sample below chance succeeds");
	Check(!PassesPercentage(50, 0.5), "category boundary is exclusive");
	Check(!PassesPercentage(50, 1), "sample above chance fails");
	Check(!PassesPercentage(NaN, 0), "NaN chance fails");
	Check(!PassesPercentage(Infinity, 0), "infinite chance fails");
	Check(!PassesPercentage(100, NaN), "NaN sample fails");
	Check(!PassesPercentage(100, -1), "out of range sample fails");
	Check(!PassesPercentage(100, 2), "out of range upper sample fails");
	const double Conversation[] = { 50, 50 };
	Check(ChooseWeighted(Conversation, 2, 0) == 0, "first category at zero");
	Check(ChooseWeighted(Conversation, 2, 0.4999) == 0, "Idle occupies lower half");
	Check(ChooseWeighted(Conversation, 2, 0.5) == 1, "Talk occupies upper half");
	Check(ChooseWeighted(Conversation, 2, 1) == 1, "unit upper endpoint selects last available");
	const double IdleMissing[] = { AvailableWeight(50, false), AvailableWeight(50, true) };
	Check(ChooseWeighted(IdleMissing, 2, 0) == 1, "missing Idle normalizes Talk to all choices");
	Check(ChooseWeighted(IdleMissing, 2, 1) == 1, "normalization includes upper endpoint");
	const double TalkMissing[] = { 50, 0 };
	Check(ChooseWeighted(TalkMissing, 2, 0.99) == 0, "missing Talk normalizes Idle to all choices");
	const double None[] = { 0, -1, NaN, Infinity };
	Check(ChooseWeighted(None, 4, 0.5) == -1, "all unavailable rejects safely");
	Check(ChooseWeighted(nullptr, 2, 0.5) == -1, "null list rejects");
	Check(ChooseWeighted(Conversation, 0, 0.5) == -1, "empty list rejects");
	Check(ChooseWeighted(Conversation, 2, NaN) == -1, "invalid random sample rejects");
	const double Ambient[] = { 50, AvailableWeight(20, false), 15, 15 };
	Check(ChooseWeighted(Ambient, 4, 0.6249) == 0, "available ambient weights normalize 50/80 Idle");
	Check(ChooseWeighted(Ambient, 4, 0.625) == 2, "ambient boundary skips unavailable smoking");
	Check(ChooseWeighted(Ambient, 4, 0.8125) == 3, "custom normalized boundary");
	Check(ChooseWeighted(Ambient, 4, 1) == 3, "ambient last available endpoint");

	// This runs the production two-stage policy with one Idle row and seven Talk rows.
	// Talk row count and row weights must never multiply the Talk category probability.
	std::mt19937_64 Random(0xA751);
	std::uniform_real_distribution<double> Unit(0.0, 1.0);
	const double TalkVariants[] = { 1, 1, 2, 3, 5, 8, 13 };
	int IdleCount = 0;
	int TalkCount = 0;
	int Variants[7] = {};
	for (int Trial = 0; Trial < 200000; ++Trial)
	{
		const int Category = ChooseWeighted(Conversation, 2, Unit(Random));
		if (Category == 0) { ++IdleCount; }
		else
		{
			++TalkCount;
			++Variants[ChooseWeighted(TalkVariants, 7, Unit(Random))];
		}
	}
	Check(std::abs(IdleCount - 100000) < 1500, "Idle remains 50 percent regardless of Talk variant count");
	Check(std::abs(TalkCount - 100000) < 1500, "all Talk variants together remain 50 percent");
	Check(Variants[6] > Variants[5] && Variants[5] > Variants[4], "row weights applied inside Talk category");
	Check(Variants[0] > 0 && Variants[1] > 0, "all positive variants remain reachable");
	std::cout << "Social probability tests: " << Checks << " checks passed; 200000 category trials; Idle="
		<< IdleCount << ", Talk=" << TalkCount << '\n';
}
