#!/usr/bin/env python3
"""Compile and execute production-policy tests without Unreal. Writes only to a temporary directory."""
from pathlib import Path
import os
import subprocess
import tempfile

plugin = Path(__file__).resolve().parents[1]
compiler = os.environ.get('CXX', 'c++')
with tempfile.TemporaryDirectory(prefix='avs-policy-') as temp:
    for source in ('composed_policy.cpp', 'social_probability.cpp'):
        executable = Path(temp) / Path(source).stem
        subprocess.run([compiler, '-std=c++17', '-Wall', '-Wextra', '-Werror', '-pedantic',
                        '-I', str(plugin / 'Source/AVSArchvizCharacters/Public'),
                        str(plugin / 'Tests' / source), '-o', str(executable)], check=True)
        subprocess.run([str(executable)], check=True)
print('Portable production policies passed. This is not a UHT/native Unreal build or asset-playback test.')
