#!/usr/bin/env bash
set -euo pipefail
test_dir="$(cd "$(dirname "$0")" && pwd)"
test_binary="$(mktemp /tmp/avs-social-probability.XXXXXX)"
trap 'rm -f "$test_binary"' EXIT
"${CXX:-c++}" -std=c++17 -Wall -Wextra -Werror -pedantic -O2 \
  -I"$test_dir/../Source/AVSArchvizCharacters/Public" \
  "$test_dir/social_probability.cpp" -o "$test_binary"
"$test_binary"
