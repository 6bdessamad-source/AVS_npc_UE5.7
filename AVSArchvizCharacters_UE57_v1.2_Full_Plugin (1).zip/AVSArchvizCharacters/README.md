# AVS ArchViz Characters

Independent source plugin for modular architectural-visualization NPCs in Unreal Engine 5.7.

Current package: **v1.2** (descriptor revision 18), the UE 5.7 compiler and linker fixes for the complete v1.10.0 rework. See [build fixes and installation](Docs/V1_2_COMPILER_FIX.md).

The plugin owns its NPC, controller, behavior, modular appearance, animation selection, pooling and crowd logic. It does not use `BP_NPC`, does not depend on an NPC Creator pack, does not link against the game module, and does not modify `UnifiedArchvizCharacter`.

## Main classes

| Need | Class |
|---|---|
| Component added to the project pawn | `UAVSArchvizCrowdComponent` |
| Plugin-owned NPC | `AAVSArchvizNPCCharacter` |
| AI Controller and optional Behavior Tree | `AAVSArchvizNPCAIController` |
| Body, sex, rig and modular-part choices | `UAVSCharacterProfile` |
| Manual animation slots and compatibility | `UAVSAnimationProfile` |
| Validated appearance/animation pairs | `UAVSCharacterLibrary` |
| Dispersed people | `AAVSCrowdZone` |
| Closed-spline crowd surface | `AAVSSplineCrowdZone` |
| Generated or placed spline walkers | `AAVSCrowdRoute` |
| Universal no-spawn/no-walk spline or box | `AAVSCrowdExclusionMask` |
| Global density, cap and graphics control | `AAVSCrowdGlobalController` |
| Groups and actor following | `AAVSNPCGroup` |
| Timed activities and queues | `AAVSPointOfInterest` |
| Pooling and distance quality | `UAVSCrowdSubsystem` |

Version 1.10.0 reworks activity ownership, contact-pose holds, safe partial reverse exits, profile-driven POI sequence preview, normalized ambient weights and 50/50 Idle/Talk conversations. Navigation arrival uses smooth facing and timeouts; pooled agents restore movement and animation state before visibility. It preserves target-specific Skeleton validation, modular head randomization, retargeting, routes and one centralized local navigation invoker.

This is a source release with portable production-policy tests. UE 5.7 UHT, native compilation, asset playback, PIE and packaging remain required acceptance gates. See [v1.10 migration and setup](Docs/V1_10_MIGRATION_AND_SETUP.md).

## Installation

1. Copy `AVSArchvizCharacters` to `<Project>/Plugins/`.
2. Delete the plugin's old `Binaries` and `Intermediate` folders if replacing an earlier version.
3. Regenerate project files and build the Editor target.
4. Enable **AVS ArchViz Characters** if Unreal requests it.
5. Add a `NavMeshBoundsVolume` over every possible pedestrian area. For very large maps, follow [Large-world navigation](Docs/LARGE_WORLD_NAVIGATION.md) instead of building the entire map at runtime.

Start with [Quick Start](Docs/QUICK_START.md).

## Guides

- [v1.10 migration and setup](Docs/V1_10_MIGRATION_AND_SETUP.md)
- [Quick Start](Docs/QUICK_START.md)
- [Behavior, controller, paths and activities](Docs/BEHAVIOR_AND_PATHS.md)
- [Walking and Orbit integration](Docs/WALKING_ORBIT_INTEGRATION.md)
- [Character Profiles and random modular parts](Docs/CHARACTER_PROFILES.md)
- [Animation compatibility and retargeting](Docs/ANIMATION_AND_RETARGETING.md)
- [Crowd zones, routes, groups and POIs](Docs/CROWD_GENERATORS.md)
- [Global controller and exclusion masks](Docs/GLOBAL_CONTROL_AND_MASKS.md)
- [Large-world local navigation](Docs/LARGE_WORLD_NAVIGATION.md)
- [Optimization and packaged builds](Docs/OPTIMIZATION_AND_PACKAGING.md)
- [Troubleshooting](Docs/TROUBLESHOOTING.md)
- [Acceptance checklist](Docs/ACCEPTANCE_CHECKLIST.md)

## Source-only boundary

The ZIP contains no invented `.uasset` files. You create Character Profiles, Animation Profiles, Behavior Trees, IK Rigs and IK Retargeters inside Unreal after the plugin compiles. Original meshes and animations are never overwritten.
