# Build and Test Log

## 2026-10-01 — v1.2 Runtime log export fix (descriptor revision 18)

The user reported one unresolved external, `LogAVSArchvizCharacters`, and Build.bat exit code 6. The Runtime module has exactly one existing `DEFINE_LOG_CATEGORY`; the Editor scene-validation report uses that category through the public module header. The declaration lacked the Runtime API export/import annotation even though the Editor Build.cs already declares its Runtime dependency.

Correction: add `AVSARCHVIZCHARACTERS_API` to `DECLARE_LOG_CATEGORY_EXTERN` in the public module header and include `Logging/LogMacros.h` directly. Keep the single Runtime definition and the existing dependency. The package label stays v1.2 and its descriptor revision increases to 18. The previous two compiler fixes and all rework source remain.

Checks actually run for this update:

- Confirmed a single public declaration, a single Runtime definition, the Editor consumer's direct header include and its existing Runtime module dependency.
- Compared source bytes against the first delivered v1.2 tree: only `Public/AVSArchvizCharacters.h` changes; reflected headers, Build.cs files and every C++ implementation are unchanged. All previous file paths remain.
- Validated descriptor revision/label, local documentation links, regenerated source manifests/checksums, and checked complete ZIP CRC, safe/unique paths, payload bytes and checksum entries.

This is a module export correction. Portable animation-policy suites were not rerun because those policies are unchanged; their previous results below remain historical coverage. Unreal Engine is unavailable here, so Windows UE 5.7 DLL linking, Editor loading, PIE and packaging still require verification in the target project.

## 2026-10-01 — v1.2 UE 5.7 compiler fix (descriptor revision 17)

The supplied user build log completed UHT processing and then failed native compilation on two source sites. `AVSCrowdGenerator.cpp` used the forward-declared behavior component without its complete header (C2027/C2039). The controller constructed `FPathFollowingRequestResult` from an unsupported enum argument (C2440, with C4390 at the same rejection branch). The final MSB3073 / code -1 was the build failure consequence. Engine ThirdParty lowercase-name CS8981 messages were warnings in the log, not the fatal errors.

Corrections: include `AVSNPCBehaviorComponent.h` directly in the generator; default-construct the controller's failed request result, set its public `Code` explicitly, and brace the failure branch. Exactly those two plugin C++ files changed. Reflected headers, public Blueprint declarations, serialized enums, Build.cs dependencies and all v1.10.0 rework functionality are retained. The requested package/display name is v1.2; the descriptor revision increases to 17.

Checks actually run for this package:

- `python3 Tests/run_portable_tests.py`, exit 0: 102 composed-policy assertions, 36 probability checks, 200000 draws (Idle 100270, Talk 99730). These tests exercise the retained production policies, not the Unreal C++ translation units being repaired.
- Compared all source files against the delivered v1.10.0 tree: only the two intended C++ files differ; every original plugin file path is retained.
- 29 headers checked; generated includes remain last, quoted local AVS includes resolve, and every C++ file dereferencing the behavior component includes its definition directly. Package JSON and local Markdown links pass validation.
- Source manifests/checksums are regenerated for the complete package; integrity files exclude themselves and one another to avoid recursive hashes.

Unreal Engine is unavailable here. No corrected-package native UE build, PIE or asset playback success is claimed. Install the complete ZIP and rebuild `AVS_labsEditor` in UE 5.7 as described in Docs/V1_2_COMPILER_FIX.md.

## 2026-10-01 — v1.10.0 full source rework (new results)

Implemented shared composed-animation resolver/state, literal transition-only contact holds, exact partial cancellation, independently controlled reverse/hold, compatible POI runtime overrides and matched editor sequence preview. Movement waits for activity exits, navigation arrival uses smooth facing/tolerances/timeouts, and pool/quality transitions reset or drain animation/behavior state safely. Normal Idle/Talk conversation categories default to 50/50 combined Talk probability; ambient category weights and independent formation percentage have project/global/box/spline controls. Added scene/profile validation, retained modular head randomization/retargeting, and copied all new settings to generated profiles. Package metadata is Version16 / VersionName1.10.0.

Tests actually run:

- `python3 Tests/run_portable_tests.py`: C++17 `-Wall -Wextra -Werror -pedantic`, exit0. Production composed policy **102 assertions passed**. Production probability helper **36 checks passed**, **200000** deterministic category draws: Idle **100270**, Talk **99730**.
- Both production suites independently ran with g++ AddressSanitizer and UndefinedBehaviorSanitizer (`-fsanitize=address,undefined -fno-omit-frame-pointer -g`), exit0, using `ASAN_OPTIONS=detect_leaks=0`. LeakSanitizer cannot run in this managed environment; no leak coverage is claimed.
- `git diff --check`: passed. Source static check: **29 headers**, **29 C++ sources**, **18 Markdown files**; valid plugin JSON, generated includes last, quoted local AVS includes resolve, delimiters balanced and local documentation links resolve. Existing Blueprint declarations and the unchanged serialized Types header were reviewed against the git baseline. All original plugin file paths remain.
- Runtime/Editor dependency direction checked; Runtime uses Engine/AIModule/NavigationSystem/GameplayTasks/DeveloperSettings and private AnimGraphRuntime. Editor adds ToolMenus/NavigationSystem/AnimGraphRuntime/Slate/SlateCore. Retarget copies smart/reverse/hold masters and whole row arrays. Public serialized enum order in AVSArchvizTypes.h is byte-for-byte unchanged.
- Official Epic API pages checked for AAIController MoveTo override, generated AnimNode properties/Slot inspection and ToolMenus startup callbacks. This API review is not a native compilation result.
- Updated source manifest and SHA256 sums. Both integrity files exclude themselves/one another to avoid recursive hashes. ZIP CRC, content/path, payload-byte and manifest checksum verification passed after package generation. Package includes the complete plugin directory and excludes Binaries, Intermediate, credentials, Codex logs and task-only files.

UE environment/gates:

- No UnrealEditor or UnrealBuildTool command was found in PATH; an independent search under /opt and /workspace found no engine executables.
- **UHT, UE 5.7 native Runtime/Editor compilation, editor preview, PIE, packaging and actual asset playback were not performed.** Added `AVS.Animation.ComposedPolicy` and `AVS.POI.ReservationLifecycle` UE automation source but neither was compiled/run.
- Source tests cover policy/control/probability logic, not real animation graphs, root-motion/notifies, NavMesh async completion or rendered lifecycle. Run Docs/ACCEPTANCE_CHECKLIST.md in the target UE5.7 project. Capacity>1 still shares one contact position; use separate Capacity1 POIs for distinct chairs.

## Historical results (v1.9 and earlier)

The entries below are preserved history. Their old static/user-reported claims do not validate v1.10; the old “Start-only” descriptions meant transition partner missing with a main present. Literal transition-only support was added in v1.10.

## 2026-09-30 — Large-world local navigation and global-cost reduction

- Added one controller-managed transient Navigation Invoker that follows the true viewer/camera location, with separate Walking/Orbit generation radii, removal padding and movement hysteresis.
- Added a one-click editor collision-channel filter that disables navigation relevance only on placed primitives that do not Block the selected channel.
- Made AVS capsules, body meshes, modular skeletal parts and props navigation-irrelevant.
- Added preset-aware repeated `MoveTo` suppression while preserving immediate route-point and significantly moved-target updates.
- Replaced all-against-all conversation candidate matching with a spatial grid and neighboring-cell queries.
- Incremented the plugin to version 1.9.0. Static checks passed; UE 5.7 UHT, compilation, invoker tile generation, channel-filter Undo and packaged-world tests remain external gates.

## 2026-09-30 — Smart missing composed transitions

- Added a profile-wide **Enable Smart Missing Transition Fallback** control and a per-row **Allow Reverse Transition Fallback** control.
- A Start-only row now plays Start → main/loop → reversed Start; an End-only row plays reversed End → main/loop → End; a main-only row remains valid and plays without synthesized transitions.
- Applied the same inference to POI runtime rows and the POI Start/End editor preview phases.
- Reverse playback supports both dynamic-montage and single-node paths while preserving the row play rate and exact Skeleton guard.
- Incremented the plugin to version 1.8.0. Static checks passed; UE 5.7 UHT, compilation, viewport preview and PIE with real animation assets remain external gates.

## 2026-09-30 — Proximity conversations, connectors and POI preview

- Added centralized low-frequency 2–4 person conversation matching with inward facing, weighted Talk variants, Idle fallback, random departure, cooldown and return-to-wander.
- Added occupied-route clearance plus a route-exit social delay so path users are not interrupted.
- Added per-zone AVS Idle Percentage Weight.
- Added Path Only, Crowd-Zone Connector Only and combined route modes, multi-zone discovery and open-end destination handoff.
- Added POI Idle/Start/Activity/End editor preview phases and clear-before-automatic-reuse safety.
- Incremented the plugin to version 1.7.0. Static checks passed; UE 5.7 UHT, compilation, PIE and real asset tests remain external gates.

## 2026-09-30 — Animation safety, route networks and crowd quality

- Added per-profile body mesh transform with Z `-88` / Yaw `-90` defaults for capsule alignment.
- Added per-row Skeleton filtering and nested Character Library validation so an invalid male sequence cannot be randomly selected from a female profile.
- Added automatic Start–Main/Loop–End rows, movement preparation and a compatible-Walk requirement to prevent stationary idle/activity clips from sliding.
- Added persistent route lane offsets, width-gated couples with gender policy, compatible crossing-route transfers and open-end event/despawn.
- Added lightweight Character Movement RVO controlled per NPC, per quality tier and globally.
- Added Spline/Box exclusion-mask shapes and consistent Side-by-Side/V/Line/Circle group formations.
- Incremented the plugin to version 1.4.0 and expanded setup/troubleshooting documentation.
- Static validation passed. Unreal Engine is not installed here; UE 5.7 UHT, native compilation, PIE with real meshes/animations, navigation and packaged-build testing remain external gates.

## 2026-09-29 — Smooth animation, spline surfaces and global control

- Added weighted variants for every animation slot, immediate-repeat avoidance, timed Idle rotation and speed hysteresis.
- Added dynamic-montage blend in/out through a configurable Animation Blueprint Slot, plus optional Walk/Run Start/Stop fallback clips.
- Added `AAVSSplineCrowdZone` for NavMesh-projected spawning inside a closed spline polygon.
- Added weighted zone-to-route decisions, contained-route auto-discovery and return-to-wander after non-looping routes.
- Added `AAVSCrowdExclusionMask` for universal spawn/movement rejection and a sampled Pawn-blocking, navigation-relevant boundary.
- Added `AAVSCrowdGlobalController` for density, caps, pooling, presets, collision, shadows, update-rate optimization, visibility ticking, LOD and draw distance.
- Incremented the plugin to version 1.3.0 and expanded the setup and technical-boundary guides.
- Unreal Engine is not installed here; UE 5.7 UHT, compilation, AnimBP Slot, PIE navigation, performance and packaging tests remain external gates.

## 2026-09-30 — UE 5.7 compiler feedback

- The target project reported MSVC shadowing for a local declaration named `Character`, followed by Build.bat code 6. Renamed the controller selection variable to `SelectedCharacter` and every local ACharacter pointer to `OwnerCharacter`.
- The Visual Studio `TIsContiguousContainer` / zero-size-array diagnostics are treated as cascading IntelliSense template diagnostics unless they also appear in the Unreal Build output with a concrete source file and line.
- Re-ran generated-header order, balanced delimiter, local include, documentation link, legacy dependency and shadow-name scans after the correction: 25 headers, 23 C++ sources and 15 Markdown files passed.

## 2026-09-29 — Compatibility-first behavior update

- Removed the experimental version 1.1 NPC Creator adapter and all runtime/editor references to it.
- Added Male, Female, Unisex/Any and Custom compatibility tags to Character Profiles, modular parts and Animation Profiles.
- Added optional Rig IDs and exact Skeleton filtering. Generators, Character Libraries and the AI Controller now choose the character first and only then choose a compatible animation.
- Added a final playback guard that refuses a mismatched animation Skeleton.
- Added weighted native modular-part randomization, per-part sex tags and weighted No Part choices.
- Added optional Behavior Tree startup and controller-owned profile pools to `AAVSArchvizNPCAIController`.
- Added weighted idle activities, timed POI use, facing, auto-release and behavior restoration.
- Added direct placed-NPC assignment to spline routes and nearest-route-point startup.
- Added editor-only billboards to AVS NPCs, generators and POIs.
- Updated the source guides and incremented the plugin to version 1.2.0.
- Static checks passed: plugin JSON, 22 reflected/runtime headers, 20 C++ sources, generated-header order, delimiter balance, local include resolution, documentation links, runtime/editor separation and legacy source dependency scan.
- UE 5.7 compilation and PIE still require the target project because Unreal Engine is not installed in this environment.

## 2026-09-29 — NPC Creator compatibility update

- Added a generic Creator Blueprint profile without a hard dependency on the Clothing Mega Pack.
- Mapped the supplied male/female body, hair, midwear, overwear, bottoms and shoes enum workflow.
- Creator variables are applied before deferred construction so the original Blueprint keeps responsibility for its hair tables, compatible meshes and opacity masks.
- Added clothes-only/full randomization, allow/exclude filters, deterministic seeds, editor buttons and optional re-randomization after pool activation.
- Routed the manual animation driver, hidden state, animation pause and shadow quality to the Creator visual.
- Confirmed against Epic's runtime API that deferred spawning allows property assignment before the Blueprint construction script and that `FinishSpawningActor` runs that script.
- Static checks passed: plugin JSON, 23 reflected/runtime headers, 21 C++ sources, generated-header order, delimiter balance, runtime/editor separation and no Clothing Mega Pack asset-path dependency.
- Incremented the plugin to version 1.1.0. UE 5.7 compilation and PIE still require the target project.

## 2026-09-29 — UE 5.7 link feedback

- Version 1.0.1 passed UnrealHeaderTool and compiled every AVS Runtime and Editor source file.
- `AVS_labs`, `AVSArchvizCharacters`, `OverCrowd` and `OverCrowdEditor` also compiled and linked.
- The only fatal error was `LNK2019/LNK1120` for five `UEditorSubsystem` symbols.
- Added the UE 5.7 `EditorSubsystem` module to `AVSArchvizCharactersEditor.Build.cs`.
- Removed the unused `UnrealEd` dependency and incremented the plugin to version 1.0.2.
- The user subsequently reported that the plugin worked.

## 2026-09-29 — UE 5.7 build feedback

- User build reached `AVSArchvizCharactersEditor` successfully enough to compile its translation units.
- First fatal error: `C1083`, missing `Subsystems/EditorSubsystem.h`.
- Corrected the UE 5.7 include to `EditorSubsystem.h`.
- Plugin version incremented to `1.0.1`.
- The project log also reports non-fatal project dependency warnings for GeometryScripting, GeometryProcessing and EditorScriptingUtilities; these are outside this plugin and do not cause the current failure.

## 2026-09-28

- Confirmed valid `.uplugin` JSON and two declared modules.
- Checked 40+ C++ headers and source files for balanced delimiters.
- Checked every reflected header for a final `*.generated.h` include.
- Checked local AVS header references for missing files.
- Scanned for `BP_NPC`, game-module API macros, TODOs and placeholders; no runtime dependency found.
- Confirmed Runtime Build.cs does not depend on the Editor module.
- Confirmed the Editor module depends on Runtime, not the reverse.
- Checked official Unreal API documentation for `UTickableWorldSubsystem`, `SetLeaderPoseComponent`, `SetPlayRate` and Navigation System projection signatures.
- Final static suite: 22 headers, 20 C++ sources and 13 Markdown files; all checks passed.
- No Unreal Engine executable or UnrealBuildTool is installed in this environment, so UnrealHeaderTool and native compilation were unavailable.
