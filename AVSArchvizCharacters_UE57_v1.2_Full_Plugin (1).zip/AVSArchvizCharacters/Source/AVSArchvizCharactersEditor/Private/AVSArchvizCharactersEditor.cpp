#include "AVSArchvizCharactersEditor.h"

#include "AVSCrowdGlobalController.h"
#include "AVSArchvizEditorSubsystem.h"
#include "Editor.h"
#include "Framework/Commands/UIAction.h"
#include "Misc/MessageDialog.h"
#include "Modules/ModuleManager.h"
#include "ToolMenus.h"

namespace
{
	FDelegateHandle ValidationMenuStartupHandle;
}

void FAVSArchvizCharactersEditorModule::StartupModule()
{
	ValidationMenuStartupHandle = UToolMenus::RegisterStartupCallback(FSimpleMulticastDelegate::FDelegate::CreateLambda([this]()
	{
		FToolMenuOwnerScoped Owner(this);
		UToolMenu* ToolsMenu = UToolMenus::Get()->ExtendMenu(TEXT("LevelEditor.MainMenu.Tools"));
		FToolMenuSection& ToolsSection = ToolsMenu->FindOrAddSection(TEXT("AVS"));
		ToolsSection.AddSubMenu(TEXT("AVSCharacters"), NSLOCTEXT("AVS", "ToolsAVS", "AVS"),
			NSLOCTEXT("AVS", "ToolsAVSTooltip", "AVS ArchViz Characters scene tools."),
			FNewToolMenuDelegate::CreateLambda([](UToolMenu* Menu)
			{
				FToolMenuSection& Section = Menu->FindOrAddSection(TEXT("Validation"));
				Section.AddMenuEntry(TEXT("ValidateSceneProfiles"),
					NSLOCTEXT("AVS", "ValidateSceneProfiles", "Validate Scene / Profiles"),
					NSLOCTEXT("AVS", "ValidateSceneProfilesTooltip", "Check scene profiles, Skeletons, modular parts, POI sequences, navigation, and montage Slots. Read-only; the full report is also written to the Output Log."),
					FSlateIcon(), FUIAction(FExecuteAction::CreateLambda([]()
					{
						if (!GEditor) return;
						if (UAVSArchvizEditorSubsystem* Subsystem = GEditor->GetEditorSubsystem<UAVSArchvizEditorSubsystem>())
						{
							FString Report;
							Subsystem->ValidateSceneProfiles(Report);
							FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(Report));
						}
					})));
			}));
	}));
	RetargetRequestHandle = AAVSCrowdGlobalController::OnRetargetRequested().AddLambda(
		[](AAVSCrowdGlobalController* Controller, bool bUpdateExisting)
		{
			if (!Controller || !GEditor)
			{
				return;
			}
			if (UAVSArchvizEditorSubsystem* Subsystem = GEditor->GetEditorSubsystem<UAVSArchvizEditorSubsystem>())
			{
				Controller->Modify();
#if WITH_EDITORONLY_DATA
				Controller->LastRetargetReport = Subsystem->RunSceneRetarget(Controller, bUpdateExisting);
#endif
			}
		});
}

void FAVSArchvizCharactersEditorModule::ShutdownModule()
{
	if (ValidationMenuStartupHandle.IsValid())
	{
		UToolMenus::UnRegisterStartupCallback(ValidationMenuStartupHandle);
		ValidationMenuStartupHandle.Reset();
	}
	UToolMenus::UnregisterOwner(this);
	if (RetargetRequestHandle.IsValid())
	{
		AAVSCrowdGlobalController::OnRetargetRequested().Remove(RetargetRequestHandle);
		RetargetRequestHandle.Reset();
	}
}

IMPLEMENT_MODULE(FAVSArchvizCharactersEditorModule, AVSArchvizCharactersEditor)
