#include "AVSArchvizEditorSubsystem.h"

#include "AVSAnimationProfile.h"
#include "AVSArchvizNPCCharacter.h"
#include "AVSArchvizCharacters.h"
#include "AVSCharacterLibrary.h"
#include "AVSCharacterProfile.h"
#include "AVSCrowdGenerator.h"
#include "AVSCrowdGlobalController.h"
#include "AVSPointOfInterest.h"
#include "AVSResolvedAnimation.h"
#include "Animation/AnimBlueprintGeneratedClass.h"
#include "Animation/AnimInstance.h"
#include "Animation/AnimSequenceBase.h"
#include "Animation/Skeleton.h"
#include "AnimNodes/AnimNode_Slot.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "AssetToolsModule.h"
#include "Engine/SkeletalMesh.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "Editor.h"
#include "FileHelpers.h"
#include "IAssetTools.h"
#include "Misc/Crc.h"
#include "Misc/DateTime.h"
#include "Misc/PackageName.h"
#include "Misc/ScopedSlowTask.h"
#include "NavigationData.h"
#include "NavigationSystem.h"
#include "NavMesh/NavMeshBoundsVolume.h"
#include "ObjectTools.h"
#include "RetargetEditor/IKRetargetBatchOperation.h"
#include "Retargeter/IKRetargeter.h"
#include "ScopedTransaction.h"
#include "UObject/Package.h"
#include "UObject/UnrealType.h"

namespace
{
	FString IssuesToReport(const TArray<FText>& Issues)
	{
		if (Issues.IsEmpty())
		{
			return TEXT("Validation passed.");
		}
		FString Report;
		for (const FText& Issue : Issues)
		{
			Report += TEXT("- ") + Issue.ToString() + LINE_TERMINATOR;
		}
		return Report;
	}

	FString MakeSafeAssetName(const FString& Input)
	{
		FString Result;
		Result.Reserve(Input.Len());
		for (const TCHAR Character : Input)
		{
			Result.AppendChar(FChar::IsAlnum(Character) || Character == TEXT('_') ? Character : TEXT('_'));
		}
		return Result;
	}

	FString MakeObjectPath(const FString& PackageName)
	{
		return PackageName + TEXT(".") + FPackageName::GetLongPackageAssetName(PackageName);
	}

	template <typename TObjectType>
	TObjectType* LoadAssetAtPackage(const FString& PackageName)
	{
		return Cast<TObjectType>(FSoftObjectPath(MakeObjectPath(PackageName)).TryLoad());
	}

	UAVSAnimationProfile* ResolveOriginalProfile(UAVSAnimationProfile* Profile)
	{
#if WITH_EDITORONLY_DATA
		TSet<UAVSAnimationProfile*> Visited;
		while (Profile && Profile->bGeneratedByAVSRetargetUtility && !Visited.Contains(Profile))
		{
			Visited.Add(Profile);
			UAVSAnimationProfile* Source = Profile->RetargetSourceProfile.LoadSynchronous();
			if (!Source)
			{
				break;
			}
			Profile = Source;
		}
#endif
		return Profile;
	}

	bool IsCompatibleIgnoringSkeleton(const UAVSCharacterProfile* Character, const UAVSAnimationProfile* Animation)
	{
		return Character && Animation && AVSIsSexCompatible(Character->Sex, Animation->CompatibleSex) &&
			(Character->RigId.IsNone() || Animation->RigId.IsNone() || Character->RigId == Animation->RigId);
	}

	bool IsProfileAlreadyTargetCompatible(const UAVSAnimationProfile* Profile, const USkeleton* TargetSkeleton)
	{
		if (!Profile || !TargetSkeleton || Profile->TargetSkeleton.LoadSynchronous() != TargetSkeleton)
		{
			return false;
		}
		for (const FAVSNamedAnimation& Entry : Profile->Animations)
		{
			const UAnimSequenceBase* Assets[] = {
				Entry.Animation.LoadSynchronous(),
				Entry.StartAnimation.LoadSynchronous(),
				Entry.EndAnimation.LoadSynchronous()
			};
			for (const UAnimSequenceBase* Asset : Assets)
			{
				if (Asset && Asset->GetSkeleton() != TargetSkeleton)
				{
					return false;
				}
			}
		}
		return true;
	}

	void CopyProfileSettings(const UAVSAnimationProfile* Source, UAVSAnimationProfile* Destination)
	{
		Destination->CompatibleSex = Source->CompatibleSex;
		Destination->RigId = Source->RigId;
		Destination->Animations = Source->Animations;
		Destination->WalkSpeedThreshold = Source->WalkSpeedThreshold;
		Destination->RunSpeedThreshold = Source->RunSpeedThreshold;
		Destination->SpeedHysteresis = Source->SpeedHysteresis;
		Destination->DesiredWalkSpeed = Source->DesiredWalkSpeed;
		Destination->MovementAcceleration = Source->MovementAcceleration;
		Destination->MovementDeceleration = Source->MovementDeceleration;
		Destination->bUseAccelerationForPaths = Source->bUseAccelerationForPaths;
		Destination->bMatchLocomotionPlayRateToSpeed = Source->bMatchLocomotionPlayRateToSpeed;
		Destination->WalkAnimationReferenceSpeed = Source->WalkAnimationReferenceSpeed;
		Destination->RunAnimationReferenceSpeed = Source->RunAnimationReferenceSpeed;
		Destination->MinDynamicLocomotionPlayRate = Source->MinDynamicLocomotionPlayRate;
		Destination->MaxDynamicLocomotionPlayRate = Source->MaxDynamicLocomotionPlayRate;
		Destination->LocomotionPlayRateInterpolationSpeed = Source->LocomotionPlayRateInterpolationSpeed;
		Destination->IdleVariantMinTime = Source->IdleVariantMinTime;
		Destination->IdleVariantMaxTime = Source->IdleVariantMaxTime;
		Destination->bUseSmoothMontageTransitions = Source->bUseSmoothMontageTransitions;
		Destination->MontageSlotName = Source->MontageSlotName;
		Destination->BlendInTime = Source->BlendInTime;
		Destination->BlendOutTime = Source->BlendOutTime;
		Destination->bUseTransitionClips = Source->bUseTransitionClips;
		Destination->bEnableSmartMissingTransitionFallback = Source->bEnableSmartMissingTransitionFallback;
		Destination->bEnableReverseTransitionFallback = Source->bEnableReverseTransitionFallback;
		Destination->bEnableHoldPoseFallback = Source->bEnableHoldPoseFallback;
	}

	bool HasCompiledMontageSlot(UClass* AnimationClass, FName SlotName)
	{
		UAnimBlueprintGeneratedClass* GeneratedClass = Cast<UAnimBlueprintGeneratedClass>(AnimationClass);
		if (!GeneratedClass || !GeneratedClass->GetDefaultObject()) return false;
		for (FStructProperty* Property : GeneratedClass->GetAnimNodeProperties())
		{
			if (Property && Property->Struct == FAnimNode_Slot::StaticStruct())
			{
				const FAnimNode_Slot* Slot = Property->ContainerPtrToValuePtr<FAnimNode_Slot>(GeneratedClass->GetDefaultObject());
				if (Slot && Slot->SlotName == SlotName) return true;
			}
		}
		return false;
	}

	void ValidateMontageSetup(const UAVSCharacterProfile* Character, const UAVSAnimationProfile* Animation,
		TArray<FString>& Messages)
	{
		if (!Character || !Animation || !Animation->bUseSmoothMontageTransitions) return;
		UClass* AnimationClass = Character->AnimationBlueprint.LoadSynchronous();
		if (!AnimationClass)
		{
			Messages.Add(FString::Printf(TEXT("[Warning] %s + %s: smooth montage transitions require an Animation Blueprint. Assign one to the Character Profile and connect a Slot '%s' to the final pose; current playback uses single-node transitions."),
				*Character->GetPathName(), *Animation->GetPathName(), *Animation->MontageSlotName.ToString()));
			return;
		}
		if (UAnimBlueprintGeneratedClass* GeneratedClass = Cast<UAnimBlueprintGeneratedClass>(AnimationClass))
		{
			if (GeneratedClass->GetTargetSkeleton() != Character->ResolveAnimationSkeleton())
			{
				Messages.Add(FString::Printf(TEXT("[Error] %s: Animation Blueprint %s targets another Skeleton. Assign/retarget a Blueprint for body Skeleton %s."),
					*Character->GetPathName(), *AnimationClass->GetPathName(), *GetPathNameSafe(Character->ResolveAnimationSkeleton())));
			}
			if (!HasCompiledMontageSlot(AnimationClass, Animation->MontageSlotName))
			{
				Messages.Add(FString::Printf(TEXT("[Warning] %s + %s: compiled Animation Blueprint %s contains no Slot '%s'. Add that Slot node on the final pose path and compile the Blueprint, or disable smooth montage transitions."),
					*Character->GetPathName(), *Animation->GetPathName(), *AnimationClass->GetPathName(), *Animation->MontageSlotName.ToString()));
			}
		}
		else
		{
			Messages.Add(FString::Printf(TEXT("[Warning] %s: native animation class %s cannot be checked for a compiled montage Slot. Verify Slot '%s' is evaluated on the final pose path in PIE."),
				*Character->GetPathName(), *AnimationClass->GetPathName(), *Animation->MontageSlotName.ToString()));
		}
		if (USkeleton* Skeleton = Character->ResolveAnimationSkeleton())
		{
			if (Animation->MontageSlotName.IsNone() || !Skeleton->ContainsSlotName(Animation->MontageSlotName))
			{
				Messages.Add(FString::Printf(TEXT("[Warning] %s: Skeleton %s has no registered montage Slot '%s'. Register it in the Skeleton Slot Manager and use the same name in the Animation Profile and Blueprint."),
					*Animation->GetPathName(), *Skeleton->GetPathName(), *Animation->MontageSlotName.ToString()));
			}
		}
	}

	FString MakeProfileKey(const UAVSAnimationProfile* Source, const USkeleton* TargetSkeleton)
	{
		return GetPathNameSafe(Source) + TEXT("|") + GetPathNameSafe(TargetSkeleton);
	}

	struct FRetargetedProfileResult
	{
		UAVSAnimationProfile* Profile = nullptr;
		bool bValid = false;
	};
}

bool UAVSArchvizEditorSubsystem::ValidateCharacterProfile(UAVSCharacterProfile* Profile, FString& OutReport) const
{
	TArray<FText> Issues;
	bool bValid = Profile && Profile->ValidateProfile(Issues);
	if (!Profile)
	{
		Issues.Add(NSLOCTEXT("AVS", "NullCharacterProfileEditor", "No Character Profile was supplied."));
	}
	else
	{
		USkeleton* BodySkeleton = Profile->ResolveAnimationSkeleton();
		if (!BodySkeleton)
		{
			Issues.Add(FText::FromString(TEXT("Assign a Body Mesh with a valid Skeleton before configuring animations or modular parts.")));
		}
		for (int32 Index = 0; Index < Profile->ModularParts.Num(); ++Index)
		{
			const FAVSSkinnedPartDefinition& Part = Profile->ModularParts[Index];
			if (!Part.bEnabled || Part.bNoPart || !AVSIsSexCompatible(Profile->Sex, Part.CompatibleSex)) continue;
			USkeletalMesh* Mesh = Part.Mesh.LoadSynchronous();
			if (!Mesh)
			{
				Issues.Add(FText::FromString(FString::Printf(TEXT("Modular Parts row %d (%s): assign a valid Mesh, enable No Part for an empty choice, or disable this row."),
					Index, *UEnum::GetValueAsString(Part.Slot))));
			}
			else if (BodySkeleton && Mesh->GetSkeleton() != BodySkeleton && !Profile->bRequireSameSkeleton)
			{
				Issues.Add(FText::FromString(FString::Printf(TEXT("Modular Parts row %d: %s differs from body Skeleton %s. Leader Pose parts require compatible bone layout; disabling Require Same Skeleton does not retarget clothing. Re-skin to the body Skeleton or remove this choice."),
					Index, *Mesh->GetPathName(), *BodySkeleton->GetPathName())));
			}
		}
		if (UAnimBlueprintGeneratedClass* Class = Cast<UAnimBlueprintGeneratedClass>(Profile->AnimationBlueprint.LoadSynchronous()))
		{
			if (BodySkeleton && Class->GetTargetSkeleton() != BodySkeleton)
			{
				Issues.Add(FText::FromString(FString::Printf(TEXT("Animation Blueprint %s targets another Skeleton. Assign a Blueprint targeting %s."),
					*Class->GetPathName(), *BodySkeleton->GetPathName())));
			}
		}
		bValid &= Issues.IsEmpty();
	}
	OutReport = IssuesToReport(Issues);
	return bValid;
}

bool UAVSArchvizEditorSubsystem::ValidateAnimationProfile(UAVSAnimationProfile* Profile, FString& OutReport) const
{
	TArray<FText> Issues;
	bool bValid = Profile && Profile->ValidateProfile(Issues);
	if (!Profile)
	{
		Issues.Add(NSLOCTEXT("AVS", "NullAnimationProfileEditor", "No Animation Profile was supplied."));
	}
	else
	{
		for (int32 Index = 0; Index < Profile->Animations.Num(); ++Index)
		{
			const FAVSNamedAnimation& Entry = Profile->Animations[Index];
			const TSoftObjectPtr<UAnimSequenceBase> Clips[] = { Entry.StartAnimation, Entry.Animation, Entry.EndAnimation };
			const TCHAR* Names[] = { TEXT("Start"), TEXT("Activity/Loop"), TEXT("End") };
			for (int32 ClipIndex = 0; ClipIndex < UE_ARRAY_COUNT(Clips); ++ClipIndex)
			{
				if (!Clips[ClipIndex].IsNull() && !Clips[ClipIndex].LoadSynchronous())
				{
					Issues.Add(FText::FromString(FString::Printf(TEXT("Animation row %d %s reference %s could not be loaded. Reassign a valid animation asset or clear the reference to use the configured fallback."),
						Index, Names[ClipIndex], *Clips[ClipIndex].ToSoftObjectPath().ToString())));
				}
			}
			if (Entry.Slot == EAVSAnimationSlot::Custom && Entry.CustomName.IsNone())
			{
				Issues.Add(FText::FromString(FString::Printf(TEXT("Animation row %d: name the Custom activity and use the same name on its POI/Idle Activity setting."), Index)));
			}
		}
		if (Profile->bUseSmoothMontageTransitions && Profile->MontageSlotName.IsNone())
		{
			Issues.Add(FText::FromString(TEXT("Set Montage Slot Name (normally DefaultSlot), register it in the Skeleton, and add that Slot node on the Animation Blueprint final pose path; or disable Smooth Montage Transitions.")));
		}
		bValid &= Issues.IsEmpty();
	}
	OutReport = IssuesToReport(Issues);
	return bValid;
}

bool UAVSArchvizEditorSubsystem::ValidateSceneProfiles(FString& OutReport) const
{
	return ValidateScene(GEditor ? GEditor->GetEditorWorldContext().World() : nullptr, OutReport);
}

bool UAVSArchvizEditorSubsystem::ValidateScene(UWorld* World, FString& OutReport) const
{
	if (!World || World->IsGameWorld())
	{
		OutReport = TEXT("[Error] Open an editor level and run Tools > AVS > Validate Scene / Profiles outside PIE.");
		return false;
	}
	TSet<UAVSCharacterProfile*> CharacterProfiles;
	TSet<UAVSAnimationProfile*> AnimationProfiles;
	TSet<UAVSCharacterLibrary*> Libraries;
	TArray<AAVSPointOfInterest*> POIs;
	TArray<FString> Messages;
	TSet<FString> CheckedPairs;
	int32 GeneratorCount = 0;
	int32 NPCCount = 0;
	int32 ControllerCount = 0;
	bool bViewerInvokerConfigured = false;
	auto CheckPair = [&](UAVSCharacterProfile* Character, UAVSAnimationProfile* Animation, const FString& Context)
	{
		if (Character) CharacterProfiles.Add(Character);
		if (Animation) AnimationProfiles.Add(Animation);
		if (!Character || !Animation)
		{
			Messages.Add(FString::Printf(TEXT("[Error] %s: assign both a Character Profile and an Animation Profile."), *Context));
			return;
		}
		const FString PairKey = Character->GetPathName() + TEXT("|") + Animation->GetPathName();
		if (CheckedPairs.Contains(PairKey)) return;
		CheckedPairs.Add(PairKey);
		if (!Animation->IsCompatibleWithCharacter(Character))
		{
			Messages.Add(FString::Printf(TEXT("[Error] %s: %s + %s is unusable. Match sex/rig tags and exact body Skeleton %s, then configure compatible standing Idle and Walk clips; use the scene retarget utility for source-Skeleton assets."),
				*Context, *Character->GetPathName(), *Animation->GetPathName(), *GetPathNameSafe(Character->ResolveAnimationSkeleton())));
		}
		ValidateMontageSetup(Character, Animation, Messages);
	};
	auto AddLibrary = [&](UAVSCharacterLibrary* Library)
	{
		if (!Library || Libraries.Contains(Library)) return;
		Libraries.Add(Library);
		FRandomStream LibraryStream(1337);
		UAVSCharacterProfile* CandidateCharacter = nullptr;
		UAVSAnimationProfile* CandidateAnimation = nullptr;
		if (!Library->SelectRandom(LibraryStream, CandidateCharacter, CandidateAnimation))
		{
			Messages.Add(FString::Printf(TEXT("[Error] %s: no enabled, positive-weight, compatible character/animation pair can be selected. Add a usable pair with compatible standing Idle and Walk."), *Library->GetPathName()));
		}
		for (int32 Index = 0; Index < Library->Characters.Num(); ++Index)
		{
			const FAVSCharacterLibraryEntry& Entry = Library->Characters[Index];
			if (Entry.bEnabled && Entry.Weight > 0.0f)
			{
				CheckPair(Entry.CharacterProfile, Entry.AnimationProfile,
					FString::Printf(TEXT("%s row %d"), *Library->GetPathName(), Index));
			}
		}
	};
	for (TActorIterator<AAVSCrowdGenerator> It(World); It; ++It)
	{
		AAVSCrowdGenerator* Generator = *It;
		++GeneratorCount;
		AddLibrary(Generator->CharacterLibrary);
		for (UAVSAnimationProfile* Animation : Generator->AnimationProfiles)
		{
			if (Animation) AnimationProfiles.Add(Animation);
		}
		for (UAVSCharacterProfile* Character : Generator->CharacterProfiles)
		{
			if (!Character) continue;
			CharacterProfiles.Add(Character);
			bool bHasCompatibleProfile = false;
			for (UAVSAnimationProfile* Animation : Generator->AnimationProfiles)
			{
				if (Animation && Animation->IsCompatibleWithCharacter(Character))
				{
					bHasCompatibleProfile = true;
					CheckPair(Character, Animation, Generator->GetPathName());
				}
			}
			if (!bHasCompatibleProfile && !Generator->CharacterLibrary)
			{
				Messages.Add(FString::Printf(TEXT("[Error] %s: Character Profile %s has no usable profile in Animation Profiles. Add a target-specific profile for Skeleton %s with compatible Idle and Walk."),
					*Generator->GetPathName(), *Character->GetPathName(), *GetPathNameSafe(Character->ResolveAnimationSkeleton())));
			}
		}
		if (Generator->bEnabled && Generator->GetEffectiveNPCCount() > 0 && !Generator->CharacterLibrary && Generator->CharacterProfiles.IsEmpty())
		{
			Messages.Add(FString::Printf(TEXT("[Error] %s: enabled generator has no Character Library or Character Profiles. Add at least one validated character/animation pair."), *Generator->GetPathName()));
		}
	}
	for (TActorIterator<AAVSArchvizNPCCharacter> It(World); It; ++It)
	{
		++NPCCount;
		CheckPair(It->DefaultCharacterProfile, It->DefaultAnimationProfile, It->GetPathName());
	}
	for (TActorIterator<AAVSCrowdGlobalController> It(World); It; ++It)
	{
		++ControllerCount;
		bViewerInvokerConfigured |= It->bEnableViewerNavigationInvoker;
	}
	if (ControllerCount > 1)
	{
		Messages.Add(TEXT("[Warning] Multiple AVS Global Controllers are present. Use one controller for predictable scene settings and the centralized viewer navigation invoker."));
	}
	for (TActorIterator<AAVSPointOfInterest> It(World); It; ++It) POIs.Add(*It);
	for (UAVSCharacterProfile* Profile : CharacterProfiles)
	{
		FString Report;
		if (!ValidateCharacterProfile(Profile, Report))
		{
			Messages.Add(FString::Printf(TEXT("[Error] Character Profile %s: %s"), *Profile->GetPathName(), *Report));
		}
	}
	for (UAVSAnimationProfile* Profile : AnimationProfiles)
	{
		FString Report;
		if (!ValidateAnimationProfile(Profile, Report))
		{
			Messages.Add(FString::Printf(TEXT("[Error] Animation Profile %s: %s"), *Profile->GetPathName(), *Report));
		}
	}
	UNavigationSystemV1* Navigation = UNavigationSystemV1::GetCurrent(World);
	ANavigationData* NavData = Navigation ? Navigation->GetDefaultNavDataInstance(FNavigationSystem::DontCreate) : nullptr;
	int32 BoundsCount = 0;
	for (TActorIterator<ANavMeshBoundsVolume> It(World); It; ++It) ++BoundsCount;
	const bool bNeedsNavigation = GeneratorCount > 0 || NPCCount > 0 || !POIs.IsEmpty();
	if (bNeedsNavigation && (!Navigation || !NavData || BoundsCount == 0))
	{
		Messages.Add(TEXT("[Error] Navigation is incomplete. Enable the Navigation System, place a NavMesh Bounds Volume covering the walking/POI area, and Build Paths. Press P to inspect walkable coverage; match the supported agent radius/height to the NPC capsule."));
	}
	bool bLocalNavigationOnly = false;
	if (Navigation)
	{
		if (const FBoolProperty* Property = FindFProperty<FBoolProperty>(Navigation->GetClass(), TEXT("bGenerateNavigationOnlyAroundNavigationInvokers")))
		{
			bLocalNavigationOnly = Property->GetPropertyValue_InContainer(Navigation);
		}
	}
	if (bViewerInvokerConfigured && NavData && NavData->GetRuntimeGenerationMode() != ERuntimeGenerationType::Dynamic)
	{
		Messages.Add(TEXT("[Error] AVS viewer navigation invoker is enabled but NavMesh Runtime Generation is not Dynamic. Set Project Settings > Navigation Mesh > Runtime Generation = Dynamic; Dynamic Modifiers Only cannot create missing tiles."));
	}
	if (bViewerInvokerConfigured && !bLocalNavigationOnly)
	{
		Messages.Add(TEXT("[Warning] AVS viewer navigation invoker is enabled, but Generate Navigation Only Around Navigation Invokers is disabled. Enable it in Project Settings > Navigation System for local generation, or disable the viewer invoker for a prebuilt whole-level NavMesh."));
	}
	if (bLocalNavigationOnly && !bViewerInvokerConfigured)
	{
		Messages.Add(TEXT("[Warning] Navigation generates only around invokers, but no AVS viewer invoker is configured. Enable it on one AVS Global Controller, or verify a project-owned invoker covers every active NPC/POI. Missing tiles cause requests to wait/back off."));
	}
	for (AAVSPointOfInterest* POI : POIs)
	{
		int32 UsableProfiles = 0;
		for (UAVSAnimationProfile* Profile : AnimationProfiles)
		{
			FRandomStream Stream(1337);
			FAVSNamedAnimation Entry;
			USkeleton* Skeleton = Profile->TargetSkeleton.LoadSynchronous();
			if (POI->ResolveRuntimeAnimation(Profile, Skeleton, Stream, Entry)) ++UsableProfiles;
			else
			{
				Messages.Add(FString::Printf(TEXT("[Warning] POI %s cannot serve Animation Profile %s. Configure its selected slot/name with a compatible loop or safe transition/hold combination, or use compatible Runtime Animation Overrides; check profile, row and POI reverse/hold switches."),
					*POI->GetPathName(), *Profile->GetPathName()));
			}
			if (POI->bUseRuntimeAnimationOverrides)
			{
				const TSoftObjectPtr<UAnimSequenceBase> Overrides[] = { POI->RuntimeStartAnimation, POI->RuntimeAnimation, POI->RuntimeEndAnimation };
				for (const TSoftObjectPtr<UAnimSequenceBase>& Override : Overrides)
				{
					if (UAnimSequenceBase* Clip = Override.LoadSynchronous())
					{
						if (Clip->GetSkeleton() != Skeleton)
						{
							Messages.Add(FString::Printf(TEXT("[Warning] POI %s override %s is ignored for %s because its Skeleton differs. Put target-specific clips in each profile for mixed male/female Skeletons; compatible profile clips are retained."),
								*POI->GetPathName(), *Clip->GetPathName(), *Profile->GetPathName()));
						}
					}
				}
			}
		}
		if (UsableProfiles == 0)
		{
			Messages.Add(FString::Printf(TEXT("[Error] POI %s has no usable runtime sequence in the scene profile pool. Preview-only animation fields do not enable runtime playback. Configure a scene Animation Profile or compatible runtime overrides."), *POI->GetPathName()));
		}
		if (POI->Capacity < 1 || !FMath::IsFinite(POI->ArrivalDistanceTolerance) || POI->ArrivalDistanceTolerance < 1.0f || POI->UseOffset.ContainsNaN())
		{
			Messages.Add(FString::Printf(TEXT("[Error] POI %s: set Capacity >= 1, Arrival Distance Tolerance >= 1 cm, and a finite Use Offset."), *POI->GetPathName()));
		}
		if (POI->Capacity > 1)
		{
			Messages.Add(FString::Printf(TEXT("[Warning] POI %s has Capacity > 1 but all users share one Use Offset. For distinct chairs/contact positions, place one Capacity 1 POI per position; collision can prevent simultaneous users from reaching a shared offset."), *POI->GetPathName()));
		}
		if (Navigation && NavData)
		{
			FNavLocation Projected;
			if (!Navigation->ProjectPointToNavigation(POI->GetUseLocation(), Projected, FVector(100.0f, 100.0f, 500.0f)))
			{
				Messages.Add(FString::Printf(TEXT("[%s] POI %s Use Offset is not on available NavMesh. Move it onto reachable floor coverage and Build Paths%s; runtime never teleports an NPC to this point."),
					bLocalNavigationOnly ? TEXT("Warning") : TEXT("Error"), *POI->GetPathName(), bLocalNavigationOnly ? TEXT(" or verify local tiles after the viewer approaches in PIE") : TEXT("")));
			}
			else if (FVector::DistSquared2D(Projected.Location, POI->GetUseLocation()) > FMath::Square(FMath::Max(1.0f, POI->ArrivalDistanceTolerance)))
			{
				Messages.Add(FString::Printf(TEXT("[Error] POI %s: nearest NavMesh point %s lies outside Arrival Distance Tolerance. Move Use Offset onto that walkable area or adjust the tolerance; the runtime cannot snap to the requested position."),
					*POI->GetPathName(), *Projected.Location.ToString()));
			}
		}
#if WITH_EDITORONLY_DATA
		if (!POI->bPreviewProfileDriven)
		{
			Messages.Add(FString::Printf(TEXT("[Warning] POI %s uses legacy POSE ONLY preview. Enable Profile Driven, choose the target Animation Profile, and inspect the full sequence to validate runtime contact/exit behavior."), *POI->GetPathName()));
		}
		else if (USkeletalMesh* PreviewMesh = POI->PreviewSkeletalMesh.LoadSynchronous())
		{
			UAVSAnimationProfile* PreviewProfile = POI->PreviewAnimationProfile.LoadSynchronous();
			FRandomStream Stream(1337);
			FAVSNamedAnimation Entry;
			if (!POI->ResolveRuntimeAnimation(PreviewProfile, PreviewMesh->GetSkeleton(), Stream, Entry))
			{
				Messages.Add(FString::Printf(TEXT("[Warning] POI %s preview profile/mesh cannot resolve the runtime row. Match their exact Skeletons and activity slot/name; inspect Preview Status in Details."), *POI->GetPathName()));
			}
		}
#endif
	}
	Messages.Sort();
	int32 ErrorCount = 0;
	int32 WarningCount = 0;
	for (const FString& Message : Messages)
	{
		ErrorCount += Message.StartsWith(TEXT("[Error]")) ? 1 : 0;
		WarningCount += Message.StartsWith(TEXT("[Warning]")) ? 1 : 0;
	}
	OutReport = FString::Printf(TEXT("AVS SCENE / PROFILES VALIDATION\nLevel: %s\n%d generator(s), %d placed NPC(s), %d POI(s), %d character profile(s), %d animation profile(s).\n%d error(s), %d warning(s).\n\n"),
		*World->GetName(), GeneratorCount, NPCCount, POIs.Num(), CharacterProfiles.Num(), AnimationProfiles.Num(), ErrorCount, WarningCount);
	OutReport += Messages.IsEmpty() ? TEXT("Validation passed. Verify animation contact poses, active montage Slot output, and real navigation in PIE before shipping.") : FString::Join(Messages, TEXT("\n\n"));
	UE_LOG(LogAVSArchvizCharacters, Display, TEXT("%s"), *OutReport);
	return ErrorCount == 0;
}

FString UAVSArchvizEditorSubsystem::BuildRetargetingChecklist(UAVSAnimationProfile* Profile) const
{
	FString Report = TEXT("AVS RETARGETING CHECKLIST") LINE_TERMINATOR;
	Report += TEXT("1. Create an IK Rig for the source Skeleton.") LINE_TERMINATOR;
	Report += TEXT("2. Create an IK Rig for the target modular-body Skeleton.") LINE_TERMINATOR;
	Report += TEXT("3. Create an IK Retargeter and map the Retarget Root and chains.") LINE_TERMINATOR;
	Report += TEXT("4. On the AVS Global Controller, add Source Mesh, Target Mesh and IK Retargeter to Retarget Pairs.") LINE_TERMINATOR;
	Report += TEXT("5. Choose Retarget Output Folder and press Execute One-Click Scene Retarget.") LINE_TERMINATOR;
	Report += TEXT("6. Preview Idle, Walk and Run and correct the IK Retargeter pose if required.") LINE_TERMINATOR;
	Report += TEXT("7. After source/profile changes, press Update / Rebuild Generated Retargets.") LINE_TERMINATOR;
	Report += TEXT("8. Source animations are never overwritten; only AVSRTG_ assets in the output folder are managed.") LINE_TERMINATOR;
	if (Profile)
	{
		TArray<FText> Issues;
		Profile->ValidateProfile(Issues);
		Report += LINE_TERMINATOR TEXT("CURRENT PROFILE") LINE_TERMINATOR;
		Report += IssuesToReport(Issues);
	}
	return Report;
}

FString UAVSArchvizEditorSubsystem::RunSceneRetarget(AAVSCrowdGlobalController* Controller, bool bUpdateExisting)
{
#if !WITH_EDITORONLY_DATA
	return TEXT("The AVS retarget utility is available only in the Unreal Editor.");
#else
	if (!Controller || !Controller->GetWorld())
	{
		return TEXT("Retarget failed: the AVS Global Controller is not in a valid editor world.");
	}

	FString OutputRoot = Controller->RetargetOutputFolder.Path;
	OutputRoot.TrimStartAndEndInline();
	while (OutputRoot.EndsWith(TEXT("/")))
	{
		OutputRoot.LeftChopInline(1);
	}
	if (!OutputRoot.StartsWith(TEXT("/Game/")) || !FPackageName::IsValidLongPackageName(OutputRoot))
	{
		return TEXT("Retarget failed: Retarget Output Folder must be a valid Content path below /Game, for example /Game/AVS/GeneratedRetargeted.");
	}

	UWorld* World = Controller->GetWorld();
	TArray<AAVSCrowdGenerator*> Generators;
	TArray<AAVSArchvizNPCCharacter*> NPCs;
	TSet<UAVSCharacterLibrary*> Libraries;
	TSet<UAVSCharacterProfile*> CharacterProfiles;
	TSet<UAVSAnimationProfile*> SourceProfiles;

	auto AddAnimationProfile = [&SourceProfiles](UAVSAnimationProfile* Profile)
	{
		if (UAVSAnimationProfile* Original = ResolveOriginalProfile(Profile))
		{
			SourceProfiles.Add(Original);
		}
	};
	auto AddLibrary = [&Libraries, &CharacterProfiles, &AddAnimationProfile](UAVSCharacterLibrary* Library)
	{
		if (!Library || Libraries.Contains(Library))
		{
			return;
		}
		Libraries.Add(Library);
		for (const FAVSCharacterLibraryEntry& Entry : Library->Characters)
		{
			if (Entry.CharacterProfile)
			{
				CharacterProfiles.Add(Entry.CharacterProfile);
			}
			AddAnimationProfile(Entry.AnimationProfile);
		}
	};

	for (TActorIterator<AAVSCrowdGenerator> It(World); It; ++It)
	{
		AAVSCrowdGenerator* Generator = *It;
		Generators.Add(Generator);
		for (UAVSCharacterProfile* Profile : Generator->CharacterProfiles)
		{
			if (Profile)
			{
				CharacterProfiles.Add(Profile);
			}
		}
		for (UAVSAnimationProfile* Profile : Generator->AnimationProfiles)
		{
			AddAnimationProfile(Profile);
		}
		AddLibrary(Generator->CharacterLibrary);
	}

	for (TActorIterator<AAVSArchvizNPCCharacter> It(World); It; ++It)
	{
		AAVSArchvizNPCCharacter* NPC = *It;
		NPCs.Add(NPC);
		if (NPC->DefaultCharacterProfile)
		{
			CharacterProfiles.Add(NPC->DefaultCharacterProfile);
		}
		AddAnimationProfile(NPC->DefaultAnimationProfile);
	}

	if (CharacterProfiles.IsEmpty() || SourceProfiles.IsEmpty())
	{
		return FString::Printf(TEXT("Nothing to retarget. Scene scan found %d Character Profile(s) and %d source Animation Profile(s). Add profiles to an AVS generator, Character Library, or placed AVS NPC."),
			CharacterProfiles.Num(), SourceProfiles.Num());
	}

	const FScopedTransaction Transaction(bUpdateExisting
		? NSLOCTEXT("AVS", "UpdateSceneRetarget", "Update AVS Generated Retargets")
		: NSLOCTEXT("AVS", "ExecuteSceneRetarget", "Execute AVS Scene Retarget"));

	TArray<FString> Messages;
	TSet<FString> ExpectedGeneratedPackages;
	TSet<UPackage*> PackagesToSave;
	TMap<FString, UAnimSequenceBase*> RetargetedAnimationCache;
	TMap<FString, FRetargetedProfileResult> ProfileResults;
	int32 CreatedAnimationCount = 0;
	int32 ReusedAnimationCount = 0;
	int32 CreatedProfileCount = 0;
	int32 UpdatedReferenceCount = 0;
	int32 FailureCount = 0;
	const FString UpdateRunSuffix = bUpdateExisting
		? FString::Printf(TEXT("_U%08X"), FCrc::StrCrc32(*FDateTime::UtcNow().ToString()))
		: FString();

	auto RetargetAnimation = [&](UAnimSequenceBase* SourceAnimation, USkeletalMesh* TargetMesh) -> UAnimSequenceBase*
	{
		if (!SourceAnimation || !TargetMesh || !TargetMesh->GetSkeleton())
		{
			return nullptr;
		}
		if (SourceAnimation->GetSkeleton() == TargetMesh->GetSkeleton())
		{
			return SourceAnimation;
		}

		const FString CacheKey = SourceAnimation->GetPathName() + TEXT("|") + TargetMesh->GetSkeleton()->GetPathName();
		if (UAnimSequenceBase* const* Cached = RetargetedAnimationCache.Find(CacheKey))
		{
			return *Cached;
		}

		const FAVSRetargetPair* MatchingPair = nullptr;
		USkeletalMesh* SourceMesh = nullptr;
		UIKRetargeter* Retargeter = nullptr;
		for (const FAVSRetargetPair& Pair : Controller->RetargetPairs)
		{
			if (!Pair.bEnabled)
			{
				continue;
			}
			USkeletalMesh* CandidateSource = Pair.SourceMesh.LoadSynchronous();
			USkeletalMesh* CandidateTarget = Pair.TargetMesh.LoadSynchronous();
			if (!CandidateSource || !CandidateTarget || CandidateSource->GetSkeleton() != SourceAnimation->GetSkeleton() ||
				CandidateTarget->GetSkeleton() != TargetMesh->GetSkeleton())
			{
				continue;
			}
			UIKRetargeter* CandidateRetargeter = Cast<UIKRetargeter>(Pair.IKRetargeter.LoadSynchronous());
			if (CandidateRetargeter)
			{
				MatchingPair = &Pair;
				SourceMesh = CandidateSource;
				Retargeter = CandidateRetargeter;
				break;
			}
		}

		if (!MatchingPair || !SourceMesh || !Retargeter)
		{
			++FailureCount;
			Messages.Add(FString::Printf(TEXT("Missing Retarget Pair: %s -> %s (needed by %s)."),
				*GetNameSafe(SourceAnimation->GetSkeleton()), *GetNameSafe(TargetMesh->GetSkeleton()), *SourceAnimation->GetName()));
			RetargetedAnimationCache.Add(CacheKey, nullptr);
			return nullptr;
		}

		const FString TargetToken = MakeSafeAssetName(TargetMesh->GetName());
		const FString Prefix = FString::Printf(TEXT("AVSRTG_%s__"), *TargetToken);
		const FString HashSuffix = FString::Printf(TEXT("_%08X"), FCrc::StrCrc32(*SourceAnimation->GetPathName()));
		const FString OutputName = Prefix + MakeSafeAssetName(SourceAnimation->GetName()) + HashSuffix + UpdateRunSuffix;
		const FString AnimationFolder = OutputRoot + TEXT("/Animations/") + TargetToken;
		const FString OutputPackage = AnimationFolder + TEXT("/") + OutputName;
		ExpectedGeneratedPackages.Add(OutputPackage);

		if (!bUpdateExisting)
		{
			if (UAnimSequenceBase* Existing = LoadAssetAtPackage<UAnimSequenceBase>(OutputPackage))
			{
				if (Existing->GetSkeleton() == TargetMesh->GetSkeleton())
				{
					++ReusedAnimationCount;
					RetargetedAnimationCache.Add(CacheKey, Existing);
					return Existing;
				}
			}
		}

		TArray<FAssetData> AssetsToRetarget;
		AssetsToRetarget.Emplace(SourceAnimation);
		const TArray<FAssetData> CreatedAssets = UIKRetargetBatchOperation::DuplicateAndRetarget(
			AssetsToRetarget,
			SourceMesh,
			TargetMesh,
			Retargeter,
			TEXT(""),
			TEXT(""),
			Prefix,
			HashSuffix + UpdateRunSuffix,
			false,
			false);

		UAnimSequenceBase* Result = nullptr;
		for (const FAssetData& AssetData : CreatedAssets)
		{
			if (UAnimSequenceBase* Candidate = Cast<UAnimSequenceBase>(AssetData.GetAsset()))
			{
				Result = Candidate;
				break;
			}
		}

		if (Result && Result->GetOutermost()->GetName() != OutputPackage)
		{
			FAssetToolsModule& AssetToolsModule = FModuleManager::LoadModuleChecked<FAssetToolsModule>(TEXT("AssetTools"));
			TArray<FAssetRenameData> RenameData;
			RenameData.Emplace(Result, AnimationFolder, OutputName);
			if (!AssetToolsModule.Get().RenameAssets(RenameData))
			{
				TArray<FAssetData> FailedTemporaryAssets;
				FailedTemporaryAssets.Emplace(Result);
				ObjectTools::DeleteAssets(FailedTemporaryAssets, false);
				Result = nullptr;
			}
		}

		if (!Result)
		{
			Result = LoadAssetAtPackage<UAnimSequenceBase>(OutputPackage);
		}

		if (!Result || Result->GetSkeleton() != TargetMesh->GetSkeleton())
		{
			++FailureCount;
			Messages.Add(FString::Printf(TEXT("Retarget failed: %s -> %s. Check the IK Retargeter chains and retarget poses."),
				*SourceAnimation->GetName(), *TargetMesh->GetName()));
			RetargetedAnimationCache.Add(CacheKey, nullptr);
			return nullptr;
		}

		++CreatedAnimationCount;
		PackagesToSave.Add(Result->GetOutermost());
		RetargetedAnimationCache.Add(CacheKey, Result);
		return Result;
	};

	FScopedSlowTask SlowTask(static_cast<float>(CharacterProfiles.Num() * SourceProfiles.Num()),
		NSLOCTEXT("AVS", "RetargetingSceneAnimations", "Scanning and retargeting AVS scene animations..."));
	SlowTask.MakeDialog(true);

	for (UAVSAnimationProfile* SourceProfile : SourceProfiles)
	{
		if (!SourceProfile)
		{
			continue;
		}
		for (UAVSCharacterProfile* CharacterProfile : CharacterProfiles)
		{
			SlowTask.EnterProgressFrame(1.0f, FText::FromString(FString::Printf(TEXT("%s -> %s"),
				*SourceProfile->GetName(), *GetNameSafe(CharacterProfile))));
			if (SlowTask.ShouldCancel() || !IsCompatibleIgnoringSkeleton(CharacterProfile, SourceProfile))
			{
				continue;
			}

			USkeletalMesh* TargetMesh = CharacterProfile->BodyMesh.LoadSynchronous();
			USkeleton* TargetSkeleton = TargetMesh ? TargetMesh->GetSkeleton() : nullptr;
			if (!TargetMesh || !TargetSkeleton)
			{
				++FailureCount;
				Messages.Add(FString::Printf(TEXT("Character Profile %s has no valid Body Mesh or Skeleton."), *CharacterProfile->GetName()));
				continue;
			}

			const FString Key = MakeProfileKey(SourceProfile, TargetSkeleton);
			if (ProfileResults.Contains(Key))
			{
				continue;
			}

			FRetargetedProfileResult ProfileResult;
			if (IsProfileAlreadyTargetCompatible(SourceProfile, TargetSkeleton))
			{
				TArray<FText> Issues;
				ProfileResult.Profile = SourceProfile;
				ProfileResult.bValid = SourceProfile->ValidateProfile(Issues);
				ProfileResults.Add(Key, ProfileResult);
				continue;
			}

			const uint32 ProfileHash = FCrc::StrCrc32(*(SourceProfile->GetPathName() + TargetSkeleton->GetPathName()));
			const FString ProfileName = FString::Printf(TEXT("AVSRTG_Profile__%s__%s_%08X"),
				*MakeSafeAssetName(SourceProfile->GetName()), *MakeSafeAssetName(TargetMesh->GetName()), ProfileHash);
			const FString ProfilePackageName = OutputRoot + TEXT("/Profiles/") + ProfileName;
			ExpectedGeneratedPackages.Add(ProfilePackageName);

			UAVSAnimationProfile* GeneratedProfile = LoadAssetAtPackage<UAVSAnimationProfile>(ProfilePackageName);
			if (!GeneratedProfile)
			{
				UPackage* Package = CreatePackage(*ProfilePackageName);
				GeneratedProfile = NewObject<UAVSAnimationProfile>(Package, *ProfileName,
					RF_Public | RF_Standalone | RF_Transactional);
				FAssetRegistryModule::AssetCreated(GeneratedProfile);
				++CreatedProfileCount;
			}
			GeneratedProfile->Modify();
			CopyProfileSettings(SourceProfile, GeneratedProfile);
			GeneratedProfile->TargetSkeleton = TargetSkeleton;
			GeneratedProfile->bGeneratedByAVSRetargetUtility = true;
			GeneratedProfile->RetargetSourceProfile = SourceProfile;
			GeneratedProfile->RetargetTargetMesh = TargetMesh;

			bool bAllRetargetsSucceeded = true;
			for (FAVSNamedAnimation& Entry : GeneratedProfile->Animations)
			{
				UAnimSequenceBase* SourceMain = Entry.Animation.LoadSynchronous();
				UAnimSequenceBase* SourceStart = Entry.StartAnimation.LoadSynchronous();
				UAnimSequenceBase* SourceEnd = Entry.EndAnimation.LoadSynchronous();
				if (SourceMain)
				{
					UAnimSequenceBase* Result = RetargetAnimation(SourceMain, TargetMesh);
					Entry.Animation = Result;
					bAllRetargetsSucceeded &= Result != nullptr;
				}
				if (SourceStart)
				{
					UAnimSequenceBase* Result = RetargetAnimation(SourceStart, TargetMesh);
					Entry.StartAnimation = Result;
					bAllRetargetsSucceeded &= Result != nullptr;
				}
				if (SourceEnd)
				{
					UAnimSequenceBase* Result = RetargetAnimation(SourceEnd, TargetMesh);
					Entry.EndAnimation = Result;
					bAllRetargetsSucceeded &= Result != nullptr;
				}
			}

			TArray<FText> Issues;
			ProfileResult.Profile = GeneratedProfile;
			ProfileResult.bValid = bAllRetargetsSucceeded && GeneratedProfile->ValidateProfile(Issues);
			GeneratedProfile->MarkPackageDirty();
			PackagesToSave.Add(GeneratedProfile->GetOutermost());
			if (!ProfileResult.bValid)
			{
				++FailureCount;
				Messages.Add(FString::Printf(TEXT("Generated profile %s is incomplete and was not assigned. %s"),
					*ProfileName, Issues.IsEmpty() ? TEXT("One or more retarget operations failed.") : *Issues[0].ToString()));
			}
			ProfileResults.Add(Key, ProfileResult);
		}
	}

	auto FindResult = [&ProfileResults](UAVSAnimationProfile* Profile, UAVSCharacterProfile* Character) -> UAVSAnimationProfile*
	{
		UAVSAnimationProfile* Source = ResolveOriginalProfile(Profile);
		USkeleton* Target = Character ? Character->ResolveAnimationSkeleton() : nullptr;
		if (!Source || !Target)
		{
			return nullptr;
		}
		if (const FRetargetedProfileResult* Result = ProfileResults.Find(MakeProfileKey(Source, Target)))
		{
			return Result->bValid ? Result->Profile : nullptr;
		}
		return nullptr;
	};

	for (AAVSCrowdGenerator* Generator : Generators)
	{
		if (!Generator)
		{
			continue;
		}
		TSet<UAVSCharacterProfile*> GeneratorCharacters;
		for (UAVSCharacterProfile* Character : Generator->CharacterProfiles)
		{
			if (Character)
			{
				GeneratorCharacters.Add(Character);
			}
		}
		if (Generator->CharacterLibrary)
		{
			for (const FAVSCharacterLibraryEntry& Entry : Generator->CharacterLibrary->Characters)
			{
				if (Entry.CharacterProfile)
				{
					GeneratorCharacters.Add(Entry.CharacterProfile);
				}
			}
		}
		if (GeneratorCharacters.IsEmpty())
		{
			continue;
		}

		TSet<UAVSAnimationProfile*> GeneratorSources;
		for (UAVSAnimationProfile* Profile : Generator->AnimationProfiles)
		{
			if (UAVSAnimationProfile* Source = ResolveOriginalProfile(Profile))
			{
				GeneratorSources.Add(Source);
			}
		}
		TArray<TObjectPtr<UAVSAnimationProfile>> NewProfiles;
		for (UAVSAnimationProfile* Source : GeneratorSources)
		{
			bool bResolvedAny = false;
			for (UAVSCharacterProfile* Character : GeneratorCharacters)
			{
				if (!IsCompatibleIgnoringSkeleton(Character, Source))
				{
					continue;
				}
				if (UAVSAnimationProfile* Result = FindResult(Source, Character))
				{
					NewProfiles.AddUnique(Result);
					bResolvedAny = true;
				}
			}
			if (!bResolvedAny)
			{
				NewProfiles.AddUnique(Source);
			}
		}
		if (NewProfiles != Generator->AnimationProfiles)
		{
			Generator->Modify();
			Generator->AnimationProfiles = MoveTemp(NewProfiles);
			Generator->MarkPackageDirty();
			PackagesToSave.Add(Generator->GetOutermost());
			++UpdatedReferenceCount;
		}
	}

	for (UAVSCharacterLibrary* Library : Libraries)
	{
		if (!Library)
		{
			continue;
		}
		for (FAVSCharacterLibraryEntry& Entry : Library->Characters)
		{
			if (UAVSAnimationProfile* Result = FindResult(Entry.AnimationProfile, Entry.CharacterProfile))
			{
				if (Result != Entry.AnimationProfile)
				{
					Library->Modify();
					Entry.AnimationProfile = Result;
					Library->MarkPackageDirty();
					PackagesToSave.Add(Library->GetOutermost());
					++UpdatedReferenceCount;
				}
			}
		}
	}

	for (AAVSArchvizNPCCharacter* NPC : NPCs)
	{
		if (!NPC)
		{
			continue;
		}
		if (UAVSAnimationProfile* Result = FindResult(NPC->DefaultAnimationProfile, NPC->DefaultCharacterProfile))
		{
			if (Result != NPC->DefaultAnimationProfile)
			{
				NPC->Modify();
				NPC->DefaultAnimationProfile = Result;
				NPC->MarkPackageDirty();
				PackagesToSave.Add(NPC->GetOutermost());
				++UpdatedReferenceCount;
			}
		}
	}

	int32 DeletedAssetCount = 0;
	if (bUpdateExisting && Controller->bDeleteUnusedGeneratedAssetsOnUpdate)
	{
		FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
		TArray<FString> PathsToScan;
		PathsToScan.Add(OutputRoot);
		AssetRegistryModule.Get().ScanPathsSynchronous(PathsToScan, true);
		TArray<FAssetData> FolderAssets;
		AssetRegistryModule.Get().GetAssetsByPath(FName(*OutputRoot), FolderAssets, true);
		TArray<FAssetData> StaleGeneratedAssets;
		for (const FAssetData& Asset : FolderAssets)
		{
			const FString PackageName = Asset.PackageName.ToString();
			if (Asset.AssetName.ToString().StartsWith(TEXT("AVSRTG_")) && !ExpectedGeneratedPackages.Contains(PackageName))
			{
				StaleGeneratedAssets.Add(Asset);
			}
		}
		if (!StaleGeneratedAssets.IsEmpty())
		{
			DeletedAssetCount = ObjectTools::DeleteAssets(StaleGeneratedAssets, false);
		}
	}

	if (!PackagesToSave.IsEmpty())
	{
		TArray<UPackage*> SaveList = PackagesToSave.Array();
		FEditorFileUtils::PromptForCheckoutAndSave(SaveList, true, false);
	}

	FString Report = FString::Printf(
		TEXT("AVS one-click retarget %s.\nScene: %d character profile(s), %d source animation profile(s).\nGenerated/rebuilt animations: %d; reused: %d; generated profiles: %d; reference sets updated: %d; stale generated assets deleted: %d; failures: %d."),
		bUpdateExisting ? TEXT("update finished") : TEXT("execute finished"), CharacterProfiles.Num(), SourceProfiles.Num(),
		CreatedAnimationCount, ReusedAnimationCount, CreatedProfileCount, UpdatedReferenceCount, DeletedAssetCount, FailureCount);
	if (!Messages.IsEmpty())
	{
		Report += TEXT("\n\nDetails:\n- ") + FString::Join(Messages, TEXT("\n- "));
	}
	if (FailureCount > 0)
	{
		Report += TEXT("\n\nNo failed generated profile was assigned. Add/fix the reported Retarget Pair and press Update again.");
	}
	return Report;
#endif
}
