#pragma once

#include "CoreMinimal.h"
#include "EditorSubsystem.h"
#include "AVSArchvizEditorSubsystem.generated.h"

class UAVSAnimationProfile;
class UAVSCharacterProfile;
class AAVSCrowdGlobalController;
class UWorld;

UCLASS()
class AVSARCHVIZCHARACTERSEDITOR_API UAVSArchvizEditorSubsystem : public UEditorSubsystem
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category="AVS|Validation")
	bool ValidateCharacterProfile(UAVSCharacterProfile* Profile, FString& OutReport) const;

	UFUNCTION(BlueprintCallable, Category="AVS|Validation")
	bool ValidateAnimationProfile(UAVSAnimationProfile* Profile, FString& OutReport) const;

	UFUNCTION(BlueprintCallable, Category="AVS|Validation", meta=(DisplayName="Validate Scene / Profiles", ToolTip="Read-only validation of the active editor world, scene profiles, usable POIs, NavMesh setup, modular Skeletons, and montage Slots. The Tools menu exposes the same action."))
	bool ValidateSceneProfiles(FString& OutReport) const;

	bool ValidateScene(UWorld* World, FString& OutReport) const;

	UFUNCTION(BlueprintCallable, Category="AVS|Retargeting")
	FString BuildRetargetingChecklist(UAVSAnimationProfile* Profile) const;

	FString RunSceneRetarget(AAVSCrowdGlobalController* Controller, bool bUpdateExisting);
};
