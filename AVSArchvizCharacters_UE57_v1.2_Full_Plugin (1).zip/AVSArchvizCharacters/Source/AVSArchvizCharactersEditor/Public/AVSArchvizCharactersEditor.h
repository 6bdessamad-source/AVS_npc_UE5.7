#pragma once

#include "Modules/ModuleManager.h"

class FAVSArchvizCharactersEditorModule final : public IModuleInterface
{
public:
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

private:
	FDelegateHandle RetargetRequestHandle;
};
