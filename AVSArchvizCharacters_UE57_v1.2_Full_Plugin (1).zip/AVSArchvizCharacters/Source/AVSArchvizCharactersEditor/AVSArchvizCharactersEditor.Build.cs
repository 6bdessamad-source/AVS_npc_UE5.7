using UnrealBuildTool;

public class AVSArchvizCharactersEditor : ModuleRules
{
    public AVSArchvizCharactersEditor(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

        PrivateDependencyModuleNames.AddRange(new string[]
        {
            "Core",
            "CoreUObject",
            "Engine",
            "EditorSubsystem",
            "UnrealEd",
            "ToolMenus",
            "NavigationSystem",
            "AnimGraphRuntime",
            "Slate",
            "SlateCore",
            "AssetRegistry",
            "AssetTools",
            "IKRig",
            "IKRigEditor",
            "AVSArchvizCharacters"
        });
    }
}
