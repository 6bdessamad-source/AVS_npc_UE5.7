using UnrealBuildTool;

public class AVSArchvizCharacters : ModuleRules
{
    public AVSArchvizCharacters(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

        PrivateDependencyModuleNames.Add("AnimGraphRuntime");
        PublicDependencyModuleNames.AddRange(new string[]
        {
            "Core",
            "CoreUObject",
            "Engine",
            "AIModule",
            "NavigationSystem",
            "GameplayTasks",
            "DeveloperSettings"
        });
    }
}
