#pragma once

#include "CoreMinimal.h"
#include "AVSCrowdGenerator.h"
#include "AVSCrowdRoute.generated.h"

class AAVSCrowdRoute;
class USplineComponent;

USTRUCT(BlueprintType)
struct AVSARCHVIZCHARACTERS_API FAVSRouteConnection
{
	GENERATED_BODY()

	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category="Route Network")
	TObjectPtr<AAVSCrowdRoute> TargetRoute = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Route Network", meta=(ClampMin="0"))
	int32 SourcePointIndex = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Route Network", meta=(ClampMin="0"))
	int32 TargetPointIndex = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Route Network", meta=(ClampMin="0.0"))
	float Weight = 1.0f;
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FAVSRouteNPCEvent, AAVSArchvizNPCCharacter*, NPC, AAVSCrowdRoute*, Route);

UCLASS(Blueprintable)
class AVSARCHVIZCHARACTERS_API AAVSCrowdRoute : public AAVSCrowdGenerator
{
	GENERATED_BODY()

public:
	AAVSCrowdRoute();

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="AVS|Route")
	TObjectPtr<USplineComponent> RouteSpline;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Route", meta=(ClampMin="50.0"))
	float RoutePointSpacing = 300.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Route")
	bool bLoopRoute = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Route",
		meta=(ToolTip="Path Only generates/controls its own walkers. Connector Only is selected by crowd zones and generates no walkers. Path + Connector supports both."))
	EAVSRoutePurpose RoutePurpose = EAVSRoutePurpose::PedestrianPath;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Route", meta=(ClampMin="0.0", ToolTip="Half the usable pedestrian lane width."))
	float LaneHalfWidth = 75.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Route|Couples")
	bool bEnableCouples = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Route|Couples", meta=(ClampMin="0.0", ClampMax="1.0", EditCondition="bEnableCouples"))
	float CoupleChance = 0.25f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Route|Couples", meta=(ClampMin="50.0", EditCondition="bEnableCouples"))
	float CoupleSpacing = 100.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Route|Couples", meta=(ClampMin="100.0", EditCondition="bEnableCouples", ToolTip="Couples are generated only if the full route width is at least this value."))
	float MinimumRouteWidthForCouples = 220.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Route|Couples", meta=(EditCondition="bEnableCouples"))
	EAVSCoupleGenderMode CoupleGenderMode = EAVSCoupleGenderMode::Any;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Route|Network", meta=(ToolTip="Finds nearby sampled points on other AVS Crowd Routes at Begin Play."))
	bool bAutoDiscoverRouteConnections = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Route|Network", meta=(ClampMin="10.0", EditCondition="bAutoDiscoverRouteConnections"))
	float ConnectionRadius = 250.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Route|Network", meta=(ClampMin="0.0", ClampMax="1.0"))
	float RouteTransferChance = 0.3f;

	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category="AVS|Route|Network")
	TArray<FAVSRouteConnection> ManualConnections;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Route|Zone Connector",
		meta=(EditCondition="RoutePurpose != EAVSRoutePurpose::PedestrianPath", ToolTip="Automatically finds every box or spline crowd zone touched by this route."))
	bool bAutoDiscoverConnectedCrowdZones = true;

	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category="AVS|Route|Zone Connector",
		meta=(EditCondition="RoutePurpose != EAVSRoutePurpose::PedestrianPath", ToolTip="Optional manual list. A connector may touch several crowd zones; its open end hands the NPC to the destination zone."))
	TArray<TObjectPtr<AAVSCrowdGenerator>> ConnectedCrowdZones;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Route|Social Safety",
		meta=(ToolTip="Nearby automatic conversations wait while this route has walkers."))
	bool bBlockNearbyConversationsWhileOccupied = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Route|Social Safety",
		meta=(ClampMin="0.0", Units="s", ToolTip="After leaving this route, an NPC waits this long before it may join an automatic conversation."))
	float ConversationReengageDelayAfterExit = 3.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Route|Open End", meta=(EditCondition="!bLoopRoute", ToolTip="Returns a pooled/generated NPC when it reaches the last point."))
	bool bDespawnAtEnd = false;

	UPROPERTY(BlueprintAssignable, Category="AVS|Route|Open End")
	FAVSRouteNPCEvent OnNPCReachedEnd;

	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category="AVS|Simple Path", meta=(ToolTip="Optional placed NPCs that should follow this spline. No crowd generation is required."))
	TArray<TObjectPtr<AAVSArchvizNPCCharacter>> PlacedNPCs;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Simple Path")
	bool bStartPlacedNPCsOnBeginPlay = true;

	UFUNCTION(BlueprintCallable, Category="AVS|Simple Path")
	void AssignNPCToRoute(AAVSArchvizNPCCharacter* NPC);

	UFUNCTION(BlueprintCallable, Category="AVS|Simple Path")
	void RemoveNPCFromRoute(AAVSArchvizNPCCharacter* NPC);

	UFUNCTION(BlueprintCallable, Category="AVS|Simple Path")
	void StartPlacedNPCs();

	UFUNCTION(BlueprintPure, Category="AVS|Route")
	int32 GetRoutePointCount() const;

	UFUNCTION(BlueprintPure, Category="AVS|Route")
	FVector GetRoutePoint(int32 PointIndex) const;

	UFUNCTION(BlueprintPure, Category="AVS|Route")
	FVector GetRouteRightVector(int32 PointIndex) const;

	UFUNCTION(BlueprintCallable, CallInEditor, Category="AVS|Route|Network")
	void RefreshRouteConnections();

	UFUNCTION(BlueprintCallable, CallInEditor, Category="AVS|Route|Zone Connector")
	void RefreshConnectedCrowdZones();

	UFUNCTION(BlueprintCallable, Category="AVS|Route|Open End")
	void SetDespawnAtEnd(bool bShouldDespawn) { bDespawnAtEnd = bShouldDespawn; }

	bool TrySelectTransfer(AAVSArchvizNPCCharacter* NPC, int32 SourcePointIndex, FRandomStream& Stream,
		AAVSCrowdRoute*& OutRoute, int32& OutTargetPointIndex) const;
	bool HandleNPCReachedEnd(AAVSArchvizNPCCharacter* NPC);
	bool CanConnectCrowdZones() const { return RoutePurpose != EAVSRoutePurpose::PedestrianPath; }
	bool IsLocationNearRoute(const FVector& WorldLocation, float ExtraClearance) const;
	virtual int32 GetEffectiveNPCCount() const override;

protected:
	virtual void OnConstruction(const FTransform& Transform) override;
	virtual void BeginPlay() override;
	virtual bool MakeSpawnTransform(int32 NPCIndex, FTransform& OutTransform) override;
	virtual void ConfigureSpawnedNPC(AAVSArchvizNPCCharacter* NPC, int32 NPCIndex) override;
	virtual void SelectProfiles(int32 NPCIndex, UAVSCharacterProfile*& OutCharacter, UAVSAnimationProfile*& OutAnimation) override;
	virtual void DrawGeneratorDebug(const FAVSViewerState& ViewerState) const override;

private:
	bool IsCouplePair(int32 PairIndex) const;
	float GetLaneOffsetForIndex(int32 NPCIndex) const;
	bool SelectCoupleCompatibleProfiles(const AAVSArchvizNPCCharacter* Partner,
		UAVSCharacterProfile*& OutCharacter, UAVSAnimationProfile*& OutAnimation);
	AAVSCrowdGenerator* FindDestinationCrowdZone(const AAVSArchvizNPCCharacter* NPC) const;

	UPROPERTY(Transient)
	TArray<FAVSRouteConnection> AutoConnections;

	UPROPERTY(Transient)
	TArray<TObjectPtr<AAVSCrowdGenerator>> AutoConnectedCrowdZones;

	TMap<int32, float> SpawnLateralOffsets;
};
