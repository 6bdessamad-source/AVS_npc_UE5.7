#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "AVSArchvizTypes.h"
#include "AVSArchvizSettings.h"
#include "AVSCrowdGlobalController.generated.h"

class UBillboardComponent;
class USkeletalMesh;
class AAVSCrowdGlobalController;

DECLARE_MULTICAST_DELEGATE_TwoParams(FAVSRetargetRequestDelegate, AAVSCrowdGlobalController*, bool);

USTRUCT(BlueprintType)
struct AVSARCHVIZCHARACTERS_API FAVSRetargetPair
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Retarget")
	bool bEnabled = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Retarget", meta=(ToolTip="Representative mesh for the Skeleton used by the source animations."))
	TSoftObjectPtr<USkeletalMesh> SourceMesh;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Retarget", meta=(ToolTip="Representative mesh for the destination Skeleton. Any scanned AVS body using the same Skeleton can use this pair."))
	TSoftObjectPtr<USkeletalMesh> TargetMesh;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Retarget",
		meta=(AllowedClasses="/Script/IKRig.IKRetargeter", ToolTip="IK Retargeter configured from Source Mesh to Target Mesh. Auto-chain generation cannot safely replace this for an unknown custom rig."))
	TSoftObjectPtr<UObject> IKRetargeter;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Retarget", meta=(ToolTip="Optional IK Retargeter override sets applied during export."))
	TArray<FName> OverrideSetNames;
};

UCLASS(Blueprintable)
class AVSARCHVIZCHARACTERS_API AAVSCrowdGlobalController : public AActor
{
	GENERATED_BODY()

public:
	AAVSCrowdGlobalController();

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="AVS")
	TObjectPtr<USceneComponent> SceneRoot;

#if WITH_EDITORONLY_DATA
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="AVS|Editor")
	TObjectPtr<UBillboardComponent> EditorBillboard;
#endif

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Global")
	bool bCrowdEnabled = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Global")
	EAVSGlobalQualityPreset QualityPreset = EAVSGlobalQualityPreset::Balanced;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Global", meta=(ClampMin="0.0", ClampMax="2.0"))
	float DensityScale = 0.75f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Global", meta=(ClampMin="1"))
	int32 MaxActiveNPCs = 100;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Global", meta=(ClampMin="0"))
	int32 WarmPoolSize = 12;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Global", meta=(ClampMin="0.05"))
	float EvaluationInterval = 0.5f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Navigation|Local Generation",
		meta=(ToolTip="Creates one transient Navigation Invoker at the real viewer/camera location. Requires a NavMesh Bounds Volume covering the possible area, Runtime Generation = Dynamic, and Generate Navigation Only Around Navigation Invokers in Project Settings."))
	bool bEnableViewerNavigationInvoker = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Navigation|Local Generation",
		meta=(ClampMin="500.0", Units="cm", EditCondition="bEnableViewerNavigationInvoker", ToolTip="Local NavMesh radius while the viewer is in Walking mode. Keep this slightly larger than the active pedestrian area around the viewer."))
	float WalkingNavigationGenerationRadius = 12000.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Navigation|Local Generation",
		meta=(ClampMin="500.0", Units="cm", EditCondition="bEnableViewerNavigationInvoker", ToolTip="Local NavMesh radius while the viewer is in Orbit mode. Reduce the route/generator activation radii too if this value is reduced."))
	float OrbitNavigationGenerationRadius = 32000.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Navigation|Local Generation",
		meta=(ClampMin="100.0", Units="cm", EditCondition="bEnableViewerNavigationInvoker", ToolTip="Extra radius retained behind the viewer to avoid regenerating tiles after small camera movements."))
	float NavigationRemovalRadiusPadding = 4000.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Navigation|Local Generation",
		meta=(ClampMin="0.0", Units="cm", EditCondition="bEnableViewerNavigationInvoker", ToolTip="The transient invoker moves only after the viewer exceeds this distance. Larger values reduce navigation tile churn."))
	float NavigationInvokerMoveThreshold = 500.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Navigation|Path Requests",
		meta=(ToolTip="Suppresses identical MoveTo requests for a short interval. New route points and significantly moved Follow targets still request a path immediately."))
	bool bOptimizeRepeatedPathRequests = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Navigation|Path Requests",
		meta=(ClampMin="0.1", Units="s", EditCondition="bOptimizeRepeatedPathRequests"))
	float MinimumPathRequestInterval = 1.5f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Navigation|Path Requests",
		meta=(ClampMin="1.0", Units="cm", EditCondition="bOptimizeRepeatedPathRequests"))
	float PathDestinationChangeThreshold = 150.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Navigation|Geometry Filter",
		meta=(ToolTip="Collision channel used by Apply Navigation Channel Filter. Components that do not Block this channel are made navigation-irrelevant. Create a custom AVSNav trace channel for precise control."))
	TEnumAsByte<ECollisionChannel> NavigationGeometryChannel = ECC_Visibility;

#if WITH_EDITORONLY_DATA
	UPROPERTY(VisibleAnywhere, Transient, Category="AVS|Navigation|Geometry Filter", meta=(MultiLine="true"))
	FString LastNavigationFilterReport;
#endif

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Graphics")
	bool bAllowShadows = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Graphics")
	bool bAllowCollision = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Graphics")
	bool bEnableAnimationUpdateRateOptimization = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Graphics")
	bool bAllowLightweightAvoidance = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Graphics", meta=(ClampMin="0.0", ToolTip="Zero lets each distance tier decide."))
	float GlobalMaxDrawDistance = 0.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Graphics")
	TArray<FAVSQualityTier> QualityTiers;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Social Conversations",
		meta=(ToolTip="Periodically forms lightweight conversation groups from nearby Idle or Wander NPCs."))
	bool bEnableProximityConversations = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Ambient Activities", meta=(ToolTip="Use these category weights instead of Project Settings. A zone or character override still takes precedence."))
	bool bOverrideAmbientActivityWeights = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Ambient Activities", meta=(EditCondition="bOverrideAmbientActivityWeights"))
	FAVSAmbientActivityWeights AmbientActivityWeights;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Social Conversations", meta=(ToolTip="Use the complete percentage/cadence/category configuration below instead of the legacy formation/radius/duration controls. Zone overrides still take precedence."))
	bool bOverrideConversationSettings = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Social Conversations", meta=(EditCondition="bOverrideConversationSettings"))
	FAVSConversationSettings Conversations;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Social Conversations",
		meta=(ClampMin="50.0", Units="cm", EditCondition="bEnableProximityConversations"))
	float ConversationDetectionRadius = 260.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Social Conversations",
		meta=(ClampMin="0.0", ClampMax="1.0", EditCondition="bEnableProximityConversations", ToolTip="Chance for each eligible nearby group to start during one global evaluation. Lower this if conversations form too often."))
	float ConversationStartChancePerEvaluation = 0.15f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Social Conversations",
		meta=(ClampMin="2", ClampMax="8", EditCondition="bEnableProximityConversations"))
	int32 MaxConversationGroupSize = 4;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Social Conversations",
		meta=(ClampMin="1", ClampMax="32", EditCondition="bEnableProximityConversations", ToolTip="Performance guard limiting how many new groups may be formed in one evaluation."))
	int32 MaxNewConversationsPerEvaluation = 4;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Social Conversations",
		meta=(ClampMin="0.1", Units="s", EditCondition="bEnableProximityConversations"))
	float MinConversationDuration = 6.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Social Conversations",
		meta=(ClampMin="0.1", Units="s", EditCondition="bEnableProximityConversations"))
	float MaxConversationDuration = 18.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Social Conversations",
		meta=(ClampMin="0.0", Units="s", EditCondition="bEnableProximityConversations"))
	float MinConversationCooldown = 12.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Social Conversations",
		meta=(ClampMin="0.0", Units="s", EditCondition="bEnableProximityConversations"))
	float MaxConversationCooldown = 30.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Social Conversations",
		meta=(ClampMin="0.0", Units="s", EditCondition="bEnableProximityConversations", ToolTip="Minimum pause after leaving a conversation before the NPC starts wandering."))
	float MinPostConversationIdleTime = 0.75f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Social Conversations",
		meta=(ClampMin="0.0", Units="s", EditCondition="bEnableProximityConversations", ToolTip="Maximum pause after leaving a conversation before the NPC starts wandering."))
	float MaxPostConversationIdleTime = 2.5f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Social Conversations",
		meta=(ClampMin="0.0", EditCondition="bEnableProximityConversations", ToolTip="How quickly participants turn toward the average position of the other people in their group."))
	float ConversationFacingInterpSpeed = 3.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Social Conversations",
		meta=(EditCondition="bEnableProximityConversations", ToolTip="Prevents nearby Idle/Wander NPCs from starting a conversation beside a route that currently has walkers."))
	bool bWaitForOccupiedRoutesBeforeConversation = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Social Conversations",
		meta=(ClampMin="0.0", Units="cm", EditCondition="bEnableProximityConversations && bWaitForOccupiedRoutesBeforeConversation"))
	float OccupiedRouteConversationClearance = 220.0f;

#if WITH_EDITORONLY_DATA
	UPROPERTY(EditAnywhere, Category="AVS|Editor Retarget", meta=(ContentDir, LongPackageName,
		ToolTip="Content Browser folder that receives only AVS-generated profiles and retargeted animations."))
	FDirectoryPath RetargetOutputFolder;

	UPROPERTY(EditAnywhere, Category="AVS|Editor Retarget", meta=(TitleProperty="TargetMesh",
		ToolTip="Add one row per source-Skeleton to target-Skeleton combination. Execute scans the active scene; these rows provide the bone-chain mapping Unreal cannot infer safely for every custom rig."))
	TArray<FAVSRetargetPair> RetargetPairs;

	UPROPERTY(EditAnywhere, Category="AVS|Editor Retarget", meta=(ToolTip="Update removes stale AVSRTG_ assets only inside Retarget Output Folder. Source assets are never deleted."))
	bool bDeleteUnusedGeneratedAssetsOnUpdate = true;

	UPROPERTY(VisibleAnywhere, Transient, Category="AVS|Editor Retarget", meta=(MultiLine="true"))
	FString LastRetargetReport;
#endif

	UFUNCTION(BlueprintCallable, CallInEditor, Category="AVS|Global")
	void ApplySelectedQualityPreset();

	UFUNCTION(CallInEditor, Category="AVS|Navigation|Geometry Filter",
		meta=(DisplayName="Apply Navigation Collision Channel Filter", ToolTip="One-time editor operation. Disables Can Ever Affect Navigation on placed primitive components that do not Block Navigation Geometry Channel. It never enables navigation on a component."))
	void ApplyNavigationCollisionChannelFilter();

	UFUNCTION(CallInEditor, Category="AVS|Editor Retarget",
		meta=(DisplayName="Execute One-Click Scene Retarget", ToolTip="Scans this editor world, creates missing target-specific assets, and updates AVS scene references."))
	void ExecuteOneClickSceneRetarget();

	UFUNCTION(CallInEditor, Category="AVS|Editor Retarget",
		meta=(DisplayName="Update / Rebuild Generated Retargets", ToolTip="Rescans, overwrites generated assets, creates new ones, and deletes unused AVSRTG_ assets from the selected output folder."))
	void UpdateGeneratedRetargets();

	static FAVSRetargetRequestDelegate& OnRetargetRequested();

	UFUNCTION(BlueprintCallable, Category="AVS|Global")
	void SetGlobalCrowdEnabled(bool bEnabled);

	UFUNCTION(BlueprintCallable, Category="AVS|Global")
	void SetGlobalDensityScale(float NewScale);

	UFUNCTION(BlueprintCallable, Category="AVS|Global")
	void ClearAllGeneratedCrowds();

	UFUNCTION(BlueprintPure, Category="AVS|Global")
	int32 GetActiveNPCCount() const;

	UFUNCTION(BlueprintPure, Category="AVS|Global")
	int32 GetPooledNPCCount() const;

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	void BuildPreset(EAVSGlobalQualityPreset Preset);
};
