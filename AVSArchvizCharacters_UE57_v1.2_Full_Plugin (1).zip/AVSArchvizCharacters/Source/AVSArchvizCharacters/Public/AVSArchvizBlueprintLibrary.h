#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "AVSArchvizBlueprintLibrary.generated.h"

class UAVSAnimationProfile;
class UAVSCharacterProfile;
class UAVSCrowdSubsystem;
class USkeletalMesh;

UCLASS()
class AVSARCHVIZCHARACTERS_API UAVSArchvizBlueprintLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintPure, Category="AVS|Crowd", meta=(WorldContext="WorldContextObject"))
	static UAVSCrowdSubsystem* GetAVSCrowdSubsystem(const UObject* WorldContextObject);

	UFUNCTION(BlueprintPure, Category="AVS|Validation")
	static bool DoMeshesUseSameSkeleton(const USkeletalMesh* A, const USkeletalMesh* B);

	UFUNCTION(BlueprintCallable, Category="AVS|Validation")
	static bool ValidateCharacterProfile(const UAVSCharacterProfile* Profile, TArray<FText>& OutIssues);

	UFUNCTION(BlueprintCallable, Category="AVS|Validation")
	static bool ValidateAnimationProfile(const UAVSAnimationProfile* Profile, TArray<FText>& OutIssues);

	UFUNCTION(BlueprintPure, Category="AVS|Debug", meta=(WorldContext="WorldContextObject"))
	static FString GetCrowdDebugSummary(const UObject* WorldContextObject);
};
