#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "AVSArchvizTypes.h"
#include "AVSArchvizNPCCharacter.generated.h"

class UAVSAnimationDriverComponent;
class UAVSAnimationProfile;
class UAVSCharacterProfile;
class UAVSModularCharacterComponent;
class UAVSNPCBehaviorComponent;
class UBillboardComponent;

UCLASS(Blueprintable)
class AVSARCHVIZCHARACTERS_API AAVSArchvizNPCCharacter : public ACharacter
{
	GENERATED_BODY()

public:
	AAVSArchvizNPCCharacter();

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="AVS")
	TObjectPtr<UAVSModularCharacterComponent> ModularCharacter;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="AVS")
	TObjectPtr<UAVSAnimationDriverComponent> AnimationDriver;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="AVS")
	TObjectPtr<UAVSNPCBehaviorComponent> Behavior;

#if WITH_EDITORONLY_DATA
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="AVS|Editor")
	TObjectPtr<UBillboardComponent> EditorBillboard;
#endif

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="AVS|Profiles")
	TObjectPtr<UAVSCharacterProfile> DefaultCharacterProfile = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="AVS|Profiles")
	TObjectPtr<UAVSAnimationProfile> DefaultAnimationProfile = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Avoidance")
	bool bEnableLightweightAvoidance = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Avoidance", meta=(ClampMin="50.0", EditCondition="bEnableLightweightAvoidance"))
	float AvoidanceConsiderationRadius = 180.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Avoidance", meta=(ClampMin="0.0", ClampMax="1.0", EditCondition="bEnableLightweightAvoidance"))
	float AvoidanceWeight = 0.35f;

	UFUNCTION(BlueprintCallable, Category="AVS|NPC")
	void InitializeNPC(const FAVSSpawnRequest& Request);

	UFUNCTION(BlueprintCallable, Category="AVS|NPC")
	bool ApplyProfiles(UAVSCharacterProfile* CharacterProfile, UAVSAnimationProfile* AnimationProfile);

	UFUNCTION(BlueprintCallable, Category="AVS|NPC")
	void SetPooled(bool bPooled);

	UFUNCTION(BlueprintCallable, Category="AVS|NPC")
	void ApplyQualityTier(const FAVSQualityTier& Tier);

	UFUNCTION(BlueprintCallable, Category="AVS|Avoidance")
	void RefreshAvoidanceSettings(bool bQualityAllowsAvoidance = true);

	UFUNCTION(BlueprintPure, Category="AVS|NPC")
	AActor* GetOwningGenerator() const { return OwningGenerator.Get(); }

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	TWeakObjectPtr<AActor> OwningGenerator;
	bool bIsPooled = false;
	bool bQualitySuspended = false;
	EAVSNPCState StateBeforeQualityPause = EAVSNPCState::Idle;
};
