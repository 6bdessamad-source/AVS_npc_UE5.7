#pragma once

#include "CoreMinimal.h"
#include "AIController.h"
#include "AVSArchvizNPCAIController.generated.h"

class UBehaviorTree;
class UAVSAnimationProfile;
class UAVSCharacterLibrary;
class UAVSCharacterProfile;

UCLASS(Blueprintable)
class AVSARCHVIZCHARACTERS_API AAVSArchvizNPCAIController : public AAIController
{
	GENERATED_BODY()

public:
	AAVSArchvizNPCAIController();
	virtual FPathFollowingRequestResult MoveTo(const FAIMoveRequest& MoveRequest, FNavPathSharedPtr* OutPath = nullptr) override;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="AVS|Behavior Tree")
	TObjectPtr<UBehaviorTree> BehaviorTreeAsset = nullptr;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="AVS|Behavior Tree")
	bool bRunBehaviorTreeOnPossess = true;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="AVS|Behavior Tree")
	bool bStartWanderingWithoutBehaviorTree = true;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="AVS|Behavior Tree", meta=(ClampMin="0.0", EditCondition="bStartWanderingWithoutBehaviorTree"))
	float DefaultWanderRadius = 1000.0f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="AVS|Profiles")
	bool bAutoSelectCompatibleProfilesOnPossess = false;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="AVS|Profiles", meta=(EditCondition="bAutoSelectCompatibleProfilesOnPossess"))
	bool bOverridePawnDefaultProfiles = false;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="AVS|Profiles", meta=(EditCondition="bAutoSelectCompatibleProfilesOnPossess"))
	TObjectPtr<UAVSCharacterLibrary> CharacterLibrary = nullptr;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="AVS|Profiles", meta=(EditCondition="bAutoSelectCompatibleProfilesOnPossess"))
	TArray<TObjectPtr<UAVSCharacterProfile>> CharacterProfiles;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="AVS|Profiles", meta=(EditCondition="bAutoSelectCompatibleProfilesOnPossess"))
	TArray<TObjectPtr<UAVSAnimationProfile>> AnimationProfiles;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="AVS|Profiles", meta=(EditCondition="bAutoSelectCompatibleProfilesOnPossess"))
	int32 RandomSeed = 1337;

	UFUNCTION(BlueprintCallable, Category="AVS|Profiles")
	bool ApplyRandomCompatibleProfiles();

protected:
	virtual void OnPossess(APawn* InPawn) override;

private:
	UAVSCharacterProfile* SelectCharacterProfile(FRandomStream& Stream) const;
	UAVSAnimationProfile* SelectCompatibleAnimation(const UAVSCharacterProfile* CharacterProfile, FRandomStream& Stream) const;
};
