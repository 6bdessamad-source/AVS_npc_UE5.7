#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "AVSArchvizTypes.h"
#include "AVSComposedAnimationPolicy.h"
#include "AVSPointOfInterest.generated.h"

class UBillboardComponent;
class UAnimSequenceBase;
class UPrimitiveComponent;
class USkeletalMesh;
class USkeletalMeshComponent;
class USphereComponent;
class USkeleton;
class UAVSAnimationProfile;
struct FAVSNamedAnimation;

UCLASS(Blueprintable)
class AVSARCHVIZCHARACTERS_API AAVSPointOfInterest : public AActor
{
	GENERATED_BODY()

public:
	AAVSPointOfInterest();
	virtual void Tick(float DeltaSeconds) override;

	UFUNCTION(CallInEditor, Category="AVS|Editor Preview", meta=(DisplayName="Refresh / Restart Preview", ToolTip="Reload the current profile and runtime override settings, then restart the resolved sequence. Useful after editing a referenced profile."))
	void RestartEditorPreview();

	UFUNCTION(CallInEditor, Category="AVS|Editor Preview", meta=(DisplayName="Preview Exit / Get Up", ToolTip="Request the shared sequence exit, including from a caller-owned indefinite hold. Entry cancellation retraces a safe synthesized segment or completes contact before a supplied exit."))
	void RequestEditorPreviewExit();
#if WITH_EDITOR
	virtual bool ShouldTickIfViewportsOnly() const override;
#endif

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="AVS|POI")
	TObjectPtr<USceneComponent> SceneRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="AVS|POI|Automatic Trigger")
	TObjectPtr<USphereComponent> AutoTrigger;

#if WITH_EDITORONLY_DATA
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="AVS|Editor")
	TObjectPtr<UBillboardComponent> EditorBillboard;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="AVS|Editor Preview")
	TObjectPtr<USkeletalMeshComponent> EditorPreviewMesh;

	UPROPERTY(EditAnywhere, Category="AVS|Editor Preview", meta=(ToolTip="Editor-only body used to preview the POI pose. It is never cooked or shown in game."))
	TSoftObjectPtr<USkeletalMesh> PreviewSkeletalMesh;

	UPROPERTY(EditAnywhere, Category="AVS|Editor Preview", meta=(ToolTip="Recommended: preview exactly the selected runtime profile row and compatible runtime overrides. Legacy Preview Animation fields below are ignored in this mode."))
	bool bPreviewProfileDriven = true;

	UPROPERTY(EditAnywhere, Category="AVS|Editor Preview", meta=(EditCondition="bPreviewProfileDriven", ToolTip="Use the Animation Profile for this preview body's exact Skeleton. Select the male/female target profile separately; source animations are never retargeted by preview."))
	TSoftObjectPtr<UAVSAnimationProfile> PreviewAnimationProfile;

	UPROPERTY(EditAnywhere, Category="AVS|Editor Preview", meta=(EditCondition="bPreviewProfileDriven", ToolTip="Play the entire resolved entry, timed loop or held contact pose, and exit. Turn off to inspect Preview Phase."))
	bool bPreviewPlaySequence = true;

	UPROPERTY(EditAnywhere, Category="AVS|Editor Preview", meta=(EditCondition="bPreviewProfileDriven && bPreviewPlaySequence"))
	bool bRepeatPreviewSequence = true;

	UPROPERTY(VisibleAnywhere, Transient, Category="AVS|Editor Preview", meta=(MultiLine="true"))
	FString PreviewStatus;

	UPROPERTY(EditAnywhere, Category="AVS|Editor Preview|Legacy Pose Only", meta=(EditCondition="!bPreviewProfileDriven", DisplayName="Preview Activity / Loop Animation", ToolTip="Editor-only pose inspection; never supplies runtime clips. Use Runtime Animation Overrides for clips that must also play in game."))
	TSoftObjectPtr<UAnimSequenceBase> PreviewAnimation;

	UPROPERTY(EditAnywhere, Category="AVS|Editor Preview|Legacy Pose Only", meta=(EditCondition="!bPreviewProfileDriven", ToolTip="Editor-only idle pose inspection; never supplies runtime clips."))
	TSoftObjectPtr<UAnimSequenceBase> PreviewIdleAnimation;

	UPROPERTY(EditAnywhere, Category="AVS|Editor Preview|Legacy Pose Only", meta=(EditCondition="!bPreviewProfileDriven", ToolTip="Editor-only entry pose inspection; never supplies runtime clips."))
	TSoftObjectPtr<UAnimSequenceBase> PreviewStartAnimation;

	UPROPERTY(EditAnywhere, Category="AVS|Editor Preview|Legacy Pose Only", meta=(EditCondition="!bPreviewProfileDriven", ToolTip="Editor-only exit pose inspection; never supplies runtime clips."))
	TSoftObjectPtr<UAnimSequenceBase> PreviewEndAnimation;

	UPROPERTY(EditAnywhere, Category="AVS|Editor Preview|Legacy Pose Only",
		meta=(EditCondition="!bPreviewProfileDriven", ToolTip="Only controls legacy pose inspection. Profile-driven preview uses runtime fallback settings."))
	bool bPreviewUseSmartMissingTransitionFallback = true;

	UPROPERTY(EditAnywhere, Category="AVS|Editor Preview", meta=(ToolTip="Inspect a resolved phase when full sequence preview is disabled. Activity shows the configured contact pose when no loop exists."))
	EAVSPOIPreviewPhase PreviewPhase = EAVSPOIPreviewPhase::ActivityLoop;

	UPROPERTY(EditAnywhere, Category="AVS|Editor Preview")
	bool bPreviewAnimationInEditor = true;

	UPROPERTY(EditAnywhere, Category="AVS|Editor Preview|Legacy Pose Only", meta=(ClampMin="0.01", EditCondition="bPreviewAnimationInEditor && !bPreviewProfileDriven", ToolTip="Legacy pose playback speed only. Profile-driven preview uses the runtime row Play Rate."))
	float PreviewPlayRate = 1.0f;

	UPROPERTY(EditAnywhere, Category="AVS|Editor Preview", meta=(ToolTip="Additional mesh adjustment after Use Offset. Use this for import-axis or foot-height correction."))
	FTransform PreviewRelativeTransform = FTransform::Identity;
#endif

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI", meta=(ClampMin="1"))
	int32 Capacity = 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI", meta=(ToolTip="Local position where the NPC stands or sits. Move the POI actor to control facing direction."))
	FVector UseOffset = FVector::ZeroVector;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI",
		meta=(ToolTip="Runtime slot. In every target-specific Animation Profile, this row may contain its own Start Animation, main loop, and End Animation. After End, AVS returns to that profile's Idle slot."))
	EAVSAnimationSlot ActivityAnimation = EAVSAnimationSlot::Idle;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI", meta=(EditCondition="ActivityAnimation == EAVSAnimationSlot::Custom"))
	FName CustomAnimationName = NAME_None;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI")
	bool bLoopActivity = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI",
		meta=(ToolTip="Allows this POI to synthesize a missing reversed transition. Profile smart/reverse and row reverse switches must also be enabled. Pose Hold has its own independent POI switch."))
	bool bUseSmartMissingTransitionFallback = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI|Composed Animation", meta=(ToolTip="Allows transition-only rows to hold their contact pose. Profile and row hold switches must also be enabled. Hold is independent of reverse fallback."))
	bool bAllowPoseHoldFallback = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI|Composed Animation", meta=(ClampMin="-1.0", ClampMax="1.0", ToolTip="-1 uses the row setting. Otherwise selects the normalized contact frame for transition-only rows; zero is the first frame and one the last."))
	float HoldNormalizedPosition = -1.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI|Runtime Animation Overrides", meta=(ToolTip="Merge these clips over the selected profile row in runtime AND profile-driven preview. Each override must match the NPC Skeleton; leave a field empty to keep the profile clip. Use target-specific profiles for mixed Skeleton crowds."))
	bool bUseRuntimeAnimationOverrides = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI|Runtime Animation Overrides", meta=(EditCondition="bUseRuntimeAnimationOverrides"))
	TSoftObjectPtr<UAnimSequenceBase> RuntimeStartAnimation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI|Runtime Animation Overrides", meta=(EditCondition="bUseRuntimeAnimationOverrides"))
	TSoftObjectPtr<UAnimSequenceBase> RuntimeAnimation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI|Runtime Animation Overrides", meta=(EditCondition="bUseRuntimeAnimationOverrides"))
	TSoftObjectPtr<UAnimSequenceBase> RuntimeEndAnimation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI")
	bool bFacePOIDirection = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI|Arrival", meta=(ClampMin="1.0", Units="cm", ToolTip="Navigation must reach this horizontal distance before entry. The capsule is never snapped to Use Offset; move the POI onto reachable NavMesh."))
	float ArrivalDistanceTolerance = 15.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI|Arrival", meta=(ClampMin="0.1", ClampMax="180.0", Units="deg", EditCondition="bFacePOIDirection"))
	float ArrivalYawTolerance = 5.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI|Arrival", meta=(ClampMin="0.1", EditCondition="bFacePOIDirection", ToolTip="Smooth turning speed while stopped at the use position. No instant yaw alignment."))
	float FacingInterpSpeed = 3.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI|Arrival", meta=(ClampMin="0.1", Units="s", ToolTip="Abort and release the reservation if navigation cannot reach the use position in time."))
	float ArrivalTimeout = 30.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI|Arrival", meta=(ClampMin="0.1", Units="s", EditCondition="bFacePOIDirection", ToolTip="Abort and release if smooth facing cannot finish after reaching the use position."))
	float AlignmentTimeout = 6.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI|Arrival", meta=(ClampMin="0.1", Units="s", ToolTip="Maximum queue wait. Prevents an unavailable POI from retaining users indefinitely."))
	float QueueTimeout = 60.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI")
	bool bAutoLeaveAfterUse = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI", meta=(ClampMin="0.1", EditCondition="bAutoLeaveAfterUse"))
	float MinUseDuration = 5.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI", meta=(ClampMin="0.1", EditCondition="bAutoLeaveAfterUse"))
	float MaxUseDuration = 12.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI", meta=(ClampMin="0"))
	float QueueSpacing = 100.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI|Automatic Trigger", meta=(ToolTip="Any AVS NPC entering Auto Trigger can reserve or queue for this POI without Blueprint logic."))
	bool bAutoTriggerNearbyNPCs = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI|Automatic Trigger", meta=(ClampMin="0.0", ClampMax="1.0", EditCondition="bAutoTriggerNearbyNPCs"))
	float AutoTriggerChance = 1.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI|Automatic Trigger", meta=(EditCondition="bAutoTriggerNearbyNPCs", ToolTip="When enabled, route/following NPCs ignore this automatic trigger; Idle and Wander NPCs may use it."))
	bool bAutoTriggerOnlyIdleOrWandering = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI|Automatic Trigger",
		meta=(EditCondition="bAutoTriggerNearbyNPCs", ToolTip="An automatically detected NPC ignores this POI while anybody is using or queued for it. Manual Use Point Of Interest calls may still queue."))
	bool bAutoTriggerOnlyWhenCompletelyClear = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|POI|Automatic Trigger",
		meta=(ClampMin="0.0", Units="s", EditCondition="bAutoTriggerNearbyNPCs && bAutoTriggerOnlyWhenCompletelyClear", ToolTip="Keeps the automatic POI unavailable briefly while the previous user plays its End animation and walks clear."))
	float AutoTriggerClearanceAfterUse = 2.5f;

	UFUNCTION(BlueprintCallable, Category="AVS|POI")
	bool Reserve(AActor* NPC);

	UFUNCTION(BlueprintCallable, Category="AVS|POI")
	void Release(AActor* NPC);

	UFUNCTION(BlueprintCallable, Category="AVS|POI")
	bool JoinQueue(AActor* NPC);

	UFUNCTION(BlueprintCallable, Category="AVS|POI")
	void LeaveQueue(AActor* NPC);

	UFUNCTION(BlueprintPure, Category="AVS|POI")
	int32 GetQueueIndex(AActor* NPC) const;

	UFUNCTION(BlueprintPure, Category="AVS|POI")
	bool HasCapacity() const;

	UFUNCTION(BlueprintPure, Category="AVS|POI")
	FVector GetUseLocation() const;

	UFUNCTION(BlueprintPure, Category="AVS|POI")
	FVector GetQueueLocation(int32 QueueIndex) const;

	// Shared row selection/override precedence for runtime and the profile-driven editor preview.
	bool ResolveRuntimeAnimation(UAVSAnimationProfile* Profile, const USkeleton* Skeleton,
		FRandomStream& Stream, FAVSNamedAnimation& OutEntry) const;

protected:
	virtual void OnConstruction(const FTransform& Transform) override;
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

	UFUNCTION()
	void HandleUserDestroyed(AActor* NPC);

	UFUNCTION()
	void HandleUserEndPlay(AActor* NPC, EEndPlayReason::Type EndPlayReason);

	UFUNCTION()
	void HandleAutoTriggerBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor,
		UPrimitiveComponent* OtherComponent, int32 OtherBodyIndex, bool bFromSweep,
		const FHitResult& SweepResult);

private:
	void RefreshAutoTrigger();
	void RefreshEditorPreview();
	void CompactUsers();
	bool IsUsableUser(const AActor* NPC) const;
	void DetachUserIfUnreferenced(AActor* NPC);
	void UpdateEditorPreviewPose();

#if WITH_EDITORONLY_DATA
	AVS::Composed::Plan PreviewPlan;
	AVS::Composed::Playback PreviewPlayback;
	AVS::Composed::Segment PreviewInspectionSegment;
	double PreviewInspectionElapsed = 0.0;

	UPROPERTY(Transient)
	TArray<TObjectPtr<UAnimSequenceBase>> ResolvedPreviewClips;

	UPROPERTY(Transient)
	TObjectPtr<UAnimSequenceBase> ActivePreviewClip;
#endif

	UPROPERTY(Transient)
	TArray<TObjectPtr<AActor>> ReservedUsers;

	UPROPERTY(Transient)
	TArray<TObjectPtr<AActor>> QueuedUsers;

	float AutoTriggerBlockedUntil = 0.0f;
};
