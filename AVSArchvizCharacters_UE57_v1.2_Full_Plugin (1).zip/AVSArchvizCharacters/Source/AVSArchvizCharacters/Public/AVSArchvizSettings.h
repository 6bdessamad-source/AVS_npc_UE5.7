#pragma once

#include "CoreMinimal.h"
#include "Engine/DeveloperSettings.h"
#include "AVSArchvizTypes.h"
#include "AVSArchvizSettings.generated.h"

USTRUCT(BlueprintType)
struct AVSARCHVIZCHARACTERS_API FAVSAmbientActivityWeights
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Activities", meta=(ClampMin="0", Units="Percent", ToolTip="Relative chance for normal standing Idle. Missing categories are excluded and the remaining weights are normalized."))
	float Idle = 50.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Activities", meta=(ClampMin="0", Units="Percent"))
	float Smoking = 20.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Activities", meta=(ClampMin="0", Units="Percent"))
	float Stretching = 15.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Activities", meta=(ClampMin="0", Units="Percent", ToolTip="Configured Custom, phone, texting, drinking and other Idle Activities share this category."))
	float Custom = 15.0f;
};

USTRUCT(BlueprintType)
struct AVSARCHVIZCHARACTERS_API FAVSConversationSettings
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Conversations")
	bool bEnabled = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Conversations", meta=(ClampMin="0", ClampMax="100", Units="Percent", ToolTip="Chance for an eligible nearby group to form at each conversation evaluation. Independent of animation category weights and movement choices."))
	float FormationPercentage = 15.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Conversations", meta=(ClampMin="0.1", Units="s"))
	float EvaluationInterval = 2.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Conversations", meta=(ClampMin="50", Units="cm"))
	float DetectionRadius = 260.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Conversations", meta=(ClampMin="0", Units="cm", ToolTip="Maximum height difference between participants, preventing conversations between separate floors."))
	float MaxVerticalSeparation = 100.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Conversations", meta=(ClampMin="2", ClampMax="4"))
	int32 MaxGroupSize = 4;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Conversations", meta=(ClampMin="0.1", Units="s"))
	float MinDuration = 6.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Conversations", meta=(ClampMin="0.1", Units="s"))
	float MaxDuration = 18.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Conversations", meta=(ClampMin="0", Units="s"))
	float MinCooldown = 12.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Conversations", meta=(ClampMin="0", Units="s"))
	float MaxCooldown = 30.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Conversations", meta=(ClampMin="0", Units="s"))
	float MinPostIdleTime = 0.75f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Conversations", meta=(ClampMin="0", Units="s"))
	float MaxPostIdleTime = 2.5f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Conversations", meta=(ClampMin="0.1"))
	float FacingInterpSpeed = 3.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Conversations|Animation", meta=(ClampMin="0", Units="Percent", ToolTip="Normal compatible Idle category chance. All Talk variants share the other category."))
	float IdleAnimationWeight = 50.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Conversations|Animation", meta=(ClampMin="0", Units="Percent"))
	float TalkAnimationWeight = 50.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Conversations|Animation", meta=(ClampMin="0.1", Units="s"))
	float MinAnimationInterval = 3.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Conversations|Animation", meta=(ClampMin="0.1", Units="s"))
	float MaxAnimationInterval = 7.0f;
};

UCLASS(Config=Game, DefaultConfig, meta=(DisplayName="AVS ArchViz Characters"))
class AVSARCHVIZCHARACTERS_API UAVSArchvizSettings : public UDeveloperSettings
{
	GENERATED_BODY()

public:
	UAVSArchvizSettings();

	virtual FName GetCategoryName() const override { return TEXT("Plugins"); }

	UPROPERTY(Config, EditAnywhere, Category="Activation", meta=(ClampMin="0.05"))
	float EvaluationInterval = 0.5f;

	UPROPERTY(Config, EditAnywhere, Category="Activation", meta=(ClampMin="0.0"))
	float DefaultOrbitActivationZoom = 2500.0f;

	UPROPERTY(Config, EditAnywhere, Category="Activation", meta=(ClampMin="0.0"))
	float DefaultOrbitDeactivationZoom = 3000.0f;

	UPROPERTY(Config, EditAnywhere, Category="Pooling", meta=(ClampMin="0"))
	int32 WarmPoolSize = 10;

	UPROPERTY(Config, EditAnywhere, Category="Pooling", meta=(ClampMin="1"))
	int32 MaxActiveNPCs = 100;

	UPROPERTY(Config, EditAnywhere, Category="Optimization")
	TArray<FAVSQualityTier> QualityTiers;

	UPROPERTY(Config, EditAnywhere, Category="Ambient Activities")
	FAVSAmbientActivityWeights AmbientActivityWeights;

	UPROPERTY(Config, EditAnywhere, Category="Social Conversations", meta=(ToolTip="Global defaults. An explicit Global Controller configuration or zone override takes precedence. Its legacy social controls still override formation/radius/durations when no complete controller override is enabled."))
	FAVSConversationSettings Conversations;

	UPROPERTY(Config, EditAnywhere, Category="Optimization", meta=(ClampMin="1", ToolTip="Maximum eligible conversation leaders examined in one evaluation. Matching remains spatial and work rotates through the crowd."))
	int32 MaxConversationCandidatesPerEvaluation = 64;

	UPROPERTY(Config, EditAnywhere, Category="Optimization", meta=(ClampMin="1", ToolTip="Maximum generated characters whose distance quality is evaluated in one subsystem evaluation."))
	int32 MaxQualityUpdatesPerEvaluation = 64;

	UPROPERTY(Config, EditAnywhere, Category="Debug")
	bool bLogValidationWarnings = true;
};
