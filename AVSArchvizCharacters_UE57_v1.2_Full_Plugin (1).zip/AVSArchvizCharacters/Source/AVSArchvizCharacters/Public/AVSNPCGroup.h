#pragma once

#include "CoreMinimal.h"
#include "AVSCrowdGenerator.h"
#include "AVSNPCGroup.generated.h"

UCLASS(Blueprintable)
class AVSARCHVIZCHARACTERS_API AAVSNPCGroup : public AAVSCrowdGenerator
{
	GENERATED_BODY()

public:
	AAVSNPCGroup();

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Group")
	TObjectPtr<AActor> ExternalLeader = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Group", meta=(ClampMin="50.0"))
	float MemberSpacing = 140.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Group", meta=(ClampMin="0.0"))
	float LeaderWanderRadius = 1200.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Group")
	EAVSGroupFormation Formation = EAVSGroupFormation::SideBySide;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Group", meta=(ToolTip="Prevents followers from stopping for random phone/stretch activities while the leader keeps walking."))
	bool bDisableIdleActivitiesForFollowers = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Group", meta=(ToolTip="Uses the character movement RVO settings to keep group members separated."))
	bool bEnableMemberAvoidance = true;

protected:
	virtual bool MakeSpawnTransform(int32 NPCIndex, FTransform& OutTransform) override;
	virtual void ConfigureSpawnedNPC(AAVSArchvizNPCCharacter* NPC, int32 NPCIndex) override;

private:
	FVector GetFormationOffset(int32 NPCIndex) const;
};
