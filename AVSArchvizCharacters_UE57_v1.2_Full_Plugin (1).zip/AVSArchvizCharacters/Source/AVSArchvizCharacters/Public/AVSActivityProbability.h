#pragma once

#include <cmath>

// Engine-independent probability policy shared by runtime selection and portable tests.
namespace AVSActivityProbability
{
inline double AvailableWeight(double Weight, bool bAvailable = true)
{
	return bAvailable && std::isfinite(Weight) && Weight > 0.0 ? Weight : 0.0;
}

inline bool PassesPercentage(double Percentage, double UnitSample)
{
	if (!std::isfinite(Percentage) || !std::isfinite(UnitSample) || UnitSample < 0.0 || UnitSample > 1.0 || Percentage <= 0.0)
	{
		return false;
	}
	return Percentage >= 100.0 || (UnitSample >= 0.0 && UnitSample < Percentage / 100.0);
}

// Choose the category first; its number of rows never changes its total chance.
inline int ChooseWeighted(const double* Weights, int Count, double UnitSample)
{
	if (!Weights || Count <= 0 || !std::isfinite(UnitSample))
	{
		return -1;
	}
	double Total = 0.0;
	int LastAvailable = -1;
	for (int Index = 0; Index < Count; ++Index)
	{
		const double Weight = AvailableWeight(Weights[Index]);
		if (Weight > 0.0)
		{
			Total += Weight;
			LastAvailable = Index;
		}
	}
	if (!(Total > 0.0) || !std::isfinite(Total))
	{
		return -1;
	}
	const double ClampedSample = UnitSample < 0.0 ? 0.0 : (UnitSample > 1.0 ? 1.0 : UnitSample);
	double Pick = ClampedSample * Total;
	for (int Index = 0; Index < Count; ++Index)
	{
		const double Weight = AvailableWeight(Weights[Index]);
		if (Weight > 0.0 && Pick < Weight)
		{
			return Index;
		}
		Pick -= Weight;
	}
	return LastAvailable;
}
}
