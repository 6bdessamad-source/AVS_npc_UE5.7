#pragma once

#include "CoreMinimal.h"
#include "AVSComposedAnimationPolicy.h"

class UAVSAnimationProfile;
class UAnimSequenceBase;
class USkeleton;
struct FAVSNamedAnimation;

struct FAVSResolveSettings
{
    bool bAllowReverse = true;
    bool bAllowHold = true;
    bool bOverrideLoop = false;
    bool bLoop = true;
    float Duration = 8.0f;
    float HoldPosition = -1.0f;
};
struct FAVSResolvedAnimation
{
    AVS::Composed::Plan Plan;
    UAnimSequenceBase* Start = nullptr;
    UAnimSequenceBase* Main = nullptr;
    UAnimSequenceBase* End = nullptr;
    UAnimSequenceBase* GetClip(AVS::Composed::Clip Source) const
    {
        return Source == AVS::Composed::Clip::Start ? Start : Source == AVS::Composed::Clip::Main ? Main : Source == AVS::Composed::Clip::End ? End : nullptr;
    }
};
AVSARCHVIZCHARACTERS_API FAVSResolvedAnimation AVSResolveAnimation(const UAVSAnimationProfile* Profile,
    const FAVSNamedAnimation& Entry, const USkeleton* Skeleton, const FAVSResolveSettings& Settings = FAVSResolveSettings());
