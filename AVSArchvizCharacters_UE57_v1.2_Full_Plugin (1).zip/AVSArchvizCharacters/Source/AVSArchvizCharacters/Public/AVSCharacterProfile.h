#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "AVSArchvizTypes.h"
#include "AVSCharacterProfile.generated.h"

class UAnimInstance;
class UMaterialInterface;
class USkeleton;
class USkeletalMesh;
class UStaticMesh;

USTRUCT(BlueprintType)
struct AVSARCHVIZCHARACTERS_API FAVSSkinnedPartDefinition
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Appearance")
	EAVSModularSlot Slot = EAVSModularSlot::Head;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Compatibility", meta=(ToolTip="The part is considered only when this tag matches the Character Profile sex, or is Unisex / Any."))
	EAVSCharacterSex CompatibleSex = EAVSCharacterSex::Unisex;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Appearance")
	bool bEnabled = true;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Appearance", meta=(ClampMin="0.0", ToolTip="Relative chance when several compatible parts use the same slot."))
	float SelectionWeight = 1.0f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Appearance", meta=(ToolTip="Treat this weighted entry as an empty choice, useful for optional hats, glasses, hair, and accessories."))
	bool bNoPart = false;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Appearance", meta=(EditCondition="!bNoPart", EditConditionHides))
	TSoftObjectPtr<USkeletalMesh> Mesh;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Appearance")
	TArray<TSoftObjectPtr<UMaterialInterface>> MaterialOverrides;
};

USTRUCT(BlueprintType)
struct AVSARCHVIZCHARACTERS_API FAVSPropDefinition
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Prop")
	TSoftObjectPtr<UStaticMesh> Mesh;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Prop")
	FName SocketName = NAME_None;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Prop")
	FTransform RelativeTransform = FTransform::Identity;
};

UCLASS(BlueprintType)
class AVSARCHVIZCHARACTERS_API UAVSCharacterProfile : public UPrimaryDataAsset
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Identity")
	FText DisplayName;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Identity", meta=(ClampMin="0.0"))
	float SelectionWeight = 1.0f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Identity", meta=(ToolTip="Used to filter modular parts and animation profiles. Sex-specific assets never cross this boundary unless marked Unisex / Any."))
	EAVSCharacterSex Sex = EAVSCharacterSex::Unisex;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Compatibility", meta=(ToolTip="Optional family label such as UE5_Mannequin, AVS_Male_A, or AVS_Female_A. When both profiles set it, the values must match."))
	FName RigId = NAME_None;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Body")
	TSoftObjectPtr<USkeletalMesh> BodyMesh;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Body|Capsule Alignment", meta=(ToolTip="Relative transform of the body mesh under the Character capsule. Typical Unreal humanoid values are Z=-88 and Yaw=-90."))
	FTransform BodyMeshRelativeTransform = FTransform(FRotator(0.0f, -90.0f, 0.0f), FVector(0.0f, 0.0f, -88.0f));

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Body")
	TSoftClassPtr<UAnimInstance> AnimationBlueprint;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Body")
	bool bRequireSameSkeleton = true;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Modular Parts", meta=(TitleProperty="Slot", ToolTip="Add any number of rows per slot: for example 3 Hat rows, 4 Feet rows, and one weighted No Part row. AVS chooses exactly one compatible row independently for every slot."))
	TArray<FAVSSkinnedPartDefinition> ModularParts;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Modular Parts")
	bool bRandomizeModularParts = true;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Modular Parts", meta=(EditCondition="bRandomizeModularParts", ToolTip="Rolls a new weighted outfit whenever this profile is applied, including when a pooled NPC spawns again."))
	bool bRandomizeOnEverySpawn = true;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Modular Parts")
	int32 ModularRandomSeed = 1337;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Props")
	FAVSPropDefinition RightHandProp;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Props")
	FAVSPropDefinition LeftHandProp;

	UFUNCTION(BlueprintCallable, Category="AVS|Validation")
	bool ValidateProfile(TArray<FText>& OutIssues) const;

	UFUNCTION(CallInEditor, Category="AVS|Validation")
	void ValidateAndLog() const;

	USkeleton* ResolveAnimationSkeleton() const;
};
