#pragma once

#include "Logging/LogMacros.h"
#include "Modules/ModuleManager.h"

AVSARCHVIZCHARACTERS_API DECLARE_LOG_CATEGORY_EXTERN(LogAVSArchvizCharacters, Log, All);

class FAVSArchvizCharactersModule final : public IModuleInterface
{
public:
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
};
