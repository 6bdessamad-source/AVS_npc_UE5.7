#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "AVSArchvizTypes.h"
#include "AVSArchvizSettings.h"
#include "AVSAnimationProfile.h"
#include "AVSNPCBehaviorComponent.generated.h"

class AAVSCrowdRoute;
class AAVSPointOfInterest;
class AAVSArchvizNPCCharacter;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FAVSNPCStateChanged, EAVSNPCState, PreviousState, EAVSNPCState, NewState);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FAVSNPCActivityEvent, EAVSAnimationSlot, Slot, FName, CustomName);

UCLASS(ClassGroup=(AVS), meta=(BlueprintSpawnableComponent))
class AVSARCHVIZCHARACTERS_API UAVSNPCBehaviorComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UAVSNPCBehaviorComponent();

	UPROPERTY(BlueprintAssignable, Category="AVS|Behavior")
	FAVSNPCStateChanged OnStateChanged;

	UPROPERTY(BlueprintAssignable, Category="AVS|Behavior")
	FAVSNPCActivityEvent OnActivityStarted;

	UPROPERTY(BlueprintAssignable, Category="AVS|Behavior")
	FAVSNPCActivityEvent OnActivityFinished;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Behavior", meta=(ClampMin="0"))
	float WanderRadius = 1000.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Behavior", meta=(ClampMin="0"))
	float AcceptanceRadius = 80.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Behavior")
	FVector FollowOffset = FVector(-150.0f, 0.0f, 0.0f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Social Conversations",
		meta=(ToolTip="Allows this NPC to be selected for automatic nearby conversations while Idle or Wandering."))
	bool bAllowProximityConversations = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Activities")
	bool bEnableIdleActivities = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Activities", meta=(ToolTip="Use per-character ambient weights. Otherwise an owning zone override or Project Settings supplies category weights."))
	bool bOverrideAmbientActivityWeights = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Activities", meta=(EditCondition="bOverrideAmbientActivityWeights"))
	FAVSAmbientActivityWeights AmbientActivityWeights;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Activities", meta=(ClampMin="0.1", EditCondition="bEnableIdleActivities"))
	float MinActivityInterval = 8.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Activities", meta=(ClampMin="0.1", EditCondition="bEnableIdleActivities"))
	float MaxActivityInterval = 20.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Activities", meta=(EditCondition="bEnableIdleActivities"))
	TArray<FAVSWeightedActivity> IdleActivities;

	UFUNCTION(BlueprintCallable, Category="AVS|Behavior")
	void SetBehaviorState(EAVSNPCState NewState);

	UFUNCTION(BlueprintCallable, Category="AVS|Behavior")
	void StartWandering(FVector NewOrigin, float NewRadius);

	UFUNCTION(BlueprintCallable, Category="AVS|Behavior")
	void SetWanderArea(FVector NewOrigin, float NewRadius);

	UFUNCTION(BlueprintCallable, Category="AVS|Behavior")
	void FollowActor(AActor* NewTarget, FVector Offset);

	UFUNCTION(BlueprintCallable, Category="AVS|Behavior")
	void FollowRoute(AAVSCrowdRoute* NewRoute, bool bLoopRoute = true);

	UFUNCTION(BlueprintCallable, Category="AVS|Behavior")
	void FollowRouteWithCompletion(AAVSCrowdRoute* NewRoute, bool bLoopRoute, EAVSNPCState CompletionState);

	UFUNCTION(BlueprintCallable, Category="AVS|Behavior")
	void FollowRouteWithOptions(AAVSCrowdRoute* NewRoute, bool bLoopRoute, EAVSNPCState CompletionState,
		float LateralOffset = 0.0f, int32 StartPointIndex = -1);

	UFUNCTION(BlueprintCallable, Category="AVS|Behavior")
	void UsePointOfInterest(AAVSPointOfInterest* NewPOI);

	UFUNCTION(BlueprintCallable, Category="AVS|Behavior")
	void QueueAtPointOfInterest(AAVSPointOfInterest* NewPOI);

	UFUNCTION(BlueprintCallable, Category="AVS|Activities")
	bool StartRandomIdleActivity();

	UFUNCTION(BlueprintCallable, Category="AVS|Activities")
	void CancelActivity();

	bool StartConversation(const TArray<AAVSArchvizNPCCharacter*>& Participants, float Duration,
		float Cooldown, float PostConversationIdleTime, float FacingInterpSpeed);

	UFUNCTION(BlueprintCallable, Category="AVS|Social Conversations")
	void LeaveConversation(bool bReturnToWander = true);

	UFUNCTION(BlueprintPure, Category="AVS|Social Conversations")
	bool CanJoinConversation() const;

	UFUNCTION(BlueprintPure, Category="AVS|Social Conversations")
	int32 GetConversationParticipantCount() const;

	UFUNCTION(BlueprintCallable, Category="AVS|Social Conversations")
	void DeferConversations(float Duration);

	UFUNCTION(BlueprintPure, Category="AVS|Behavior")
	EAVSNPCState GetBehaviorState() const { return State; }

	UFUNCTION(BlueprintPure, Category="AVS|Behavior")
	AAVSCrowdRoute* GetCurrentRoute() const { return Route.Get(); }

	UFUNCTION(BlueprintPure, Category="AVS|Behavior")
	AAVSPointOfInterest* GetCurrentPointOfInterest() const { return PointOfInterest.Get(); }

	UFUNCTION(BlueprintCallable, Category="AVS|Behavior")
	void ResetBehavior();

	// Successful project Behavior Trees own decisions until the controller releases ownership.
	UFUNCTION(BlueprintCallable, Category="AVS|Behavior", meta=(ToolTip="Stop the project Behavior Tree before disabling external ownership; one owner should issue movement/activity decisions."))
	void SetExternalBehaviorOwnership(bool bExternalOwner) { bExternalBehaviorOwner = bExternalOwner; }
	bool HasPendingStateChange() const { return bHasPendingStateChange; }

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

private:
	bool IssueMoveTo(const FVector& Destination, float DestinationAcceptanceRadius = -1.0f);
	void UpdateIdle(float DeltaTime);
	void UpdateActivity(float DeltaTime);
	void UpdateWander();
	void UpdateFollowActor();
	void UpdateRoute();
	FVector GetRouteTarget(int32 PointIndex) const;
	bool CompleteCurrentRoute();
	void UpdateQueue();
	void UpdatePointOfInterest(float DeltaTime);
	void RequestPointOfInterest(AAVSPointOfInterest* NewPOI, bool bQueueOnly, bool bPreserveReturnState = false);
	void UpdateConversation(float DeltaTime);
	void ClearConversationState();
	bool PlayConversationVariant();
	bool SelectConversationVariant(FAVSNamedAnimation& OutEntry, EAVSAnimationSlot& OutSlot, int32& OutIndex);
	void ScheduleConversationAnimation();
	FAVSAmbientActivityWeights GetAmbientActivityWeights() const;
	FAVSConversationSettings GetConversationSettings() const;
	void RestoreFacingControl();
	void ScheduleNextActivity();

	EAVSNPCState State = EAVSNPCState::Inactive;
	EAVSNPCState ReturnStateAfterActivity = EAVSNPCState::Idle;
	EAVSNPCState ReturnStateAfterPOI = EAVSNPCState::Idle;
	FVector WanderOrigin = FVector::ZeroVector;
	TWeakObjectPtr<AActor> FollowTarget;
	TWeakObjectPtr<AAVSCrowdRoute> Route;
	TWeakObjectPtr<AAVSPointOfInterest> PointOfInterest;
	int32 RoutePointIndex = 0;
	float RouteLateralOffset = 0.0f;
	float RouteTransferCooldown = 0.0f;
	bool bLoop = true;
	EAVSNPCState RouteCompletionState = EAVSNPCState::Idle;
	bool bStartedPOIActivity = false;
	float TimeUntilDecision = 0.0f;
	float MoveRequestCooldownRemaining = 0.0f;
	FVector LastMoveRequestDestination = FVector::ZeroVector;
	bool bHasLastMoveRequest = false;
	float TimeUntilNextActivity = 0.0f;
	float ActivityTimeRemaining = 0.0f;
	float POIElapsedTime = 0.0f;
	float POIAlignmentElapsedTime = 0.0f;
	float POITimeRemaining = 0.0f;
	float ConversationTimeRemaining = 0.0f;
	float ConversationCooldownRemaining = 0.0f;
	float PendingConversationCooldown = 0.0f;
	float PostConversationIdleRemaining = 0.0f;
	float ConversationFacingSpeed = 3.0f;
	bool bPendingWanderAfterConversation = false;
	bool bSavedOrientRotationToMovement = true;
	bool bHasSavedFacingControl = false;
	bool bHasPendingStateChange = false;
	EAVSNPCState PendingState = EAVSNPCState::Idle;
	TWeakObjectPtr<AAVSPointOfInterest> PendingPointOfInterest;
	bool bPendingPOIQueue = false;
	float ConversationAnimationTimeRemaining = 0.0f;
	bool bConversationVariantPending = false;
	EAVSAnimationSlot LastConversationSlot = EAVSAnimationSlot::Custom;
	int32 LastConversationVariantIndex = INDEX_NONE;
	FAVSNamedAnimation PendingConversationEntry;
	EAVSAnimationSlot PendingConversationSlot = EAVSAnimationSlot::Idle;
	int32 PendingConversationVariantIndex = INDEX_NONE;
	TMap<FString, int32> LastActivityVariantIndices;
	float NavigationFailureBackoff = 0.25f;
	FVector ConversationWanderOrigin = FVector::ZeroVector;
	TArray<TWeakObjectPtr<AAVSArchvizNPCCharacter>> ConversationParticipants;
	EAVSAnimationSlot ActiveActivitySlot = EAVSAnimationSlot::Idle;
	FName ActiveActivityName = NAME_None;
	FRandomStream BehaviorRandom;
	bool bExternalBehaviorOwner = false;
};
