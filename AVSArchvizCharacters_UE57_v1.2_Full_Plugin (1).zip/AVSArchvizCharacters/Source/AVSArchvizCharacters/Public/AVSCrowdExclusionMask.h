#pragma once

#include "CoreMinimal.h"
#include "AVSArchvizTypes.h"
#include "GameFramework/Actor.h"
#include "AVSCrowdExclusionMask.generated.h"

class UBillboardComponent;
class UBoxComponent;
class USplineComponent;

UCLASS(Blueprintable)
class AVSARCHVIZCHARACTERS_API AAVSCrowdExclusionMask : public AActor
{
	GENERATED_BODY()

public:
	AAVSCrowdExclusionMask();

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="AVS")
	TObjectPtr<USceneComponent> SceneRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="AVS|Mask")
	TObjectPtr<USplineComponent> MaskSpline;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="AVS|Mask")
	TObjectPtr<UBoxComponent> MaskBox;

#if WITH_EDITORONLY_DATA
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="AVS|Editor")
	TObjectPtr<UBillboardComponent> EditorBillboard;
#endif

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Mask")
	EAVSExclusionMaskShape Shape = EAVSExclusionMaskShape::Spline;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Mask")
	bool bBlockSpawning = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Mask")
	bool bBlockMovementDestinations = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Mask", meta=(ToolTip="Builds invisible Pawn-blocking, navigation-relevant boxes around the closed spline boundary."))
	bool bBuildCollisionBoundary = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Mask", meta=(ClampMin="10.0"))
	float BoundaryThickness = 80.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Mask", meta=(ClampMin="25.0"))
	float BoundarySampleSpacing = 200.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Mask")
	float MinHeightOffset = -200.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Mask")
	float MaxHeightOffset = 400.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Mask")
	bool bAffectNavigation = true;

	UFUNCTION(BlueprintPure, Category="AVS|Mask")
	bool ContainsWorldLocation(const FVector& WorldLocation) const;

	UFUNCTION(BlueprintPure, Category="AVS|Mask")
	bool IntersectsWorldSegment(const FVector& SegmentStart, const FVector& SegmentEnd) const;

	UFUNCTION(BlueprintCallable, CallInEditor, Category="AVS|Mask")
	void RebuildBoundary();

	void GetPolygonPoints(TArray<FVector>& OutPoints) const;

protected:
	virtual void OnConstruction(const FTransform& Transform) override;
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	UPROPERTY(Transient)
	TArray<TObjectPtr<UBoxComponent>> BoundaryComponents;
};
