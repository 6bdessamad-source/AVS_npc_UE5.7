#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "AVSArchvizTypes.h"
#include "AVSArchvizViewerInterface.generated.h"

UINTERFACE(BlueprintType)
class AVSARCHVIZCHARACTERS_API UAVSArchvizViewerInterface : public UInterface
{
	GENERATED_BODY()
};

class AVSARCHVIZCHARACTERS_API IAVSArchvizViewerInterface
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category="AVS|Crowd")
	bool GetAVSViewerState(FAVSViewerState& OutState) const;
};
