#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "AVSArchvizTypes.h"
#include "AVSArchvizViewerInterface.h"
#include "AVSArchvizCrowdComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FAVSViewerStateChanged, const FAVSViewerState&, NewState);

/**
 * Drop this component on the ArchViz pawn. It can be driven manually from Blueprint,
 * through IAVSArchvizViewerInterface, or by reading compatible owner properties by name.
 */
UCLASS(ClassGroup=(AVS), meta=(BlueprintSpawnableComponent, DisplayName="AVS ArchViz Crowd Bridge"))
class AVSARCHVIZCHARACTERS_API UAVSArchvizCrowdComponent : public UActorComponent, public IAVSArchvizViewerInterface
{
	GENERATED_BODY()

public:
	UAVSArchvizCrowdComponent();

	UPROPERTY(BlueprintAssignable, Category="AVS|Viewer")
	FAVSViewerStateChanged OnViewerStateChanged;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Viewer")
	EAVSViewerMode ViewerMode = EAVSViewerMode::Walking;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Viewer")
	float OrbitZoom = 0.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Viewer")
	bool bCrowdEnabled = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Automatic Integration")
	bool bReadOwnerProperties = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Automatic Integration")
	FName ModePropertyName = TEXT("CurrentState");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Automatic Integration")
	FName ZoomPropertyName = TEXT("ORB_TargetZoom");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Automatic Integration")
	int64 WalkingEnumValue = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Automatic Integration")
	int64 OrbitingEnumValue = 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Activation", meta=(ClampMin="0.0"))
	float OrbitActivationZoom = 2500.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Activation", meta=(ClampMin="0.0"))
	float OrbitDeactivationZoom = 3000.0f;

	UFUNCTION(BlueprintCallable, Category="AVS|Viewer")
	void SetViewerMode(EAVSViewerMode NewMode);

	UFUNCTION(BlueprintCallable, Category="AVS|Viewer")
	void SetOrbitZoom(float NewZoom);

	UFUNCTION(BlueprintCallable, Category="AVS|Viewer")
	void SetCrowdEnabled(bool bEnabled);

	UFUNCTION(BlueprintPure, Category="AVS|Viewer")
	FAVSViewerState GetCurrentViewerState() const;

	virtual bool GetAVSViewerState_Implementation(FAVSViewerState& OutState) const override;

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

private:
	void RefreshFromOwner();
	void RefreshActivationState();
	bool ReadNumericProperty(const UObject* Object, FName PropertyName, double& OutValue) const;
	void BroadcastIfChanged();

	FAVSViewerState LastBroadcastState;
	bool bHasBroadcastState = false;
	bool bZoomAllowsCrowd = true;
};
