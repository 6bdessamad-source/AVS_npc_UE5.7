#pragma once

#include "CoreMinimal.h"
#include "AVSCrowdGenerator.h"
#include "AVSArchvizSettings.h"
#include "AVSSplineCrowdZone.generated.h"

class USplineComponent;

/** Spawns and configures a crowd inside a closed spline polygon. */
UCLASS(Blueprintable)
class AVSARCHVIZCHARACTERS_API AAVSSplineCrowdZone : public AAVSCrowdGenerator
{
	GENERATED_BODY()

public:
	AAVSSplineCrowdZone();

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="AVS|Spline Zone")
	TObjectPtr<USplineComponent> SurfaceSpline;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Spline Zone", meta=(ClampMin="50.0"))
	float SurfaceSampleSpacing = 250.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Spline Zone", meta=(ClampMin="1", ClampMax="128"))
	int32 MaxSpawnAttemptsPerNPC = 24;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Spline Zone")
	bool bProjectToNavMesh = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Spline Zone")
	FVector NavProjectionExtent = FVector(100.0f, 100.0f, 500.0f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, AdvancedDisplay, Category="AVS|Spline Zone", meta=(ClampMin="0.0", ClampMax="1.0", ToolTip="Legacy setting retained for asset compatibility. Use AVS Idle Percentage Weight."))
	float WanderingFraction = 0.75f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Spline Zone", meta=(DisplayName="AVS Idle Percentage Weight", ClampMin="0.0", ClampMax="100.0", Units="Percent", ToolTip="Percentage of newly spawned zone NPCs that begin Idle. Set lower values to make the crowd more active."))
	float IdlePercentageWeight = 25.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Spline Zone", meta=(ClampMin="0.0"))
	float WanderRadius = 1000.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Spline Zone|Ambient Activities")
	bool bOverrideAmbientActivityWeights = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Spline Zone|Ambient Activities", meta=(EditCondition="bOverrideAmbientActivityWeights"))
	FAVSAmbientActivityWeights AmbientActivityWeights;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Spline Zone|Conversations")
	bool bOverrideConversationSettings = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Spline Zone|Conversations", meta=(EditCondition="bOverrideConversationSettings"))
	FAVSConversationSettings Conversations;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Spline Zone|Routes", meta=(ClampMin="0.0", ClampMax="1.0"))
	float RouteDecisionChance = 0.25f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Spline Zone|Routes")
	bool bAutoDiscoverContainedRoutes = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Spline Zone|Routes", meta=(ClampMin="25.0", EditCondition="bAutoDiscoverContainedRoutes"))
	float RouteDetectionSampleSpacing = 100.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Spline Zone|Routes")
	TArray<FAVSZoneRouteChoice> RouteChoices;

	UFUNCTION(BlueprintCallable, CallInEditor, Category="AVS|Spline Zone|Routes")
	void RefreshContainedRoutes();

	UFUNCTION(BlueprintPure, Category="AVS|Spline Zone")
	virtual bool ContainsWorldLocation(const FVector& Location) const override;
	virtual void AcceptConnectorArrival(AAVSArchvizNPCCharacter* NPC) override;

protected:
	virtual void BeginPlay() override;
	virtual bool MakeSpawnTransform(int32 NPCIndex, FTransform& OutTransform) override;
	virtual void ConfigureSpawnedNPC(AAVSArchvizNPCCharacter* NPC, int32 NPCIndex) override;
	virtual void DrawGeneratorDebug(const FAVSViewerState& ViewerState) const override;

private:
	void GetSurfacePolygon(TArray<FVector>& OutPoints) const;
	const FAVSZoneRouteChoice* SelectRouteChoice(const AAVSArchvizNPCCharacter* NPC);

	UPROPERTY(Transient)
	TArray<FAVSZoneRouteChoice> CachedRouteChoices;
};
