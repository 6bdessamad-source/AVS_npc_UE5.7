#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "AVSArchvizTypes.h"
#include "AVSAnimationProfile.generated.h"

class UAnimSequenceBase;
class UAnimMontage;
class USkeleton;
class USkeletalMesh;
class UAVSCharacterProfile;

USTRUCT(BlueprintType)
struct AVSARCHVIZCHARACTERS_API FAVSNamedAnimation
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Animation")
	EAVSAnimationSlot Slot = EAVSAnimationSlot::Custom;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Animation", meta=(EditCondition="Slot == EAVSAnimationSlot::Custom"))
	FName CustomName = NAME_None;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Animation")
	TSoftObjectPtr<UAnimSequenceBase> Animation;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Animation|Composed", meta=(ToolTip="Optional one-shot played before the main animation. For example: stand-to-walk, phone pickup, sit down."))
	TSoftObjectPtr<UAnimSequenceBase> StartAnimation;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Animation|Composed", meta=(ToolTip="Optional one-shot played before leaving this animation. For example: walk stop, phone put-away, stand up."))
	TSoftObjectPtr<UAnimSequenceBase> EndAnimation;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Animation|Composed",
		meta=(ToolTip="When the profile's Smart Missing Transition Fallback is enabled, AVS reverses the available transition to replace a missing partner: End reversed becomes Start, or Start reversed becomes End. Disable this row for clips that look wrong in reverse, especially root-motion clips."))
	bool bAllowReverseTransitionFallback = true;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Animation|Composed", meta=(ToolTip="When no Loop exists, hold the contact pose during timed use. Requires a compatible safe exit. Independent of reverse fallback."))
	bool bAllowHoldPoseFallback = true;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Animation|Composed", meta=(ClampMin="-1.0", ClampMax="1.0", ToolTip="-1 uses the final Start frame or first End frame. Otherwise normalized contact position 0..1; the exit retraces only the traversed segment."))
	float HoldPoseNormalizedPosition = -1.0f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Animation|Composed", meta=(ToolTip="Enable only after checking reversed notifies and root motion. Reverse fallback uses deterministic single-node playback; notifies are suppressed by default."))
	bool bAllowReverseNotifies = false;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Animation|Composed", meta=(ToolTip="Opt in only after validating reverse root motion with your clips. Root-motion reversal is rejected by default."))
	bool bAllowReverseRootMotion = false;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Animation")
	bool bLoop = false;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Animation", meta=(ClampMin="0.01"))
	float PlayRate = 1.0f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Animation|Locomotion", meta=(ClampMin="0.0", ToolTip="For Walk/Run rows, the intended ground speed of this animation in cm/s. Zero uses the profile-level reference speed. Set this to the speed at which the feet look planted when Play Rate is 1.0."))
	float AuthoredGroundSpeed = 0.0f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Animation", meta=(ClampMin="0.0", ToolTip="Relative chance when several entries use the same slot and custom name."))
	float SelectionWeight = 1.0f;
};

UCLASS(BlueprintType)
class AVSARCHVIZCHARACTERS_API UAVSAnimationProfile : public UPrimaryDataAsset
{
	GENERATED_BODY()

public:
#if WITH_EDITORONLY_DATA
	UPROPERTY(VisibleAnywhere, Category="AVS|Generated Retarget", AdvancedDisplay,
		meta=(ToolTip="True only for target-specific profiles created by the AVS one-click retarget utility."))
	bool bGeneratedByAVSRetargetUtility = false;

	UPROPERTY(VisibleAnywhere, Category="AVS|Generated Retarget", AdvancedDisplay)
	TSoftObjectPtr<UAVSAnimationProfile> RetargetSourceProfile;

	UPROPERTY(VisibleAnywhere, Category="AVS|Generated Retarget", AdvancedDisplay)
	TSoftObjectPtr<USkeletalMesh> RetargetTargetMesh;
#endif

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Compatibility", meta=(ToolTip="Male and Female profiles are selected only for matching characters. Use Unisex / Any only for animations that are valid for both."))
	EAVSCharacterSex CompatibleSex = EAVSCharacterSex::Unisex;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Compatibility", meta=(ToolTip="Optional family label. When both the character and animation set it, they must match."))
	FName RigId = NAME_None;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Compatibility")
	TSoftObjectPtr<USkeleton> TargetSkeleton;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Manual Animation Slots")
	TArray<FAVSNamedAnimation> Animations;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Locomotion", meta=(ClampMin="0.0"))
	float WalkSpeedThreshold = 10.0f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Locomotion", meta=(ClampMin="0.0"))
	float RunSpeedThreshold = 300.0f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Locomotion", meta=(ClampMin="0.0", ToolTip="Prevents rapid Idle/Walk/Run switching when speed hovers near a threshold."))
	float SpeedHysteresis = 12.0f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Locomotion|Movement Match", meta=(ClampMin="1.0", ToolTip="Maximum AI walking speed in cm/s. 125 is a relaxed ArchViz walking pace."))
	float DesiredWalkSpeed = 125.0f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Locomotion|Movement Match", meta=(ClampMin="1.0", ToolTip="Acceleration used by Character Movement and AI path following, in cm/s squared."))
	float MovementAcceleration = 160.0f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Locomotion|Movement Match", meta=(ClampMin="1.0", ToolTip="Walking deceleration used when approaching a destination or stopping."))
	float MovementDeceleration = 220.0f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Locomotion|Movement Match", meta=(ToolTip="Makes AI path following accelerate and decelerate instead of setting walking velocity instantly."))
	bool bUseAccelerationForPaths = true;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Locomotion|Movement Match", meta=(ToolTip="Scales Walk and Run animation playback from the character's real horizontal speed."))
	bool bMatchLocomotionPlayRateToSpeed = true;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Locomotion|Movement Match", meta=(ClampMin="1.0", EditCondition="bMatchLocomotionPlayRateToSpeed", ToolTip="Fallback intended speed for Walk rows whose Authored Ground Speed is zero."))
	float WalkAnimationReferenceSpeed = 125.0f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Locomotion|Movement Match", meta=(ClampMin="1.0", EditCondition="bMatchLocomotionPlayRateToSpeed", ToolTip="Fallback intended speed for Run rows whose Authored Ground Speed is zero."))
	float RunAnimationReferenceSpeed = 320.0f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Locomotion|Movement Match", meta=(ClampMin="0.05", ClampMax="2.0", EditCondition="bMatchLocomotionPlayRateToSpeed"))
	float MinDynamicLocomotionPlayRate = 0.25f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Locomotion|Movement Match", meta=(ClampMin="0.05", ClampMax="4.0", EditCondition="bMatchLocomotionPlayRateToSpeed"))
	float MaxDynamicLocomotionPlayRate = 1.35f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Locomotion|Movement Match", meta=(ClampMin="0.0", EditCondition="bMatchLocomotionPlayRateToSpeed", ToolTip="How quickly playback catches up with real movement speed. Lower values feel softer."))
	float LocomotionPlayRateInterpolationSpeed = 5.0f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Locomotion|Variants", meta=(ClampMin="0.1"))
	float IdleVariantMinTime = 6.0f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Locomotion|Variants", meta=(ClampMin="0.1"))
	float IdleVariantMaxTime = 15.0f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Transitions", meta=(ToolTip="Uses dynamic montages when the character's Animation Blueprint contains Montage Slot Name. Falls back to single-node playback otherwise."))
	bool bUseSmoothMontageTransitions = true;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Transitions", meta=(EditCondition="bUseSmoothMontageTransitions"))
	FName MontageSlotName = TEXT("DefaultSlot");

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Transitions", meta=(ClampMin="0.0", EditCondition="bUseSmoothMontageTransitions"))
	float BlendInTime = 0.25f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Transitions", meta=(ClampMin="0.0", EditCondition="bUseSmoothMontageTransitions"))
	float BlendOutTime = 0.25f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Transitions", meta=(ToolTip="When montage blending is unavailable, optional Walk Start/Stop and Run Start/Stop slots are played before switching locomotion."))
	bool bUseTransitionClips = true;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Transitions|Composed",
		meta=(ToolTip="Master switch for missing composed transitions. If a row has only Start, AVS reverses Start as End. If it has only End, AVS reverses End as Start. Rows containing only the main animation remain valid and play normally."))
	bool bEnableSmartMissingTransitionFallback = true;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Transitions|Composed", meta=(ToolTip="Independent master permission for synthesizing reversed transitions."))
	bool bEnableReverseTransitionFallback = true;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Transitions|Composed", meta=(ToolTip="Independent master permission for holding a transition contact pose when no Loop is configured."))
	bool bEnableHoldPoseFallback = true;

	UFUNCTION(BlueprintPure, Category="AVS|Animation")
	UAnimSequenceBase* ResolveAnimation(EAVSAnimationSlot Slot, FName CustomName = NAME_None) const;

	UFUNCTION(BlueprintPure, Category="AVS|Animation")
	bool HasAnimation(EAVSAnimationSlot Slot, FName CustomName = NAME_None) const;

	bool HasCompatibleEntryForSkeleton(const FAVSNamedAnimation& Entry, const USkeleton* Skeleton) const;
	bool SelectCompatibleAnimationVariant(EAVSAnimationSlot Slot, FName CustomName, const USkeleton* Skeleton,
		FRandomStream& Stream, int32 AvoidIndex, FAVSNamedAnimation& OutEntry, int32& OutIndex) const;

	int32 GetVariantCount(EAVSAnimationSlot Slot, FName CustomName = NAME_None) const;
	bool HasCompatibleAnimationForSkeleton(EAVSAnimationSlot Slot, const USkeleton* Skeleton, FName CustomName = NAME_None) const;
	bool SelectAnimationVariant(EAVSAnimationSlot Slot, FName CustomName, FRandomStream& Stream,
		int32 AvoidIndex, FAVSNamedAnimation& OutEntry, int32& OutIndex) const;

	UFUNCTION(BlueprintPure, Category="AVS|Compatibility")
	bool IsCompatibleWithCharacter(const UAVSCharacterProfile* CharacterProfile) const;

	UFUNCTION(BlueprintCallable, Category="AVS|Validation")
	bool ValidateProfile(TArray<FText>& OutIssues) const;

	UFUNCTION(CallInEditor, Category="AVS|Validation")
	void ValidateAndLog() const;
};
