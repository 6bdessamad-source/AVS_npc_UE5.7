#pragma once

#include "CoreMinimal.h"
#include "AVSCrowdGenerator.h"
#include "AVSArchvizSettings.h"
#include "AVSCrowdZone.generated.h"

class UBoxComponent;

UCLASS(Blueprintable)
class AVSARCHVIZCHARACTERS_API AAVSCrowdZone : public AAVSCrowdGenerator
{
	GENERATED_BODY()

public:
	AAVSCrowdZone();

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="AVS|Zone")
	TObjectPtr<UBoxComponent> SpawnVolume;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Zone")
	bool bProjectToNavMesh = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Zone")
	FVector NavProjectionExtent = FVector(100.0f, 100.0f, 500.0f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, AdvancedDisplay, Category="AVS|Zone", meta=(ClampMin="0.0", ClampMax="1.0", ToolTip="Legacy setting retained for asset compatibility. Use AVS Idle Percentage Weight."))
	float WanderingFraction = 0.5f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Zone", meta=(DisplayName="AVS Idle Percentage Weight", ClampMin="0.0", ClampMax="100.0", Units="Percent", ToolTip="Percentage of newly spawned zone NPCs that begin Idle. Set lower values to make the crowd more active."))
	float IdlePercentageWeight = 50.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Zone", meta=(ClampMin="0.0"))
	float WanderRadius = 1000.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Zone|Ambient Activities")
	bool bOverrideAmbientActivityWeights = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Zone|Ambient Activities", meta=(EditCondition="bOverrideAmbientActivityWeights"))
	FAVSAmbientActivityWeights AmbientActivityWeights;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Zone|Conversations")
	bool bOverrideConversationSettings = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Zone|Conversations", meta=(EditCondition="bOverrideConversationSettings"))
	FAVSConversationSettings Conversations;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Zone|Routes", meta=(ClampMin="0.0", ClampMax="1.0", ToolTip="Chance that a spawned NPC chooses a route touching this zone instead of immediately wandering or idling."))
	float RouteDecisionChance = 0.25f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Zone|Routes")
	bool bAutoDiscoverContainedRoutes = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Zone|Routes", meta=(ClampMin="25.0", EditCondition="bAutoDiscoverContainedRoutes"))
	float RouteDetectionSampleSpacing = 100.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Zone|Routes")
	TArray<FAVSZoneRouteChoice> RouteChoices;

	UFUNCTION(BlueprintCallable, CallInEditor, Category="AVS|Zone|Routes")
	void RefreshContainedRoutes();

	virtual bool ContainsWorldLocation(const FVector& Location) const override;
	virtual void AcceptConnectorArrival(AAVSArchvizNPCCharacter* NPC) override;

protected:
	virtual void BeginPlay() override;
	virtual bool MakeSpawnTransform(int32 NPCIndex, FTransform& OutTransform) override;
	virtual void ConfigureSpawnedNPC(AAVSArchvizNPCCharacter* NPC, int32 NPCIndex) override;
	virtual void DrawGeneratorDebug(const FAVSViewerState& ViewerState) const override;

private:
	const FAVSZoneRouteChoice* SelectRouteChoice(const AAVSArchvizNPCCharacter* NPC);

	UPROPERTY(Transient)
	TArray<FAVSZoneRouteChoice> CachedRouteChoices;
};
