#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "AVSArchvizTypes.h"
#include "AVSAnimationProfile.h"
#include "AVSResolvedAnimation.h"
#include "AVSAnimationDriverComponent.generated.h"

class UAnimMontage;
class UAnimInstance;
class UAnimSequenceBase;
class USkeletalMeshComponent;

UCLASS(ClassGroup=(AVS), meta=(BlueprintSpawnableComponent))
class AVSARCHVIZCHARACTERS_API UAVSAnimationDriverComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UAVSAnimationDriverComponent();

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="AVS|Animation")
	TObjectPtr<UAVSAnimationProfile> AnimationProfile = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Animation")
	bool bDriveSingleNodeLocomotion = true;

	UFUNCTION(BlueprintCallable, Category="AVS|Animation")
	void ApplyAnimationProfile(UAVSAnimationProfile* NewProfile);

	UFUNCTION(BlueprintCallable, Category="AVS|Animation")
	bool PlayAnimationSlot(EAVSAnimationSlot Slot, FName CustomName = NAME_None, bool bLoopOverride = false,
		bool bOverrideProfileLoopSetting = false, bool bAllowSmartTransitionFallback = true);

	UFUNCTION(BlueprintCallable, Category="AVS|Animation")
	void ResumeLocomotion();

	bool PlayAnimationEntry(const FAVSNamedAnimation& Entry, EAVSAnimationSlot Slot, float Duration = -1.0f,
		bool bAllowReverse = true, bool bAllowHold = true, float HoldPosition = -1.0f);

	UFUNCTION(BlueprintPure, Category="AVS|Animation")
	bool IsActivityPlaybackActive() const { return ActivityPlayback.IsActive(); }

	bool IsActivityBodyActive() const { return ActivityPlayback.GetPhase() == AVS::Composed::Phase::Body; }

	UFUNCTION(BlueprintCallable, Category="AVS|Animation")
	void CancelActivityPlayback(bool bImmediate = false);

	void ResetForPool();

	UFUNCTION(BlueprintPure, Category="AVS|Animation")
	USkeletalMeshComponent* GetTargetMesh() const;

	UFUNCTION(BlueprintPure, Category="AVS|Animation")
	EAVSAnimationSlot GetCurrentSlot() const { return CurrentSlot; }

	UFUNCTION(BlueprintPure, Category="AVS|Animation")
	bool HasValidMovementAnimation() const;

	UFUNCTION(BlueprintPure, Category="AVS|Animation")
	bool IsCurrentAnimationMovementCapable() const;

	UFUNCTION(BlueprintPure, Category="AVS|Animation")
	bool IsMovementTemporarilyLocked() const;

	UFUNCTION(BlueprintCallable, Category="AVS|Animation")
	bool PrepareForMovement();

protected:
	virtual void BeginPlay() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

private:
	void UpdateLocomotion(float DeltaTime);
	void UpdateActivityPlayback(float DeltaTime);
	void ApplyActivityPose();
	void ApplyMovementMatchSettings();
	void UpdateDynamicLocomotionPlayRate(float DeltaTime);
	float GetCurrentLocomotionReferenceSpeed() const;
	EAVSAnimationSlot DetermineLocomotionSlot(float Speed) const;
	EAVSAnimationSlot GetTransitionSlot(EAVSAnimationSlot From, EAVSAnimationSlot To) const;
	bool StartSelectedVariant(EAVSAnimationSlot Slot, FName CustomName, bool bLoop, bool bAllowMontageBlend);
	bool StartAnimationEntry(const FAVSNamedAnimation& Entry, EAVSAnimationSlot Slot, bool bLoop, bool bAllowMontageBlend);
	bool StartAsset(UAnimSequenceBase* Animation, bool bLoop, float PlayRate, EAVSAnimationSlot Slot,
		bool bAllowMontageBlend, bool bReverse = false);
	bool StartCurrentEntryEnd(EAVSAnimationSlot NextLocomotionSlot, bool bResumeLocomotion);
	bool ShouldUseReverseTransitionFallback(const FAVSNamedAnimation& Entry) const;
	bool UpdateComposedPlayback(float DeltaTime);
	void ResumeLocomotionImmediate(EAVSAnimationSlot DesiredSlot);
	void StopMovementForMissingLocomotion(EAVSAnimationSlot DesiredSlot);
	bool CanUseMontageBlending() const;
	void ScheduleIdleVariant();
	FString MakeVariantKey(EAVSAnimationSlot Slot, FName CustomName) const;

	UPROPERTY(Transient)
	TSubclassOf<UAnimInstance> SavedAnimationBlueprintClass;

	UPROPERTY(Transient)
	TObjectPtr<UAnimSequenceBase> CurrentAnimation = nullptr;

	UPROPERTY(Transient)
	TObjectPtr<UAnimMontage> ActiveDynamicMontage = nullptr;

	AVS::Composed::Playback ActivityPlayback;
	FAVSResolvedAnimation ResolvedActivity;
	FName ActiveActivityCustomName;
	UPROPERTY(Transient)
	TArray<TObjectPtr<UAnimSequenceBase>> ActivityClips;
	TMap<FString, int32> LastVariantIndices;
	TSet<uint8> WarnedMissingLocomotionSlots;
	FRandomStream RandomStream;
	FAVSNamedAnimation CurrentEntry;
	FAVSNamedAnimation PendingMainEntry;
	EAVSAnimationSlot CurrentSlot = EAVSAnimationSlot::Idle;
	EAVSAnimationSlot CurrentLocomotionSlot = EAVSAnimationSlot::Idle;
	EAVSAnimationSlot PendingLocomotionSlot = EAVSAnimationSlot::Idle;
	bool bActivityOverride = false;
	bool bHasStartedLocomotion = false;
	bool bPlayingTransition = false;
	bool bHasCurrentEntry = false;
	bool bPlayingComposedStart = false;
	bool bPlayingComposedEnd = false;
	bool bPendingMainLoop = false;
	bool bPendingMainAllowMontageBlend = true;
	bool bResumeLocomotionAfterEnd = false;
	bool bHasPendingLocomotionAfterEnd = false;
	EAVSAnimationSlot PendingMainSlot = EAVSAnimationSlot::Idle;
	EAVSAnimationSlot LocomotionAfterEnd = EAVSAnimationSlot::Idle;
	float TransitionTimeRemaining = 0.0f;
	float ComposedTimeRemaining = 0.0f;
	float IdleVariantTimeRemaining = 0.0f;
	float MovementPreparationGraceRemaining = 0.0f;
	float CurrentBasePlayRate = 1.0f;
	float CurrentAppliedPlayRate = 1.0f;
};
