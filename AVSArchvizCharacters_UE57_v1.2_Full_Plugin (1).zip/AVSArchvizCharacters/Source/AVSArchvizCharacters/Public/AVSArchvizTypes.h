#pragma once

#include "CoreMinimal.h"
#include "AVSArchvizTypes.generated.h"

class AAVSCrowdRoute;

UENUM(BlueprintType)
enum class EAVSViewerMode : uint8
{
	Walking UMETA(DisplayName="Walking"),
	Orbiting UMETA(DisplayName="Orbiting")
};

UENUM(BlueprintType)
enum class EAVSNPCState : uint8
{
	Inactive,
	Idle,
	Wander,
	FollowRoute,
	FollowActor,
	Queue,
	AtPointOfInterest,
	Activity,
	Paused,
	Conversation
};

UENUM(BlueprintType)
enum class EAVSModularSlot : uint8
{
	Head,
	Hair,
	Hat,
	Chest,
	Legs,
	Feet,
	HandsOrGloves,
	Eyeglasses,
	Accessory01,
	Accessory02
};

UENUM(BlueprintType)
enum class EAVSCharacterSex : uint8
{
	Male,
	Female,
	Unisex UMETA(DisplayName="Unisex / Any"),
	Custom
};

UENUM(BlueprintType)
enum class EAVSAnimationSlot : uint8
{
	Idle,
	Walk,
	Run,
	WalkStart,
	WalkStop,
	RunStart,
	RunStop,
	Talk,
	PhoneStart,
	PhoneLoop,
	PhoneEnd,
	Texting,
	Drink,
	Smoke,
	Stretch,
	Custom
};

UENUM(BlueprintType)
enum class EAVSGlobalQualityPreset : uint8
{
	Cinematic,
	High,
	Balanced,
	Performance,
	Custom
};

UENUM(BlueprintType)
enum class EAVSExclusionMaskShape : uint8
{
	Spline,
	Box
};

UENUM(BlueprintType)
enum class EAVSCoupleGenderMode : uint8
{
	Any,
	SameSex UMETA(DisplayName="Same Sex"),
	MixedSex UMETA(DisplayName="Different Sex")
};

UENUM(BlueprintType)
enum class EAVSGroupFormation : uint8
{
	SideBySide UMETA(DisplayName="Side by Side"),
	VFormation UMETA(DisplayName="V Formation"),
	Line,
	Circle
};

UENUM(BlueprintType)
enum class EAVSRoutePurpose : uint8
{
	PedestrianPath UMETA(DisplayName="Path Only"),
	ZoneConnector UMETA(DisplayName="Crowd-Zone Connector Only"),
	PathAndConnector UMETA(DisplayName="Path + Crowd-Zone Connector")
};

UENUM(BlueprintType)
enum class EAVSPOIPreviewPhase : uint8
{
	Idle,
	Start,
	ActivityLoop UMETA(DisplayName="Activity / Loop"),
	End
};

USTRUCT(BlueprintType)
struct AVSARCHVIZCHARACTERS_API FAVSZoneRouteChoice
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Route")
	TObjectPtr<AAVSCrowdRoute> Route = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Route", meta=(ClampMin="0.0"))
	float Weight = 1.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Route")
	bool bLoop = false;
};

USTRUCT(BlueprintType)
struct AVSARCHVIZCHARACTERS_API FAVSWeightedActivity
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Activity")
	EAVSAnimationSlot Slot = EAVSAnimationSlot::Idle;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Activity", meta=(EditCondition="Slot == EAVSAnimationSlot::Custom"))
	FName CustomName = NAME_None;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Activity", meta=(ClampMin="0.0"))
	float Weight = 1.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Activity", meta=(ClampMin="0.1"))
	float MinDuration = 3.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Activity", meta=(ClampMin="0.1"))
	float MaxDuration = 8.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Activity")
	bool bLoop = true;
};

FORCEINLINE bool AVSIsSexCompatible(EAVSCharacterSex CharacterSex, EAVSCharacterSex AssetSex)
{
	return AssetSex == EAVSCharacterSex::Unisex || CharacterSex == AssetSex;
}

USTRUCT(BlueprintType)
struct AVSARCHVIZCHARACTERS_API FAVSViewerState
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS")
	EAVSViewerMode Mode = EAVSViewerMode::Walking;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS")
	float OrbitZoom = 0.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS")
	FVector ViewLocation = FVector::ZeroVector;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS")
	FVector ViewDirection = FVector::ForwardVector;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS")
	bool bCrowdEnabled = true;
};

USTRUCT(BlueprintType)
struct AVSARCHVIZCHARACTERS_API FAVSQualityTier
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS", meta=(ClampMin="0"))
	float MaxDistance = 5000.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS", meta=(ClampMin="0.0"))
	float TickInterval = 0.1f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS")
	bool bEnableMovement = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS")
	bool bEnableAnimation = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS")
	bool bCastShadows = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS")
	bool bEnableCollision = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS")
	bool bUseAnimationUpdateRateOptimization = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS")
	bool bOnlyTickPoseWhenRendered = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS")
	bool bEnableAvoidance = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS", meta=(ClampMin="0"))
	int32 ForcedLOD = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS", meta=(ClampMin="0.0", ToolTip="Zero keeps the mesh asset's normal cull behavior."))
	float MaxDrawDistance = 0.0f;
};

USTRUCT(BlueprintType)
struct AVSARCHVIZCHARACTERS_API FAVSSpawnRequest
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS")
	FTransform Transform = FTransform::Identity;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS")
	TObjectPtr<class UAVSCharacterProfile> CharacterProfile = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS")
	TObjectPtr<class UAVSAnimationProfile> AnimationProfile = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS")
	TObjectPtr<AActor> Generator = nullptr;
};
