#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "Tickable.h"
#include "AVSArchvizTypes.h"
#include "AVSCrowdSubsystem.generated.h"

class AAVSArchvizNPCCharacter;
class AAVSCrowdExclusionMask;
class AAVSCrowdGenerator;
class AAVSCrowdGlobalController;
class AAVSCrowdZone;
class AAVSNavigationInvokerAnchor;
class UAVSArchvizCrowdComponent;

UCLASS()
class AVSARCHVIZCHARACTERS_API UAVSCrowdSubsystem : public UTickableWorldSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;
	virtual void Tick(float DeltaTime) override;
	virtual TStatId GetStatId() const override;
	virtual bool IsTickableInEditor() const override { return false; }
	virtual bool DoesSupportWorldType(EWorldType::Type WorldType) const override;

	void RegisterViewer(UAVSArchvizCrowdComponent* Viewer);
	void UnregisterViewer(UAVSArchvizCrowdComponent* Viewer);
	void RegisterGenerator(AAVSCrowdGenerator* Generator);
	void UnregisterGenerator(AAVSCrowdGenerator* Generator);
	void RegisterExclusionMask(AAVSCrowdExclusionMask* Mask);
	void UnregisterExclusionMask(AAVSCrowdExclusionMask* Mask);
	void RegisterGlobalController(AAVSCrowdGlobalController* Controller);
	void UnregisterGlobalController(AAVSCrowdGlobalController* Controller);
	void RegisterNPC(AAVSArchvizNPCCharacter* NPC);
	void UnregisterNPC(AAVSArchvizNPCCharacter* NPC);

	UFUNCTION(BlueprintCallable, Category="AVS|Crowd")
	AAVSArchvizNPCCharacter* AcquireNPC(TSubclassOf<AAVSArchvizNPCCharacter> NPCClass, const FAVSSpawnRequest& Request);

	UFUNCTION(BlueprintCallable, Category="AVS|Crowd")
	void ReleaseNPC(AAVSArchvizNPCCharacter* NPC);

	UFUNCTION(BlueprintCallable, Category="AVS|Crowd")
	void ReleaseNPCsOwnedBy(AActor* Generator);

	UFUNCTION(BlueprintCallable, Category="AVS|Crowd")
	void ClearAllGeneratedCrowds();

	UFUNCTION(BlueprintPure, Category="AVS|Crowd")
	bool IsLocationExcluded(const FVector& WorldLocation, bool bForSpawning = true) const;

	UFUNCTION(BlueprintPure, Category="AVS|Crowd")
	bool GetPrimaryViewerState(FAVSViewerState& OutState) const;

	UFUNCTION(BlueprintPure, Category="AVS|Crowd")
	int32 GetActiveNPCCount() const { return ActiveNPCs.Num(); }

	UFUNCTION(BlueprintPure, Category="AVS|Crowd")
	int32 GetPooledNPCCount() const { return PooledNPCs.Num(); }

	float GetDensityScale() const;
	int32 GetEffectiveMaxActiveNPCs() const;
	int32 GetEffectiveWarmPoolSize() const;
	AAVSCrowdGlobalController* GetGlobalController() const { return GlobalController.Get(); }

private:
	void CompactReferences();
	void ApplyQualityTiers(const FAVSViewerState& ViewerState);
	void UpdateProximityConversations();
	void UpdateViewerNavigationInvoker(const FAVSViewerState& ViewerState);
	void DestroyViewerNavigationInvoker();

	TArray<TWeakObjectPtr<UAVSArchvizCrowdComponent>> Viewers;
	TArray<TWeakObjectPtr<AAVSCrowdGenerator>> Generators;
	TArray<TWeakObjectPtr<AAVSCrowdExclusionMask>> ExclusionMasks;
	TWeakObjectPtr<AAVSCrowdGlobalController> GlobalController;
	TArray<TWeakObjectPtr<AAVSArchvizNPCCharacter>> RegisteredNPCs;

	UPROPERTY(Transient)
	TArray<TObjectPtr<AAVSArchvizNPCCharacter>> ActiveNPCs;

	UPROPERTY(Transient)
	TArray<TObjectPtr<AAVSArchvizNPCCharacter>> PooledNPCs;

	UPROPERTY(Transient)
	TObjectPtr<AAVSNavigationInvokerAnchor> ViewerNavigationInvoker = nullptr;

	float TimeUntilEvaluation = 0.0f;
	float NextConversationEvaluationTime = 0.0f;
	TMap<TWeakObjectPtr<AAVSCrowdGenerator>, float> ZoneConversationEvaluationTimes;
	int32 ConversationCandidateCursor = 0;
	int32 QualityUpdateCursor = 0;
	FRandomStream SocialRandom;
};
