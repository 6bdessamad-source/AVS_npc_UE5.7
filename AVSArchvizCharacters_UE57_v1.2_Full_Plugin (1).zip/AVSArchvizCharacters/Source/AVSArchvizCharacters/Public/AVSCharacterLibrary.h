#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "AVSCharacterLibrary.generated.h"

class UAVSAnimationProfile;
class UAVSCharacterProfile;

USTRUCT(BlueprintType)
struct AVSARCHVIZCHARACTERS_API FAVSCharacterLibraryEntry
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Character")
	bool bEnabled = true;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Character")
	TObjectPtr<UAVSCharacterProfile> CharacterProfile = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Character")
	TObjectPtr<UAVSAnimationProfile> AnimationProfile = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Character", meta=(ClampMin="0.0"))
	float Weight = 1.0f;
};

UCLASS(BlueprintType)
class AVSARCHVIZCHARACTERS_API UAVSCharacterLibrary : public UPrimaryDataAsset
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Characters")
	TArray<FAVSCharacterLibraryEntry> Characters;

	bool SelectRandom(FRandomStream& Stream, UAVSCharacterProfile*& OutCharacter, UAVSAnimationProfile*& OutAnimation) const;

	UFUNCTION(BlueprintCallable, Category="AVS|Validation")
	bool ValidateLibrary(TArray<FText>& OutIssues) const;

	UFUNCTION(CallInEditor, Category="AVS|Validation")
	void ValidateAndLog() const;
};
