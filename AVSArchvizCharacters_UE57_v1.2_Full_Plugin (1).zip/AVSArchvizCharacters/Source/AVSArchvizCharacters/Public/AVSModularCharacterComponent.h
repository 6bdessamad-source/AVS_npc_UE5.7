#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "AVSArchvizTypes.h"
#include "AVSModularCharacterComponent.generated.h"

class UAVSCharacterProfile;
class USkeletalMeshComponent;
class UStaticMeshComponent;

UCLASS(ClassGroup=(AVS), meta=(BlueprintSpawnableComponent))
class AVSARCHVIZCHARACTERS_API UAVSModularCharacterComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UAVSModularCharacterComponent();

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="AVS|Appearance")
	TObjectPtr<UAVSCharacterProfile> CharacterProfile = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Appearance")
	bool bApplyOnBeginPlay = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Appearance", meta=(ToolTip="Per-NPC offset added to the Character Profile modular random seed."))
	int32 RandomSeedOffset = 0;

	UFUNCTION(BlueprintCallable, Category="AVS|Appearance")
	bool ApplyProfile(UAVSCharacterProfile* NewProfile);

	UFUNCTION(BlueprintCallable, CallInEditor, Category="AVS|Appearance")
	bool RandomizeModularParts();

	UFUNCTION(BlueprintCallable, Category="AVS|Appearance")
	void ClearModularParts();

	UFUNCTION(BlueprintPure, Category="AVS|Appearance")
	USkeletalMeshComponent* GetPartComponent(EAVSModularSlot Slot) const;

	UFUNCTION(BlueprintCallable, Category="AVS|Validation")
	bool ValidateCurrentAppearance(TArray<FText>& OutIssues) const;

protected:
	virtual void BeginPlay() override;
	virtual void OnUnregister() override;

private:
	USkeletalMeshComponent* GetBodyMesh() const;
	const struct FAVSSkinnedPartDefinition* SelectPartForSlot(
		const TArray<const struct FAVSSkinnedPartDefinition*>& Candidates,
		FRandomStream& Stream) const;
	void ApplyPart(const struct FAVSSkinnedPartDefinition& Definition, USkeletalMeshComponent* Leader);
	void ApplyProp(const struct FAVSPropDefinition& Definition, bool bRightHand, USkeletalMeshComponent* Leader);
	void RestoreOriginalBody();

	UPROPERTY(Transient)
	TMap<EAVSModularSlot, TObjectPtr<USkeletalMeshComponent>> GeneratedParts;

	UPROPERTY(Transient)
	TObjectPtr<UStaticMeshComponent> RightPropComponent = nullptr;

	UPROPERTY(Transient)
	TObjectPtr<UStaticMeshComponent> LeftPropComponent = nullptr;

	UPROPERTY(Transient)
	TObjectPtr<class USkeletalMesh> OriginalBodyMesh = nullptr;

	UPROPERTY(Transient)
	TSubclassOf<class UAnimInstance> OriginalAnimClass;

	bool bSavedOriginalBody = false;
	int32 AppearanceRoll = 0;
};
