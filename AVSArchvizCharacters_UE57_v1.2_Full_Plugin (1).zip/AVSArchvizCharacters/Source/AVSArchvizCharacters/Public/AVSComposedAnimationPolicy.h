#pragma once

// Engine-independent production policy. Used by runtime and editor preview; tested by Tests/.
#include <algorithm>
#include <cmath>

namespace AVS { namespace Composed {
enum class Clip { None, Start, Main, End };
enum class Phase { Inactive, Entry, Body, Exit };
inline double Safe(double Value, double Default, double Min, double Max)
{
    return std::isfinite(Value) ? std::max(Min, std::min(Max, Value)) : Default;
}
struct Clips { double Start = 0, Main = 0, End = 0; };
struct Options
{
    bool Smart = true, Reverse = true, Hold = true, Loop = true;
    double HoldPosition = -1; // -1: last Start frame / first End frame.
    double Rate = 1, Duration = 8; // negative duration: explicit caller-owned exit.
};
struct Segment
{
    Clip Source = Clip::None;
    double From = 0, To = 1, Rate = 1, Seconds = 0;
};
struct Plan
{
    bool Valid = false, Hold = false, Loop = true;
    Segment Entry, Body, Exit;
    double Duration = 8;
};
inline Segment Slice(Clip Source, double Length, double From, double To, double Rate)
{
    Segment Result;
    Result.Source = Source;
    Result.From = From;
    Result.To = To;
    Result.Rate = To < From ? -Rate : Rate;
    Result.Seconds = std::abs(To - From) * Length / Rate;
    return Result;
}
inline Plan Resolve(Clips C, Options O)
{
    Plan P; P.Loop = O.Loop;
    C.Start = Safe(C.Start, 0, 0, 86400); C.Main = Safe(C.Main, 0, 0, 86400); C.End = Safe(C.End, 0, 0, 86400);
    const double Rate = Safe(O.Rate, 1, .01, 8);
    P.Duration = O.Duration < 0 && std::isfinite(O.Duration) ? -1 : Safe(O.Duration, 8, .01, 86400);
    const bool Reverse = O.Smart && O.Reverse;
    const bool Hold = O.Smart && O.Hold;
    if (C.Main > 0)
    {
        if (C.Start > 0) P.Entry = Slice(Clip::Start, C.Start, 0, 1, Rate);
        else if (C.End > 0 && Reverse) P.Entry = Slice(Clip::End, C.End, 1, 0, Rate);
        P.Body = Slice(Clip::Main, C.Main, 0, 1, Rate);
        if (C.End > 0) P.Exit = Slice(Clip::End, C.End, 0, 1, Rate);
        else if (C.Start > 0 && Reverse) P.Exit = Slice(Clip::Start, C.Start, 1, 0, Rate);
        P.Valid = true;
        return P;
    }
    if (!Hold) return P;
    if (C.Start > 0 && (C.End > 0 || Reverse))
    {
        const double Position = O.HoldPosition == -1 ? 1 : Safe(O.HoldPosition, 1, 0, 1);
        P.Entry = Slice(Clip::Start, C.Start, 0, Position, Rate);
        P.Body = Slice(Clip::Start, C.Start, Position, Position, Rate);
        P.Exit = C.End > 0 ? Slice(Clip::End, C.End, 0, 1, Rate) : Slice(Clip::Start, C.Start, Position, 0, Rate);
    }
    else if (C.End > 0 && Reverse)
    {
        const double Position = O.HoldPosition == -1 ? 0 : Safe(O.HoldPosition, 0, 0, 1);
        P.Entry = Slice(Clip::End, C.End, 1, Position, Rate);
        P.Body = Slice(Clip::End, C.End, Position, Position, Rate);
        P.Exit = Slice(Clip::End, C.End, Position, 1, Rate);
    }
    else return P;
    P.Hold = true; P.Valid = true;
    return P;
}

// Entry/hold/exit own movement until complete. Repeated exits cannot reset progress.
class Playback
{
public:
    bool Begin(const Plan& InPlan)
    {
        if (IsActive() || !InPlan.Valid) return false;
        P = InPlan; ExitRequested = false; Elapsed = 0;
        Current = P.Entry.Source == Clip::None || P.Entry.Seconds <= 0 ? Phase::Body : Phase::Entry;
        return true;
    }
    void Reset() { P = Plan(); Current = Phase::Inactive; Elapsed = 0; ExitRequested = false; }
    bool IsActive() const { return Current != Phase::Inactive; }
    bool CanMove() const { return !IsActive(); }
    Phase GetPhase() const { return Current; }
    const Segment& GetSegment() const
    {
        return Current == Phase::Entry ? P.Entry : Current == Phase::Exit ? P.Exit : P.Body;
    }
    double GetPosition() const
    {
        const Segment& S = GetSegment();
        if (Current == Phase::Body)
        {
            if (P.Hold || S.Seconds <= 0) return S.From;
            return S.From + (S.To-S.From) * (P.Loop ? std::fmod(Elapsed, S.Seconds) : std::min(Elapsed, S.Seconds)) / S.Seconds;
        }
        return S.Seconds > 0 ? S.From + (S.To-S.From) * std::min(1.0, Elapsed / S.Seconds) : S.To;
    }
    void RequestExit()
    {
        if (!IsActive() || ExitRequested) return;
        ExitRequested = true;
        // A synthesized exit can safely retrace exactly the traversed segment immediately.
        if (Current == Phase::Entry && P.Entry.Source == P.Exit.Source)
        {
            const double Position = GetPosition();
            const double FullLengthOverRate = std::abs(P.Exit.To - P.Exit.From) > 0
                ? P.Exit.Seconds / std::abs(P.Exit.To - P.Exit.From) : 0;
            P.Exit.From = Position;
            P.Exit.Seconds = std::abs(P.Exit.To - Position) * FullLengthOverRate;
            EnterExit();
        }
        else if (Current == Phase::Body) EnterExit();
        // A supplied different exit waits for the compatible entry contact pose.
    }
    void Advance(double Delta)
    {
        if (!IsActive()) return;
        Delta = Safe(Delta, 0, 0, 86400);
        for (int Guard = 0; Guard < 4 && IsActive(); ++Guard)
        {
            const double Limit = Current == Phase::Body ? (P.Duration < 0 ? 1e100 : P.Duration) : GetSegment().Seconds;
            const double Used = std::min(Delta, std::max(0.0, Limit - Elapsed));
            Elapsed += Used; Delta -= Used;
            if (Elapsed + 1e-9 < Limit) break;
            if (Current == Phase::Entry) { Current = Phase::Body; Elapsed = 0; if (ExitRequested) EnterExit(); }
            else if (Current == Phase::Body) EnterExit();
            else { Current = Phase::Inactive; Elapsed = 0; }
            if (Delta <= 0 && Current != Phase::Inactive && GetSegment().Seconds > 0) break;
        }
    }
private:
    void EnterExit()
    {
        Current = P.Exit.Source != Clip::None && P.Exit.Seconds > 0 ? Phase::Exit : Phase::Inactive;
        Elapsed = 0;
    }
    Plan P;
    Phase Current = Phase::Inactive;
    double Elapsed = 0;
    bool ExitRequested = false;
};
} }
