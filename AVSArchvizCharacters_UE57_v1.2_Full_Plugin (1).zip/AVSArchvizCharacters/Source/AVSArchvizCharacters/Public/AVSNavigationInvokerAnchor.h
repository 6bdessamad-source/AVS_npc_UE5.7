#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "AVSNavigationInvokerAnchor.generated.h"

class UNavigationInvokerComponent;

/** Runtime-only navigation anchor managed by the AVS Crowd Subsystem. */
UCLASS(NotBlueprintable, NotPlaceable, Transient)
class AVSARCHVIZCHARACTERS_API AAVSNavigationInvokerAnchor : public AActor
{
	GENERATED_BODY()

public:
	AAVSNavigationInvokerAnchor();

	UPROPERTY(VisibleAnywhere, Category="AVS|Navigation")
	TObjectPtr<USceneComponent> SceneRoot;

	UPROPERTY(VisibleAnywhere, Category="AVS|Navigation")
	TObjectPtr<UNavigationInvokerComponent> NavigationInvoker;

	void ConfigureRadii(float GenerationRadius, float RemovalRadius);
};
