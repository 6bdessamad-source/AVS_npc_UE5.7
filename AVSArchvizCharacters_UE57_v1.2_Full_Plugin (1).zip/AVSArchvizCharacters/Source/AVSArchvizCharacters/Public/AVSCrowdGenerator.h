#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "AVSArchvizTypes.h"
#include "AVSCrowdGenerator.generated.h"

class AAVSArchvizNPCCharacter;
class UAVSAnimationProfile;
class UAVSCharacterLibrary;
class UAVSCharacterProfile;
class UBillboardComponent;

UCLASS(Abstract, Blueprintable)
class AVSARCHVIZCHARACTERS_API AAVSCrowdGenerator : public AActor
{
	GENERATED_BODY()

public:
	AAVSCrowdGenerator();

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="AVS")
	TObjectPtr<USceneComponent> SceneRoot;

#if WITH_EDITORONLY_DATA
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="AVS|Editor")
	TObjectPtr<UBillboardComponent> EditorBillboard;
#endif

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Generation")
	bool bEnabled = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Generation", meta=(ClampMin="0"))
	int32 NPCCount = 10;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Generation")
	TSubclassOf<AAVSArchvizNPCCharacter> NPCClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Profiles")
	TArray<TObjectPtr<UAVSCharacterProfile>> CharacterProfiles;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Profiles")
	TArray<TObjectPtr<UAVSAnimationProfile>> AnimationProfiles;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Profiles")
	TObjectPtr<UAVSCharacterLibrary> CharacterLibrary = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Activation", meta=(ClampMin="0"))
	float WalkingActivationRadius = 10000.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Activation", meta=(ClampMin="0"))
	float OrbitActivationRadius = 30000.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Activation", meta=(ClampMin="0"))
	float OrbitActivationZoom = 2500.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Activation", meta=(ClampMin="0"))
	float OrbitDeactivationZoom = 3000.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Generation")
	int32 RandomSeed = 1337;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AVS|Debug")
	bool bDrawDebug = false;

	UFUNCTION(BlueprintCallable, Category="AVS|Generation")
	void GenerateNow();

	UFUNCTION(BlueprintCallable, Category="AVS|Generation")
	void ClearGeneratedNPCs();

	UFUNCTION(BlueprintPure, Category="AVS|Generation")
	int32 GetGeneratedNPCCount() const { return ActiveNPCs.Num(); }

	UFUNCTION(BlueprintPure, Category="AVS|Generation")
	virtual int32 GetEffectiveNPCCount() const;

	virtual bool ContainsWorldLocation(const FVector& WorldLocation) const;
	virtual void AcceptConnectorArrival(AAVSArchvizNPCCharacter* NPC);

	bool SupportsProfiles(const UAVSCharacterProfile* CharacterProfile, const UAVSAnimationProfile* AnimationProfile) const;

	void UpdateForViewer(const FAVSViewerState& ViewerState);

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual bool MakeSpawnTransform(int32 NPCIndex, FTransform& OutTransform);
	virtual void ConfigureSpawnedNPC(AAVSArchvizNPCCharacter* NPC, int32 NPCIndex);
	virtual void DrawGeneratorDebug(const FAVSViewerState& ViewerState) const;

	UAVSCharacterProfile* SelectCharacterProfile();
	UAVSAnimationProfile* SelectAnimationProfile(const UAVSCharacterProfile* CharacterProfile);
	virtual void SelectProfiles(int32 NPCIndex, UAVSCharacterProfile*& OutCharacter, UAVSAnimationProfile*& OutAnimation);
	void SpawnMissingNPCs();
	void TrimExcessNPCs();

	UPROPERTY(Transient)
	TArray<TObjectPtr<AAVSArchvizNPCCharacter>> ActiveNPCs;

	FRandomStream RandomStream;
	bool bGeneratorActive = false;
};
