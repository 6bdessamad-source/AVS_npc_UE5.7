#include "AVSArchvizNPCAIController.h"

#include "AVSAnimationProfile.h"
#include "AVSAnimationDriverComponent.h"
#include "Navigation/PathFollowingComponent.h"
#include "AVSArchvizCharacters.h"
#include "AVSArchvizNPCCharacter.h"
#include "AVSCharacterLibrary.h"
#include "AVSCharacterProfile.h"
#include "AVSNPCBehaviorComponent.h"
#include "BehaviorTree/BehaviorTree.h"

AAVSArchvizNPCAIController::AAVSArchvizNPCAIController()
{
	bAttachToPawn = true;
}

FPathFollowingRequestResult AAVSArchvizNPCAIController::MoveTo(const FAIMoveRequest& MoveRequest, FNavPathSharedPtr* OutPath)
{
	const AAVSArchvizNPCCharacter* NPC = Cast<AAVSArchvizNPCCharacter>(GetPawn());
	if (!NPC || NPC->IsHidden() || !NPC->AnimationDriver || !NPC->AnimationDriver->IsComponentTickEnabled() || !NPC->AnimationDriver->PrepareForMovement())
	{
		FPathFollowingRequestResult FailedResult;
		FailedResult.Code = EPathFollowingRequestResult::Failed;
		return FailedResult;
	}
	return Super::MoveTo(MoveRequest, OutPath);
}

void AAVSArchvizNPCAIController::OnPossess(APawn* InPawn)
{
	Super::OnPossess(InPawn);

	if (bAutoSelectCompatibleProfilesOnPossess)
	{
		ApplyRandomCompatibleProfiles();
	}

	const bool bStartedBehaviorTree = bRunBehaviorTreeOnPossess && BehaviorTreeAsset && RunBehaviorTree(BehaviorTreeAsset);
	if (AAVSArchvizNPCCharacter* NPC = Cast<AAVSArchvizNPCCharacter>(InPawn))
		NPC->Behavior->SetExternalBehaviorOwnership(bStartedBehaviorTree);
	if (!bStartedBehaviorTree && bStartWanderingWithoutBehaviorTree)
	{
		if (AAVSArchvizNPCCharacter* NPC = Cast<AAVSArchvizNPCCharacter>(InPawn))
		{
			NPC->Behavior->StartWandering(NPC->GetActorLocation(), DefaultWanderRadius);
		}
	}
}

UAVSCharacterProfile* AAVSArchvizNPCAIController::SelectCharacterProfile(FRandomStream& Stream) const
{
	float TotalWeight = 0.0f;
	for (const UAVSCharacterProfile* Profile : CharacterProfiles)
	{
		if (Profile)
		{
			TotalWeight += FMath::Max(0.0f, Profile->SelectionWeight);
		}
	}
	if (TotalWeight <= 0.0f)
	{
		TArray<UAVSCharacterProfile*> ValidProfiles;
		for (UAVSCharacterProfile* Profile : CharacterProfiles)
		{
			if (Profile)
			{
				ValidProfiles.Add(Profile);
			}
		}
		return ValidProfiles.IsEmpty() ? nullptr : ValidProfiles[Stream.RandRange(0, ValidProfiles.Num() - 1)];
	}

	float Choice = Stream.FRandRange(0.0f, TotalWeight);
	for (UAVSCharacterProfile* Profile : CharacterProfiles)
	{
		if (!Profile)
		{
			continue;
		}
		Choice -= FMath::Max(0.0f, Profile->SelectionWeight);
		if (Choice <= 0.0f)
		{
			return Profile;
		}
	}
	return nullptr;
}

UAVSAnimationProfile* AAVSArchvizNPCAIController::SelectCompatibleAnimation(
	const UAVSCharacterProfile* CharacterProfile,
	FRandomStream& Stream) const
{
	TArray<UAVSAnimationProfile*> CompatibleProfiles;
	for (UAVSAnimationProfile* Profile : AnimationProfiles)
	{
		if (Profile && Profile->IsCompatibleWithCharacter(CharacterProfile))
		{
			CompatibleProfiles.Add(Profile);
		}
	}
	return CompatibleProfiles.IsEmpty() ? nullptr : CompatibleProfiles[Stream.RandRange(0, CompatibleProfiles.Num() - 1)];
}

bool AAVSArchvizNPCAIController::ApplyRandomCompatibleProfiles()
{
	AAVSArchvizNPCCharacter* NPC = Cast<AAVSArchvizNPCCharacter>(GetPawn());
	if (!NPC)
	{
		return false;
	}

	FRandomStream Stream(RandomSeed ^ GetUniqueID() ^ NPC->GetUniqueID());
	UAVSCharacterProfile* SelectedCharacter = bOverridePawnDefaultProfiles ? nullptr : NPC->DefaultCharacterProfile.Get();
	UAVSAnimationProfile* Animation = bOverridePawnDefaultProfiles ? nullptr : NPC->DefaultAnimationProfile.Get();

	if (!SelectedCharacter && CharacterLibrary)
	{
		CharacterLibrary->SelectRandom(Stream, SelectedCharacter, Animation);
	}
	if (!SelectedCharacter)
	{
		SelectedCharacter = SelectCharacterProfile(Stream);
	}
	if (!SelectedCharacter)
	{
		UE_LOG(LogAVSArchvizCharacters, Warning, TEXT("%s has no Character Profile to select."), *GetName());
		return false;
	}
	if (!Animation || !Animation->IsCompatibleWithCharacter(SelectedCharacter))
	{
		Animation = SelectCompatibleAnimation(SelectedCharacter, Stream);
	}
	if (!Animation)
	{
		UE_LOG(LogAVSArchvizCharacters, Warning,
			TEXT("%s found no animation compatible with character '%s'. Check sex tag, Rig ID, and target Skeleton."),
			*GetName(), *GetNameSafe(SelectedCharacter));
		return false;
	}
	const bool bApplied = NPC->ApplyProfiles(SelectedCharacter, Animation);
	// A placed pawn that failed setup can be repaired later. Generated/pool entries activate through AcquireNPC.
	if (bApplied && NPC->IsHidden() && !NPC->GetOwner() && !NPC->GetOwningGenerator()) NPC->SetPooled(false);
	return bApplied;
}
