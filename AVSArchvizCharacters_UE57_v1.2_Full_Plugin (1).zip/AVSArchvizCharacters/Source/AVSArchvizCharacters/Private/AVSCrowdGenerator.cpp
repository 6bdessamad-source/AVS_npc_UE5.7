#include "AVSCrowdGenerator.h"

#include "AVSAnimationProfile.h"
#include "AVSArchvizNPCCharacter.h"
#include "AVSCharacterProfile.h"
#include "AVSCharacterLibrary.h"
#include "AVSCrowdSubsystem.h"
#include "AVSNPCBehaviorComponent.h"
#include "Components/BillboardComponent.h"
#include "Components/SceneComponent.h"
#include "DrawDebugHelpers.h"
#include "Engine/Texture2D.h"
#include "UObject/ConstructorHelpers.h"

AAVSCrowdGenerator::AAVSCrowdGenerator()
{
	PrimaryActorTick.bCanEverTick = false;
	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	SetRootComponent(SceneRoot);
	NPCClass = AAVSArchvizNPCCharacter::StaticClass();

#if WITH_EDITORONLY_DATA
	EditorBillboard = CreateEditorOnlyDefaultSubobject<UBillboardComponent>(TEXT("EditorBillboard"));
	if (EditorBillboard)
	{
		EditorBillboard->SetupAttachment(SceneRoot);
		EditorBillboard->SetRelativeLocation(FVector(0.0f, 0.0f, 100.0f));
		EditorBillboard->SetHiddenInGame(true);
		EditorBillboard->SetIsVisualizationComponent(true);
		static ConstructorHelpers::FObjectFinder<UTexture2D> Sprite(TEXT("/Engine/EditorResources/S_Actor.S_Actor"));
		if (Sprite.Succeeded())
		{
			EditorBillboard->SetSprite(Sprite.Object);
		}
	}
#endif
}

void AAVSCrowdGenerator::BeginPlay()
{
	Super::BeginPlay();
	RandomStream.Initialize(RandomSeed);
	if (UAVSCrowdSubsystem* Subsystem = GetWorld()->GetSubsystem<UAVSCrowdSubsystem>())
	{
		Subsystem->RegisterGenerator(this);
	}
}

void AAVSCrowdGenerator::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (GetWorld())
	{
		if (UAVSCrowdSubsystem* Subsystem = GetWorld()->GetSubsystem<UAVSCrowdSubsystem>())
		{
			Subsystem->UnregisterGenerator(this);
		}
	}
	ActiveNPCs.Reset();
	Super::EndPlay(EndPlayReason);
}

void AAVSCrowdGenerator::UpdateForViewer(const FAVSViewerState& ViewerState)
{
	ActiveNPCs.RemoveAll([](const TObjectPtr<AAVSArchvizNPCCharacter>& NPC) { return !IsValid(NPC) || NPC->IsHidden(); });

	const float Distance = FVector::Dist2D(ViewerState.ViewLocation, GetActorLocation());
	bool bShouldActivate = false;
	if (bEnabled && ViewerState.bCrowdEnabled)
	{
		if (ViewerState.Mode == EAVSViewerMode::Walking)
		{
			bShouldActivate = Distance <= WalkingActivationRadius;
		}
		else
		{
			const float ZoomThreshold = bGeneratorActive ? OrbitDeactivationZoom : OrbitActivationZoom;
			bShouldActivate = Distance <= OrbitActivationRadius && ViewerState.OrbitZoom <= ZoomThreshold;
		}
	}

	if (bShouldActivate)
	{
		bGeneratorActive = true;
		TrimExcessNPCs();
		SpawnMissingNPCs();
	}
	else if (bGeneratorActive || !ActiveNPCs.IsEmpty())
	{
		bGeneratorActive = false;
		ClearGeneratedNPCs();
	}

	if (bDrawDebug)
	{
		DrawGeneratorDebug(ViewerState);
	}
}

void AAVSCrowdGenerator::TrimExcessNPCs()
{
	UAVSCrowdSubsystem* Subsystem = GetWorld()->GetSubsystem<UAVSCrowdSubsystem>();
	while (Subsystem && ActiveNPCs.Num() > GetEffectiveNPCCount())
	{
		AAVSArchvizNPCCharacter* NPC = ActiveNPCs.Pop();
		Subsystem->ReleaseNPC(NPC);
	}
}

void AAVSCrowdGenerator::GenerateNow()
{
	bGeneratorActive = true;
	SpawnMissingNPCs();
}

void AAVSCrowdGenerator::SpawnMissingNPCs()
{
	UAVSCrowdSubsystem* Subsystem = GetWorld()->GetSubsystem<UAVSCrowdSubsystem>();
	if (!Subsystem)
	{
		return;
	}
	const int32 TargetCount = GetEffectiveNPCCount();
	int32 Attempts = 0;
	while (ActiveNPCs.Num() < TargetCount && Attempts < TargetCount * 4 + 4)
	{
		const int32 NPCIndex = ActiveNPCs.Num();
		FTransform SpawnTransform;
		++Attempts;
		if (!MakeSpawnTransform(NPCIndex, SpawnTransform))
		{
			continue;
		}
		if (Subsystem->IsLocationExcluded(SpawnTransform.GetLocation(), true))
		{
			continue;
		}

		FAVSSpawnRequest Request;
		Request.Transform = SpawnTransform;
		UAVSCharacterProfile* SelectedCharacter = nullptr;
		UAVSAnimationProfile* SelectedAnimation = nullptr;
		SelectProfiles(NPCIndex, SelectedCharacter, SelectedAnimation);
		Request.CharacterProfile = SelectedCharacter;
		Request.AnimationProfile = SelectedAnimation;
		Request.Generator = this;
		if (AAVSArchvizNPCCharacter* NPC = Subsystem->AcquireNPC(NPCClass, Request))
		{
			ActiveNPCs.Add(NPC);
			ConfigureSpawnedNPC(NPC, NPCIndex);
		}
		else
		{
			break;
		}
	}
}

int32 AAVSCrowdGenerator::GetEffectiveNPCCount() const
{
	if (UWorld* World = GetWorld())
	{
		if (const UAVSCrowdSubsystem* Subsystem = World->GetSubsystem<UAVSCrowdSubsystem>())
		{
			return FMath::Max(0, FMath::RoundToInt(static_cast<float>(NPCCount) * Subsystem->GetDensityScale()));
		}
	}
	return FMath::Max(0, NPCCount);
}

bool AAVSCrowdGenerator::ContainsWorldLocation(const FVector& WorldLocation) const
{
	return false;
}

void AAVSCrowdGenerator::AcceptConnectorArrival(AAVSArchvizNPCCharacter* NPC)
{
	if (NPC && NPC->Behavior)
	{
		NPC->Behavior->SetBehaviorState(EAVSNPCState::Idle);
	}
}

void AAVSCrowdGenerator::ClearGeneratedNPCs()
{
	if (UAVSCrowdSubsystem* Subsystem = GetWorld()->GetSubsystem<UAVSCrowdSubsystem>())
	{
		for (AAVSArchvizNPCCharacter* NPC : ActiveNPCs)
		{
			Subsystem->ReleaseNPC(NPC);
		}
	}
	ActiveNPCs.Reset();
}

bool AAVSCrowdGenerator::MakeSpawnTransform(int32 NPCIndex, FTransform& OutTransform)
{
	OutTransform = GetActorTransform();
	return true;
}

void AAVSCrowdGenerator::ConfigureSpawnedNPC(AAVSArchvizNPCCharacter* NPC, int32 NPCIndex)
{
}

UAVSCharacterProfile* AAVSCrowdGenerator::SelectCharacterProfile()
{
	float TotalWeight = 0.0f;
	for (const UAVSCharacterProfile* Profile : CharacterProfiles)
	{
		if (Profile)
		{
			TotalWeight += FMath::Max(0.0f, Profile->SelectionWeight);
		}
	}
	if (TotalWeight <= 0.0f)
	{
		return CharacterProfiles.IsEmpty() ? nullptr : CharacterProfiles[RandomStream.RandRange(0, CharacterProfiles.Num() - 1)];
	}
	float Choice = RandomStream.FRandRange(0.0f, TotalWeight);
	for (UAVSCharacterProfile* Profile : CharacterProfiles)
	{
		if (Profile)
		{
			Choice -= FMath::Max(0.0f, Profile->SelectionWeight);
			if (Choice <= 0.0f)
			{
				return Profile;
			}
		}
	}
	return CharacterProfiles.Last();
}

UAVSAnimationProfile* AAVSCrowdGenerator::SelectAnimationProfile(const UAVSCharacterProfile* CharacterProfile)
{
	TArray<UAVSAnimationProfile*> CompatibleProfiles;
	for (UAVSAnimationProfile* Profile : AnimationProfiles)
	{
		if (Profile && Profile->IsCompatibleWithCharacter(CharacterProfile))
		{
			CompatibleProfiles.Add(Profile);
		}
	}
	return CompatibleProfiles.IsEmpty() ? nullptr : CompatibleProfiles[RandomStream.RandRange(0, CompatibleProfiles.Num() - 1)];
}

void AAVSCrowdGenerator::SelectProfiles(int32 NPCIndex, UAVSCharacterProfile*& OutCharacter, UAVSAnimationProfile*& OutAnimation)
{
	if (CharacterLibrary && CharacterLibrary->SelectRandom(RandomStream, OutCharacter, OutAnimation))
	{
		return;
	}
	OutCharacter = SelectCharacterProfile();
	OutAnimation = SelectAnimationProfile(OutCharacter);
	if (OutCharacter && !OutAnimation && !AnimationProfiles.IsEmpty())
	{
		UE_LOG(LogTemp, Warning,
			TEXT("%s found no compatible Animation Profile for '%s'. Check sex tag, Rig ID, and target Skeleton."),
			*GetName(), *GetNameSafe(OutCharacter));
	}
}

bool AAVSCrowdGenerator::SupportsProfiles(const UAVSCharacterProfile* CharacterProfile, const UAVSAnimationProfile* AnimationProfile) const
{
	if (!CharacterProfile || !AnimationProfile)
	{
		return false;
	}
	if (CharacterLibrary)
	{
		for (const FAVSCharacterLibraryEntry& Entry : CharacterLibrary->Characters)
		{
			if (Entry.bEnabled && Entry.CharacterProfile == CharacterProfile && Entry.AnimationProfile == AnimationProfile)
			{
				return true;
			}
		}
		return false;
	}
	const bool bCharacterAccepted = CharacterProfiles.IsEmpty() || CharacterProfiles.ContainsByPredicate(
		[CharacterProfile](const TObjectPtr<UAVSCharacterProfile>& Item) { return Item == CharacterProfile; });
	const bool bAnimationAccepted = AnimationProfiles.IsEmpty() || AnimationProfiles.ContainsByPredicate(
		[AnimationProfile](const TObjectPtr<UAVSAnimationProfile>& Item) { return Item == AnimationProfile; });
	return bCharacterAccepted && bAnimationAccepted && AnimationProfile->IsCompatibleWithCharacter(CharacterProfile);
}

void AAVSCrowdGenerator::DrawGeneratorDebug(const FAVSViewerState& ViewerState) const
{
	DrawDebugSphere(GetWorld(), GetActorLocation(), 100.0f, 12, bGeneratorActive ? FColor::Green : FColor::Red, false, 0.6f, 0, 4.0f);
	DrawDebugLine(GetWorld(), ViewerState.ViewLocation, GetActorLocation(), FColor::Cyan, false, 0.6f, 0, 2.0f);
}
