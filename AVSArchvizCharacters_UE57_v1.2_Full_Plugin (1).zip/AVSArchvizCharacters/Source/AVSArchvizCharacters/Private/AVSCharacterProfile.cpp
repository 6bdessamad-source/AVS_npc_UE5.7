#include "AVSCharacterProfile.h"

#include "AVSArchvizCharacters.h"
#include "Animation/Skeleton.h"
#include "Animation/AnimBlueprintGeneratedClass.h"
#include "Engine/SkeletalMesh.h"

bool UAVSCharacterProfile::ValidateProfile(TArray<FText>& OutIssues) const
{
	OutIssues.Reset();
	USkeletalMesh* Body = BodyMesh.LoadSynchronous();
	if (!Body)
	{
		OutIssues.Add(NSLOCTEXT("AVS", "MissingBody", "Character Profile has no valid Body Mesh."));
		return false;
	}

	if (const UAnimBlueprintGeneratedClass* AnimationClass = Cast<UAnimBlueprintGeneratedClass>(AnimationBlueprint.LoadSynchronous()))
		if (AnimationClass->GetTargetSkeleton() != Body->GetSkeleton())
			OutIssues.Add(NSLOCTEXT("AVS", "AnimationBlueprintSkeletonMismatch", "Animation Blueprint targets another Skeleton. Assign a class generated for the body Skeleton."));

	for (const FAVSSkinnedPartDefinition& Part : ModularParts)
	{
		if (!Part.bEnabled)
		{
			continue;
		}
		if (Part.bNoPart)
		{
			continue;
		}
		USkeletalMesh* Mesh = Part.Mesh.LoadSynchronous();
		if (!Mesh)
		{
			continue;
		}
		if (bRequireSameSkeleton && Mesh->GetSkeleton() != Body->GetSkeleton())
		{
			OutIssues.Add(FText::Format(
				NSLOCTEXT("AVS", "SkeletonMismatch", "Part {0} does not use the Body Mesh Skeleton."),
				FText::FromString(UEnum::GetValueAsString(Part.Slot))));
		}
	}
	return OutIssues.IsEmpty();
}

void UAVSCharacterProfile::ValidateAndLog() const
{
	TArray<FText> Issues;
	if (ValidateProfile(Issues))
	{
		UE_LOG(LogAVSArchvizCharacters, Display, TEXT("Character Profile '%s' is valid."), *GetName());
		return;
	}
	for (const FText& Issue : Issues)
	{
		UE_LOG(LogAVSArchvizCharacters, Warning, TEXT("Character Profile '%s': %s"), *GetName(), *Issue.ToString());
	}
}

USkeleton* UAVSCharacterProfile::ResolveAnimationSkeleton() const
{
	USkeletalMesh* Body = BodyMesh.LoadSynchronous();
	return Body ? Body->GetSkeleton() : nullptr;
}
