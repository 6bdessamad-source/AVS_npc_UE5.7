#include "AVSNPCGroup.h"

#include "AVSArchvizNPCCharacter.h"
#include "AVSNPCBehaviorComponent.h"

AAVSNPCGroup::AAVSNPCGroup()
{
	NPCCount = 4;
}

bool AAVSNPCGroup::MakeSpawnTransform(int32 NPCIndex, FTransform& OutTransform)
{
	const FVector Offset = GetFormationOffset(NPCIndex);
	OutTransform = FTransform(GetActorRotation(), GetActorTransform().TransformPositionNoScale(Offset));
	return true;
}

void AAVSNPCGroup::ConfigureSpawnedNPC(AAVSArchvizNPCCharacter* NPC, int32 NPCIndex)
{
	if (!NPC || !NPC->Behavior)
	{
		return;
	}
	NPC->bEnableLightweightAvoidance = bEnableMemberAvoidance;
	NPC->RefreshAvoidanceSettings(true);
	AActor* Leader = ExternalLeader;
	if (!Leader && !ActiveNPCs.IsEmpty())
	{
		Leader = ActiveNPCs[0];
	}
	if (NPCIndex == 0 && !ExternalLeader)
	{
		NPC->Behavior->StartWandering(GetActorLocation(), LeaderWanderRadius);
		return;
	}
	if (Leader)
	{
		NPC->Behavior->bEnableIdleActivities = !bDisableIdleActivitiesForFollowers;
		NPC->Behavior->FollowActor(Leader, GetFormationOffset(NPCIndex));
	}
}

FVector AAVSNPCGroup::GetFormationOffset(int32 NPCIndex) const
{
	if (NPCIndex <= 0 && !ExternalLeader)
	{
		return FVector::ZeroVector;
	}
	const int32 MemberIndex = ExternalLeader ? NPCIndex : NPCIndex - 1;
	const int32 Row = MemberIndex / 2 + 1;
	const float Side = MemberIndex % 2 == 0 ? -1.0f : 1.0f;
	switch (Formation)
	{
	case EAVSGroupFormation::VFormation:
		return FVector(-MemberSpacing * Row, Side * MemberSpacing * Row * 0.75f, 0.0f);
	case EAVSGroupFormation::Line:
		return FVector(-MemberSpacing * (MemberIndex + 1), 0.0f, 0.0f);
	case EAVSGroupFormation::Circle:
	{
		const int32 MemberCount = FMath::Max(1, ExternalLeader ? NPCCount : NPCCount - 1);
		const float Angle = 2.0f * PI * static_cast<float>(MemberIndex) / static_cast<float>(MemberCount);
		return FVector(FMath::Cos(Angle), FMath::Sin(Angle), 0.0f) * MemberSpacing;
	}
	case EAVSGroupFormation::SideBySide:
	default:
		return FVector(-MemberSpacing * 0.35f * Row, Side * MemberSpacing * Row, 0.0f);
	}
}
