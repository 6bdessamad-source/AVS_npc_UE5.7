#include "AVSCrowdRoute.h"

#include "AVSAnimationProfile.h"
#include "AVSArchvizNPCCharacter.h"
#include "AVSCharacterLibrary.h"
#include "AVSCharacterProfile.h"
#include "AVSCrowdSubsystem.h"
#include "AVSNPCBehaviorComponent.h"
#include "Components/SplineComponent.h"
#include "DrawDebugHelpers.h"
#include "EngineUtils.h"

AAVSCrowdRoute::AAVSCrowdRoute()
{
	RouteSpline = CreateDefaultSubobject<USplineComponent>(TEXT("RouteSpline"));
	RouteSpline->SetupAttachment(SceneRoot);
	RouteSpline->SetClosedLoop(true);
	NPCCount = 6;
}

void AAVSCrowdRoute::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);
	if (RouteSpline)
	{
		RouteSpline->SetClosedLoop(bLoopRoute);
	}
}

void AAVSCrowdRoute::BeginPlay()
{
	Super::BeginPlay();
	RefreshRouteConnections();
	RefreshConnectedCrowdZones();
	if (bStartPlacedNPCsOnBeginPlay)
	{
		StartPlacedNPCs();
	}
}

int32 AAVSCrowdRoute::GetEffectiveNPCCount() const
{
	return RoutePurpose == EAVSRoutePurpose::ZoneConnector ? 0 : Super::GetEffectiveNPCCount();
}

void AAVSCrowdRoute::AssignNPCToRoute(AAVSArchvizNPCCharacter* NPC)
{
	if (!NPC)
	{
		return;
	}
	PlacedNPCs.AddUnique(NPC);
	if (NPC->Behavior)
	{
		NPC->Behavior->FollowRoute(this, bLoopRoute);
	}
}

void AAVSCrowdRoute::RemoveNPCFromRoute(AAVSArchvizNPCCharacter* NPC)
{
	PlacedNPCs.Remove(NPC);
	if (NPC && NPC->Behavior && NPC->Behavior->GetCurrentRoute() == this)
	{
		NPC->Behavior->SetBehaviorState(EAVSNPCState::Idle);
	}
}

void AAVSCrowdRoute::StartPlacedNPCs()
{
	PlacedNPCs.RemoveAll([](const TObjectPtr<AAVSArchvizNPCCharacter>& NPC) { return !IsValid(NPC); });
	for (AAVSArchvizNPCCharacter* NPC : PlacedNPCs)
	{
		if (NPC && NPC->Behavior)
		{
			NPC->Behavior->FollowRoute(this, bLoopRoute);
		}
	}
}

int32 AAVSCrowdRoute::GetRoutePointCount() const
{
	const float Length = RouteSpline ? RouteSpline->GetSplineLength() : 0.0f;
	if (Length <= 0.0f)
	{
		return 0;
	}
	const int32 Segments = FMath::Max(1, FMath::CeilToInt(Length / FMath::Max(50.0f, RoutePointSpacing)));
	return bLoopRoute ? FMath::Max(2, Segments) : Segments + 1;
}

FVector AAVSCrowdRoute::GetRoutePoint(int32 PointIndex) const
{
	const int32 Count = GetRoutePointCount();
	if (!RouteSpline || Count <= 0)
	{
		return GetActorLocation();
	}
	const int32 SafeIndex = bLoopRoute ? (PointIndex % Count + Count) % Count : FMath::Clamp(PointIndex, 0, Count - 1);
	const float Denominator = bLoopRoute ? static_cast<float>(Count) : static_cast<float>(FMath::Max(1, Count - 1));
	const float Distance = RouteSpline->GetSplineLength() * static_cast<float>(SafeIndex) / Denominator;
	return RouteSpline->GetLocationAtDistanceAlongSpline(Distance, ESplineCoordinateSpace::World);
}

FVector AAVSCrowdRoute::GetRouteRightVector(int32 PointIndex) const
{
	const int32 Count = GetRoutePointCount();
	if (!RouteSpline || Count <= 0)
	{
		return GetActorRightVector();
	}
	const int32 SafeIndex = bLoopRoute ? (PointIndex % Count + Count) % Count : FMath::Clamp(PointIndex, 0, Count - 1);
	const float Denominator = bLoopRoute ? static_cast<float>(Count) : static_cast<float>(FMath::Max(1, Count - 1));
	const float Distance = RouteSpline->GetSplineLength() * static_cast<float>(SafeIndex) / Denominator;
	return RouteSpline->GetRightVectorAtDistanceAlongSpline(Distance, ESplineCoordinateSpace::World).GetSafeNormal();
}

bool AAVSCrowdRoute::IsCouplePair(int32 PairIndex) const
{
	if (!bEnableCouples || LaneHalfWidth * 2.0f < MinimumRouteWidthForCouples || CoupleChance <= 0.0f)
	{
		return false;
	}
	FRandomStream PairStream(HashCombine(GetTypeHash(RandomSeed), GetTypeHash(PairIndex)));
	return PairStream.FRand() <= CoupleChance;
}

float AAVSCrowdRoute::GetLaneOffsetForIndex(int32 NPCIndex) const
{
	if (IsCouplePair(NPCIndex / 2))
	{
		const float HalfSpacing = FMath::Min(CoupleSpacing * 0.5f, FMath::Max(0.0f, LaneHalfWidth - 20.0f));
		return NPCIndex % 2 == 0 ? -HalfSpacing : HalfSpacing;
	}
	FRandomStream LaneStream(HashCombine(GetTypeHash(RandomSeed + 7919), GetTypeHash(NPCIndex)));
	return LaneStream.FRandRange(-LaneHalfWidth, LaneHalfWidth);
}

bool AAVSCrowdRoute::MakeSpawnTransform(int32 NPCIndex, FTransform& OutTransform)
{
	const int32 Count = GetRoutePointCount();
	if (!RouteSpline || Count <= 0)
	{
		return false;
	}
	const bool bCoupled = IsCouplePair(NPCIndex / 2);
	const int32 PointIndex = (bCoupled ? NPCIndex / 2 : NPCIndex) % Count;
	const float Denominator = bLoopRoute ? static_cast<float>(Count) : static_cast<float>(FMath::Max(1, Count - 1));
	const float Distance = RouteSpline->GetSplineLength() * static_cast<float>(PointIndex) / Denominator;
	const float LateralOffset = GetLaneOffsetForIndex(NPCIndex);
	FVector Location = RouteSpline->GetLocationAtDistanceAlongSpline(Distance, ESplineCoordinateSpace::World);
	Location += RouteSpline->GetRightVectorAtDistanceAlongSpline(Distance, ESplineCoordinateSpace::World) * LateralOffset;
	const FRotator Rotation = RouteSpline->GetRotationAtDistanceAlongSpline(Distance, ESplineCoordinateSpace::World);
	OutTransform = FTransform(FRotator(0.0f, Rotation.Yaw, 0.0f), Location);
	SpawnLateralOffsets.Add(NPCIndex, LateralOffset);
	return true;
}

void AAVSCrowdRoute::ConfigureSpawnedNPC(AAVSArchvizNPCCharacter* NPC, int32 NPCIndex)
{
	if (NPC && NPC->Behavior)
	{
		NPC->Behavior->FollowRouteWithOptions(this, bLoopRoute, EAVSNPCState::Idle,
			SpawnLateralOffsets.FindRef(NPCIndex), INDEX_NONE);
	}
}

bool AAVSCrowdRoute::SelectCoupleCompatibleProfiles(const AAVSArchvizNPCCharacter* Partner,
	UAVSCharacterProfile*& OutCharacter, UAVSAnimationProfile*& OutAnimation)
{
	if (!Partner || !Partner->DefaultCharacterProfile || CoupleGenderMode == EAVSCoupleGenderMode::Any)
	{
		return false;
	}
	const EAVSCharacterSex PartnerSex = Partner->DefaultCharacterProfile->Sex;
	auto IsDesiredSex = [this, PartnerSex](EAVSCharacterSex CandidateSex)
	{
		const bool bPartnerBinary = PartnerSex == EAVSCharacterSex::Male || PartnerSex == EAVSCharacterSex::Female;
		const bool bCandidateBinary = CandidateSex == EAVSCharacterSex::Male || CandidateSex == EAVSCharacterSex::Female;
		if (!bPartnerBinary || !bCandidateBinary)
		{
			return false;
		}
		return CoupleGenderMode == EAVSCoupleGenderMode::SameSex ? CandidateSex == PartnerSex : CandidateSex != PartnerSex;
	};

	struct FCandidate
	{
		UAVSCharacterProfile* Character = nullptr;
		UAVSAnimationProfile* Animation = nullptr;
		float Weight = 0.0f;
	};
	TArray<FCandidate> Candidates;
	float TotalWeight = 0.0f;
	if (CharacterLibrary)
	{
		for (const FAVSCharacterLibraryEntry& Entry : CharacterLibrary->Characters)
		{
			if (Entry.bEnabled && Entry.CharacterProfile && Entry.AnimationProfile && Entry.Weight > 0.0f &&
				IsDesiredSex(Entry.CharacterProfile->Sex) && Entry.AnimationProfile->IsCompatibleWithCharacter(Entry.CharacterProfile))
			{
				FCandidate Candidate;
				Candidate.Character = Entry.CharacterProfile;
				Candidate.Animation = Entry.AnimationProfile;
				Candidate.Weight = Entry.Weight;
				Candidates.Add(Candidate);
				TotalWeight += Entry.Weight;
			}
		}
	}
	else
	{
		for (UAVSCharacterProfile* Character : CharacterProfiles)
		{
			if (Character && IsDesiredSex(Character->Sex))
			{
				TArray<UAVSAnimationProfile*> Compatible;
				for (UAVSAnimationProfile* Animation : AnimationProfiles)
				{
					if (Animation && Animation->IsCompatibleWithCharacter(Character))
					{
						Compatible.Add(Animation);
					}
				}
				if (!Compatible.IsEmpty())
				{
					FCandidate Candidate;
					Candidate.Character = Character;
					Candidate.Animation = Compatible[RandomStream.RandRange(0, Compatible.Num() - 1)];
					Candidate.Weight = FMath::Max(0.01f, Character->SelectionWeight);
					Candidates.Add(Candidate);
					TotalWeight += Candidate.Weight;
				}
			}
		}
	}
	if (Candidates.IsEmpty() || TotalWeight <= 0.0f)
	{
		return false;
	}
	float Choice = RandomStream.FRandRange(0.0f, TotalWeight);
	for (const FCandidate& Candidate : Candidates)
	{
		Choice -= Candidate.Weight;
		if (Choice <= 0.0f)
		{
			OutCharacter = Candidate.Character;
			OutAnimation = Candidate.Animation;
			return true;
		}
	}
	OutCharacter = Candidates.Last().Character;
	OutAnimation = Candidates.Last().Animation;
	return true;
}

void AAVSCrowdRoute::SelectProfiles(int32 NPCIndex, UAVSCharacterProfile*& OutCharacter, UAVSAnimationProfile*& OutAnimation)
{
	if (NPCIndex % 2 == 1 && IsCouplePair(NPCIndex / 2) && ActiveNPCs.IsValidIndex(NPCIndex - 1) &&
		SelectCoupleCompatibleProfiles(ActiveNPCs[NPCIndex - 1], OutCharacter, OutAnimation))
	{
		return;
	}
	Super::SelectProfiles(NPCIndex, OutCharacter, OutAnimation);
}

void AAVSCrowdRoute::RefreshRouteConnections()
{
	AutoConnections.Reset();
	if (!bAutoDiscoverRouteConnections || !GetWorld())
	{
		return;
	}
	const float RadiusSquared = FMath::Square(ConnectionRadius);
	for (TActorIterator<AAVSCrowdRoute> It(GetWorld()); It; ++It)
	{
		AAVSCrowdRoute* Other = *It;
		if (!Other || Other == this)
		{
			continue;
		}
		for (int32 SourceIndex = 0; SourceIndex < GetRoutePointCount(); ++SourceIndex)
		{
			float BestDistanceSquared = RadiusSquared;
			int32 BestTarget = INDEX_NONE;
			for (int32 TargetIndex = 0; TargetIndex < Other->GetRoutePointCount(); ++TargetIndex)
			{
				const float DistanceSquared = FVector::DistSquared(GetRoutePoint(SourceIndex), Other->GetRoutePoint(TargetIndex));
				if (DistanceSquared <= BestDistanceSquared)
				{
					BestDistanceSquared = DistanceSquared;
					BestTarget = TargetIndex;
				}
			}
			if (BestTarget != INDEX_NONE)
			{
				FAVSRouteConnection& Connection = AutoConnections.AddDefaulted_GetRef();
				Connection.TargetRoute = Other;
				Connection.SourcePointIndex = SourceIndex;
				Connection.TargetPointIndex = BestTarget;
				Connection.Weight = 1.0f;
			}
		}
	}
}

void AAVSCrowdRoute::RefreshConnectedCrowdZones()
{
	AutoConnectedCrowdZones.Reset();
	if (!CanConnectCrowdZones() || !bAutoDiscoverConnectedCrowdZones || !GetWorld() || !RouteSpline)
	{
		return;
	}

	const float RouteLength = RouteSpline->GetSplineLength();
	const int32 SampleCount = FMath::Max(1, FMath::CeilToInt(RouteLength / FMath::Max(50.0f, RoutePointSpacing)));
	for (TActorIterator<AAVSCrowdGenerator> It(GetWorld()); It; ++It)
	{
		AAVSCrowdGenerator* Candidate = *It;
		if (!Candidate || Candidate == this || ConnectedCrowdZones.Contains(Candidate))
		{
			continue;
		}
		for (int32 SampleIndex = 0; SampleIndex <= SampleCount; ++SampleIndex)
		{
			const float Distance = RouteLength * static_cast<float>(SampleIndex) / static_cast<float>(SampleCount);
			const FVector Sample = RouteSpline->GetLocationAtDistanceAlongSpline(Distance, ESplineCoordinateSpace::World);
			if (Candidate->ContainsWorldLocation(Sample))
			{
				AutoConnectedCrowdZones.AddUnique(Candidate);
				break;
			}
		}
	}
}

AAVSCrowdGenerator* AAVSCrowdRoute::FindDestinationCrowdZone(const AAVSArchvizNPCCharacter* NPC) const
{
	if (!CanConnectCrowdZones() || bLoopRoute || GetRoutePointCount() == 0)
	{
		return nullptr;
	}
	const FVector EndLocation = GetRoutePoint(GetRoutePointCount() - 1);
	const AActor* OriginGenerator = NPC ? NPC->GetOwningGenerator() : nullptr;
	TArray<AAVSCrowdGenerator*> Candidates;
	for (AAVSCrowdGenerator* Zone : ConnectedCrowdZones)
	{
		if (IsValid(Zone) && Zone != this)
		{
			Candidates.AddUnique(Zone);
		}
	}
	for (AAVSCrowdGenerator* Zone : AutoConnectedCrowdZones)
	{
		if (IsValid(Zone) && Zone != this)
		{
			Candidates.AddUnique(Zone);
		}
	}

	for (AAVSCrowdGenerator* Zone : Candidates)
	{
		if (Zone != OriginGenerator && Zone->ContainsWorldLocation(EndLocation))
		{
			return Zone;
		}
	}
	for (AAVSCrowdGenerator* Zone : Candidates)
	{
		if (Zone->ContainsWorldLocation(EndLocation))
		{
			return Zone;
		}
	}

	AAVSCrowdGenerator* Closest = nullptr;
	float ClosestDistanceSquared = TNumericLimits<float>::Max();
	for (AAVSCrowdGenerator* Zone : Candidates)
	{
		if (Zone == OriginGenerator)
		{
			continue;
		}
		const float DistanceSquared = FVector::DistSquared2D(EndLocation, Zone->GetActorLocation());
		if (DistanceSquared < ClosestDistanceSquared)
		{
			ClosestDistanceSquared = DistanceSquared;
			Closest = Zone;
		}
	}
	return Closest;
}

bool AAVSCrowdRoute::IsLocationNearRoute(const FVector& WorldLocation, float ExtraClearance) const
{
	if (!RouteSpline)
	{
		return false;
	}
	const FVector Closest = RouteSpline->FindLocationClosestToWorldLocation(WorldLocation, ESplineCoordinateSpace::World);
	return FVector::DistSquared2D(Closest, WorldLocation) <=
		FMath::Square(FMath::Max(0.0f, LaneHalfWidth + ExtraClearance));
}

bool AAVSCrowdRoute::TrySelectTransfer(AAVSArchvizNPCCharacter* NPC, int32 SourcePointIndex, FRandomStream& Stream,
	AAVSCrowdRoute*& OutRoute, int32& OutTargetPointIndex) const
{
	OutRoute = nullptr;
	OutTargetPointIndex = INDEX_NONE;
	if (!NPC || RouteTransferChance <= 0.0f || Stream.FRand() > RouteTransferChance)
	{
		return false;
	}
	TArray<const FAVSRouteConnection*> Candidates;
	float TotalWeight = 0.0f;
	auto AddCompatible = [&](const TArray<FAVSRouteConnection>& Connections)
	{
		for (const FAVSRouteConnection& Connection : Connections)
		{
			if (Connection.SourcePointIndex == SourcePointIndex && Connection.TargetRoute && Connection.TargetRoute != this &&
				Connection.Weight > 0.0f && Connection.TargetRoute->SupportsProfiles(NPC->DefaultCharacterProfile, NPC->DefaultAnimationProfile))
			{
				Candidates.Add(&Connection);
				TotalWeight += Connection.Weight;
			}
		}
	};
	AddCompatible(ManualConnections);
	AddCompatible(AutoConnections);
	if (Candidates.IsEmpty() || TotalWeight <= 0.0f)
	{
		return false;
	}
	float Choice = Stream.FRandRange(0.0f, TotalWeight);
	const FAVSRouteConnection* Selected = Candidates.Last();
	for (const FAVSRouteConnection* Candidate : Candidates)
	{
		Choice -= Candidate->Weight;
		if (Choice <= 0.0f)
		{
			Selected = Candidate;
			break;
		}
	}
	OutRoute = Selected->TargetRoute;
	OutTargetPointIndex = FMath::Clamp(Selected->TargetPointIndex, 0, FMath::Max(0, OutRoute->GetRoutePointCount() - 1));
	return OutRoute != nullptr;
}

bool AAVSCrowdRoute::HandleNPCReachedEnd(AAVSArchvizNPCCharacter* NPC)
{
	OnNPCReachedEnd.Broadcast(NPC, this);
	if (!bLoopRoute && bDespawnAtEnd && NPC && GetWorld())
	{
		if (UAVSCrowdSubsystem* Subsystem = GetWorld()->GetSubsystem<UAVSCrowdSubsystem>())
		{
			Subsystem->ReleaseNPC(NPC);
			return true;
		}
	}
	if (AAVSCrowdGenerator* DestinationZone = FindDestinationCrowdZone(NPC))
	{
		DestinationZone->AcceptConnectorArrival(NPC);
		return true;
	}
	return false;
}

void AAVSCrowdRoute::DrawGeneratorDebug(const FAVSViewerState& ViewerState) const
{
	Super::DrawGeneratorDebug(ViewerState);
	const int32 Count = GetRoutePointCount();
	const int32 SegmentCount = bLoopRoute ? Count : FMath::Max(0, Count - 1);
	for (int32 Index = 0; Index < SegmentCount; ++Index)
	{
		const FVector A = GetRoutePoint(Index);
		const FVector B = GetRoutePoint((Index + 1) % Count);
		DrawDebugLine(GetWorld(), A, B, FColor::Orange, false, 0.6f, 0, 4.0f);
		DrawDebugLine(GetWorld(), A - GetRouteRightVector(Index) * LaneHalfWidth,
			A + GetRouteRightVector(Index) * LaneHalfWidth, FColor::Silver, false, 0.6f, 0, 1.0f);
	}
	for (const FAVSRouteConnection& Connection : AutoConnections)
	{
		if (Connection.TargetRoute)
		{
			DrawDebugLine(GetWorld(), GetRoutePoint(Connection.SourcePointIndex),
				Connection.TargetRoute->GetRoutePoint(Connection.TargetPointIndex), FColor::Cyan, false, 0.6f, 0, 3.0f);
		}
	}
}
