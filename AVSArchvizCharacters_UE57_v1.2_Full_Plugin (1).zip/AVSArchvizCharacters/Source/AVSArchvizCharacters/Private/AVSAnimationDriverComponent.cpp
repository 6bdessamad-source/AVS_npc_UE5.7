#include "AVSAnimationDriverComponent.h"

#include "AVSAnimationProfile.h"
#include "AVSArchvizCharacters.h"
#include "Animation/AnimInstance.h"
#include "Animation/AnimBlueprintGeneratedClass.h"
#include "AnimNodes/AnimNode_Slot.h"
#include "UObject/UnrealType.h"
#include "Animation/AnimMontage.h"
#include "Animation/AnimSequenceBase.h"
#include "Animation/AnimSingleNodeInstance.h"
#include "AIController.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/SkeletalMesh.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/NavMovementComponent.h"

UAVSAnimationDriverComponent::UAVSAnimationDriverComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.TickInterval = 0.05f;
}

void UAVSAnimationDriverComponent::BeginPlay()
{
	Super::BeginPlay();
	if (USkeletalMeshComponent* Mesh = GetTargetMesh(); Mesh && Mesh->GetAnimationMode() == EAnimationMode::AnimationBlueprint)
		if (UAnimInstance* Instance = Mesh->GetAnimInstance(); Instance && !Instance->IsA<UAnimSingleNodeInstance>())
			SavedAnimationBlueprintClass = Instance->GetClass();
	RandomStream.Initialize(GetTypeHash(GetOwner()->GetFName()) ^ GetOwner()->GetUniqueID());
	ApplyMovementMatchSettings();
	ScheduleIdleVariant();
	UpdateLocomotion(0.0f);
}

void UAVSAnimationDriverComponent::ApplyAnimationProfile(UAVSAnimationProfile* NewProfile)
{
	// Profile application follows modular appearance: capture its configured class, including explicit None.
	if (USkeletalMeshComponent* Mesh = GetTargetMesh()) SavedAnimationBlueprintClass = Mesh->GetAnimClass();
	if (USkeletalMeshComponent* Mesh = GetTargetMesh())
	{
		if (UAnimInstance* Instance = Mesh->GetAnimInstance())
		{
			if (ActiveDynamicMontage)
			{
				Instance->Montage_Stop(NewProfile ? NewProfile->BlendOutTime : 0.0f, ActiveDynamicMontage);
			}
		}
		if (!NewProfile)
		{
			Mesh->Stop();
		}
	}

	ResetForPool();
	AnimationProfile = NewProfile;
	CurrentAnimation = nullptr;
	ActiveDynamicMontage = nullptr;
	LastVariantIndices.Reset();
	WarnedMissingLocomotionSlots.Reset();
	bActivityOverride = false;
	bHasStartedLocomotion = false;
	bPlayingTransition = false;
	bHasCurrentEntry = false;
	bPlayingComposedStart = false;
	bPlayingComposedEnd = false;
	bResumeLocomotionAfterEnd = false;
	bHasPendingLocomotionAfterEnd = false;
	TransitionTimeRemaining = 0.0f;
	ComposedTimeRemaining = 0.0f;
	MovementPreparationGraceRemaining = 0.0f;
	CurrentBasePlayRate = 1.0f;
	CurrentAppliedPlayRate = 1.0f;
	ApplyMovementMatchSettings();
	ScheduleIdleVariant();
	if (NewProfile)
	{
		UpdateLocomotion(0.0f);
	}
}

void UAVSAnimationDriverComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	if (ActivityPlayback.IsActive())
	{
		UpdateActivityPlayback(DeltaTime);
		return;
	}
	if (UpdateComposedPlayback(DeltaTime))
	{
		return;
	}
	if (!bActivityOverride)
	{
		UpdateLocomotion(DeltaTime);
		UpdateDynamicLocomotionPlayRate(DeltaTime);
	}
}

void UAVSAnimationDriverComponent::ApplyMovementMatchSettings()
{
	ACharacter* OwnerCharacter = Cast<ACharacter>(GetOwner());
	UCharacterMovementComponent* Movement = OwnerCharacter ? OwnerCharacter->GetCharacterMovement() : nullptr;
	if (!Movement || !AnimationProfile)
	{
		return;
	}

	Movement->MaxWalkSpeed = FMath::Max(1.0f, AnimationProfile->DesiredWalkSpeed);
	Movement->MaxAcceleration = FMath::Max(1.0f, AnimationProfile->MovementAcceleration);
	Movement->BrakingDecelerationWalking = FMath::Max(1.0f, AnimationProfile->MovementDeceleration);
	if (FNavMovementProperties* NavProperties = Movement->GetNavMovementProperties())
	{
		NavProperties->bUseAccelerationForPaths = AnimationProfile->bUseAccelerationForPaths;
	}
}

float UAVSAnimationDriverComponent::GetCurrentLocomotionReferenceSpeed() const
{
	if (!AnimationProfile)
	{
		return 1.0f;
	}
	if (CurrentEntry.AuthoredGroundSpeed > 0.0f)
	{
		return CurrentEntry.AuthoredGroundSpeed;
	}
	return CurrentSlot == EAVSAnimationSlot::Run
		? FMath::Max(1.0f, AnimationProfile->RunAnimationReferenceSpeed)
		: FMath::Max(1.0f, AnimationProfile->WalkAnimationReferenceSpeed);
}

void UAVSAnimationDriverComponent::UpdateDynamicLocomotionPlayRate(float DeltaTime)
{
	if (!AnimationProfile || !AnimationProfile->bMatchLocomotionPlayRateToSpeed || bActivityOverride ||
		bPlayingComposedStart || bPlayingComposedEnd || bPlayingTransition ||
		(CurrentSlot != EAVSAnimationSlot::Walk && CurrentSlot != EAVSAnimationSlot::Run))
	{
		return;
	}

	const ACharacter* OwnerCharacter = Cast<ACharacter>(GetOwner());
	USkeletalMeshComponent* Mesh = GetTargetMesh();
	if (!OwnerCharacter || !Mesh)
	{
		return;
	}

	const float Speed = OwnerCharacter->GetVelocity().Size2D();
	const float MinRate = FMath::Max(0.05f, AnimationProfile->MinDynamicLocomotionPlayRate);
	const float MaxRate = FMath::Max(MinRate, AnimationProfile->MaxDynamicLocomotionPlayRate);
	const float TargetRate = Speed <= 1.0f
		? 0.0f
		: FMath::Clamp(CurrentBasePlayRate * Speed / GetCurrentLocomotionReferenceSpeed(), MinRate, MaxRate);
	CurrentAppliedPlayRate = FMath::FInterpTo(CurrentAppliedPlayRate, TargetRate, DeltaTime,
		FMath::Max(0.0f, AnimationProfile->LocomotionPlayRateInterpolationSpeed));

	if (UAnimInstance* Instance = Mesh->GetAnimInstance(); Instance && ActiveDynamicMontage)
	{
		Instance->Montage_SetPlayRate(ActiveDynamicMontage, CurrentAppliedPlayRate);
	}
	else
	{
		Mesh->SetPlayRate(CurrentAppliedPlayRate);
	}
}

EAVSAnimationSlot UAVSAnimationDriverComponent::DetermineLocomotionSlot(float Speed) const
{
	if (!AnimationProfile || !bHasStartedLocomotion)
	{
		if (AnimationProfile && Speed >= AnimationProfile->RunSpeedThreshold)
		{
			return EAVSAnimationSlot::Run;
		}
		if (AnimationProfile && Speed >= AnimationProfile->WalkSpeedThreshold)
		{
			return EAVSAnimationSlot::Walk;
		}
		return EAVSAnimationSlot::Idle;
	}

	const float Hysteresis = FMath::Max(0.0f, AnimationProfile->SpeedHysteresis);
	switch (CurrentLocomotionSlot)
	{
	case EAVSAnimationSlot::Idle:
		return Speed >= AnimationProfile->WalkSpeedThreshold + Hysteresis ? EAVSAnimationSlot::Walk : EAVSAnimationSlot::Idle;
	case EAVSAnimationSlot::Walk:
		if (Speed <= FMath::Max(0.0f, AnimationProfile->WalkSpeedThreshold - Hysteresis))
		{
			return EAVSAnimationSlot::Idle;
		}
		return Speed >= AnimationProfile->RunSpeedThreshold + Hysteresis ? EAVSAnimationSlot::Run : EAVSAnimationSlot::Walk;
	case EAVSAnimationSlot::Run:
		if (Speed <= FMath::Max(0.0f, AnimationProfile->RunSpeedThreshold - Hysteresis))
		{
			return Speed >= AnimationProfile->WalkSpeedThreshold ? EAVSAnimationSlot::Walk : EAVSAnimationSlot::Idle;
		}
		return EAVSAnimationSlot::Run;
	default:
		return Speed >= AnimationProfile->WalkSpeedThreshold ? EAVSAnimationSlot::Walk : EAVSAnimationSlot::Idle;
	}
}

EAVSAnimationSlot UAVSAnimationDriverComponent::GetTransitionSlot(EAVSAnimationSlot From, EAVSAnimationSlot To) const
{
	if (From == EAVSAnimationSlot::Idle && To == EAVSAnimationSlot::Walk)
	{
		return EAVSAnimationSlot::WalkStart;
	}
	if ((From == EAVSAnimationSlot::Walk || From == EAVSAnimationSlot::Run) && To == EAVSAnimationSlot::Idle)
	{
		return From == EAVSAnimationSlot::Run ? EAVSAnimationSlot::RunStop : EAVSAnimationSlot::WalkStop;
	}
	if (From == EAVSAnimationSlot::Walk && To == EAVSAnimationSlot::Run)
	{
		return EAVSAnimationSlot::RunStart;
	}
	if (From == EAVSAnimationSlot::Run && To == EAVSAnimationSlot::Walk)
	{
		return EAVSAnimationSlot::RunStop;
	}
	return EAVSAnimationSlot::Custom;
}

void UAVSAnimationDriverComponent::UpdateLocomotion(float DeltaTime)
{
	const ACharacter* OwnerCharacter = Cast<ACharacter>(GetOwner());
	if (!OwnerCharacter || !AnimationProfile || !bDriveSingleNodeLocomotion)
	{
		return;
	}

	if (bPlayingTransition)
	{
		TransitionTimeRemaining -= DeltaTime;
		if (TransitionTimeRemaining > 0.0f)
		{
			return;
		}
		bPlayingTransition = false;
		CurrentLocomotionSlot = PendingLocomotionSlot;
		bHasStartedLocomotion = StartSelectedVariant(CurrentLocomotionSlot, NAME_None, true, true);
		if (!bHasStartedLocomotion && (CurrentLocomotionSlot == EAVSAnimationSlot::Walk || CurrentLocomotionSlot == EAVSAnimationSlot::Run))
		{
			StopMovementForMissingLocomotion(CurrentLocomotionSlot);
		}
		if (CurrentLocomotionSlot == EAVSAnimationSlot::Idle)
		{
			ScheduleIdleVariant();
		}
		return;
	}

	MovementPreparationGraceRemaining = FMath::Max(0.0f, MovementPreparationGraceRemaining - DeltaTime);
	const bool bHoldPreparedMovement = MovementPreparationGraceRemaining > 0.0f &&
		(CurrentLocomotionSlot == EAVSAnimationSlot::Walk || CurrentLocomotionSlot == EAVSAnimationSlot::Run);
	const EAVSAnimationSlot Desired = bHoldPreparedMovement
		? CurrentLocomotionSlot
		: DetermineLocomotionSlot(OwnerCharacter->GetVelocity().Size2D());
	if (!bHasStartedLocomotion || Desired != CurrentLocomotionSlot)
	{
		if (bHasStartedLocomotion && CurrentLocomotionSlot != EAVSAnimationSlot::Idle &&
			Desired != CurrentLocomotionSlot && StartCurrentEntryEnd(Desired, true))
		{
			return;
		}
		if (bHasStartedLocomotion && AnimationProfile->bUseTransitionClips && !CanUseMontageBlending())
		{
			const EAVSAnimationSlot TransitionSlot = GetTransitionSlot(CurrentLocomotionSlot, Desired);
			FAVSNamedAnimation TransitionEntry;
			int32 TransitionIndex = INDEX_NONE;
			const FString Key = MakeVariantKey(TransitionSlot, NAME_None);
			const int32 AvoidIndex = LastVariantIndices.Contains(Key) ? LastVariantIndices.FindRef(Key) : INDEX_NONE;
			if (TransitionSlot != EAVSAnimationSlot::Custom &&
				AnimationProfile->SelectAnimationVariant(TransitionSlot, NAME_None, RandomStream, AvoidIndex, TransitionEntry, TransitionIndex))
			{
				if (UAnimSequenceBase* Animation = TransitionEntry.Animation.LoadSynchronous())
				{
					if (StartAsset(Animation, false, TransitionEntry.PlayRate, TransitionSlot, false))
					{
						LastVariantIndices.Add(Key, TransitionIndex);
						PendingLocomotionSlot = Desired;
						TransitionTimeRemaining = Animation->GetPlayLength() / CurrentBasePlayRate;
						bPlayingTransition = true;
						return;
					}
				}
			}
		}

		CurrentLocomotionSlot = Desired;
		bHasStartedLocomotion = StartSelectedVariant(Desired, NAME_None, true, true);
		if (!bHasStartedLocomotion && (Desired == EAVSAnimationSlot::Walk || Desired == EAVSAnimationSlot::Run))
		{
			StopMovementForMissingLocomotion(Desired);
		}
		if (Desired == EAVSAnimationSlot::Idle)
		{
			ScheduleIdleVariant();
		}
		return;
	}

	if (Desired == EAVSAnimationSlot::Idle && AnimationProfile->GetVariantCount(EAVSAnimationSlot::Idle) > 1)
	{
		IdleVariantTimeRemaining -= DeltaTime;
		if (IdleVariantTimeRemaining <= 0.0f)
		{
			if (!StartCurrentEntryEnd(EAVSAnimationSlot::Idle, true))
			{
				StartSelectedVariant(EAVSAnimationSlot::Idle, NAME_None, true, true);
				ScheduleIdleVariant();
			}
		}
	}
}

bool UAVSAnimationDriverComponent::PlayAnimationSlot(EAVSAnimationSlot Slot, FName CustomName,
	bool bLoopOverride, bool bOverrideProfileLoopSetting, bool bAllowSmartTransitionFallback)
{
	if (!AnimationProfile) return false;
	// Idempotent state requests: high-frequency behavior commands never restart a clip/montage.
	if (ActivityPlayback.IsActive()) return CurrentSlot == Slot && ActiveActivityCustomName == CustomName;
	FAVSNamedAnimation Entry;
	int32 Index = INDEX_NONE;
	const FString Key = MakeVariantKey(Slot, CustomName);
	const USkeletalMeshComponent* Mesh = GetTargetMesh();
	const USkeleton* Skeleton = Mesh && Mesh->GetSkeletalMeshAsset() ? Mesh->GetSkeletalMeshAsset()->GetSkeleton() : nullptr;
	if (!AnimationProfile->SelectCompatibleAnimationVariant(Slot, CustomName, Skeleton, RandomStream,
		LastVariantIndices.Contains(Key) ? LastVariantIndices.FindRef(Key) : INDEX_NONE, Entry, Index)) return false;
	Entry.bLoop = bOverrideProfileLoopSetting ? bLoopOverride : bLoopOverride || Entry.bLoop;
	if (!PlayAnimationEntry(Entry, Slot, -1.0f, bAllowSmartTransitionFallback, true)) return false;
	LastVariantIndices.Add(Key, Index);
	return true;
}

bool UAVSAnimationDriverComponent::PlayAnimationEntry(const FAVSNamedAnimation& Entry, EAVSAnimationSlot Slot,
	float Duration, bool bAllowReverse, bool bAllowHold, float HoldPosition)
{
	if (ActivityPlayback.IsActive())
		return CurrentSlot == Slot && ActiveActivityCustomName == Entry.CustomName &&
			CurrentEntry.Animation == Entry.Animation && CurrentEntry.StartAnimation == Entry.StartAnimation && CurrentEntry.EndAnimation == Entry.EndAnimation;
	USkeletalMeshComponent* Mesh = GetTargetMesh();
	const USkeleton* Skeleton = Mesh && Mesh->GetSkeletalMeshAsset() ? Mesh->GetSkeletalMeshAsset()->GetSkeleton() : nullptr;
	FAVSResolveSettings Settings;
	Settings.Duration = Duration; Settings.bAllowReverse = bAllowReverse; Settings.bAllowHold = bAllowHold; Settings.HoldPosition = HoldPosition;
	const FAVSResolvedAnimation Resolved = AVSResolveAnimation(AnimationProfile, Entry, Skeleton, Settings);
	if (!Resolved.Plan.Valid) return false;
	// Activities never share path-following ownership. Behavior must also cancel/release its path target.
	if (ACharacter* OwnerCharacter = Cast<ACharacter>(GetOwner()))
	{
		if (AAIController* AI = Cast<AAIController>(OwnerCharacter->GetController())) AI->StopMovement();
		OwnerCharacter->GetCharacterMovement()->StopMovementImmediately();
	}
	if (UAnimInstance* Instance = Mesh->GetAnimInstance(); Instance && ActiveDynamicMontage)
		Instance->Montage_Stop(0.0f, ActiveDynamicMontage);
	ActiveDynamicMontage = nullptr;
	ResolvedActivity = Resolved;
	ActivityClips = { Resolved.Start, Resolved.Main, Resolved.End };
	CurrentEntry = Entry; CurrentSlot = Slot; ActiveActivityCustomName = Entry.CustomName;
	bActivityOverride = true; bPlayingTransition = false; bPlayingComposedStart = false; bPlayingComposedEnd = false;
	bHasCurrentEntry = false;
	if (!ActivityPlayback.Begin(Resolved.Plan)) return false;
	ApplyActivityPose();
	return true;
}

void UAVSAnimationDriverComponent::ApplyActivityPose()
{
	USkeletalMeshComponent* Mesh = GetTargetMesh();
	if (!Mesh || !ActivityPlayback.IsActive()) return;
	UAnimSequenceBase* Clip = ResolvedActivity.GetClip(ActivityPlayback.GetSegment().Source);
	if (!Clip) { CancelActivityPlayback(true); return; }
	// Sampling provides exact partial traversals and holds without global bPauseAnims or unsafe reverse montage notifies.
	if (CurrentAnimation != Clip || Mesh->GetAnimationMode() != EAnimationMode::AnimationSingleNode)
	{
		Mesh->SetAnimationMode(EAnimationMode::AnimationSingleNode);
		Mesh->PlayAnimation(Clip, false);
		CurrentAnimation = Clip;
	}
	if (UAnimSingleNodeInstance* Instance = Mesh->GetSingleNodeInstance()) Instance->SetPlaying(false);
	const bool bNotifies = ActivityPlayback.GetSegment().Rate >= 0 || CurrentEntry.bAllowReverseNotifies;
	Mesh->SetPosition(static_cast<float>(ActivityPlayback.GetPosition()) * Clip->GetPlayLength(), bNotifies);
}

void UAVSAnimationDriverComponent::UpdateActivityPlayback(float DeltaTime)
{
	ActivityPlayback.Advance(DeltaTime);
	if (ActivityPlayback.IsActive()) ApplyActivityPose();
	else
	{
		bActivityOverride = false; ActivityClips.Reset(); CurrentAnimation = nullptr;
		ResumeLocomotionImmediate(EAVSAnimationSlot::Idle);
	}
}

void UAVSAnimationDriverComponent::CancelActivityPlayback(bool bImmediate)
{
	if (bImmediate)
	{
		ActivityPlayback.Reset(); ActivityClips.Reset(); bActivityOverride = false;
		return;
	}
	if (ActivityPlayback.IsActive())
	{
		ActivityPlayback.RequestExit();
		UpdateActivityPlayback(0.0f);
	}
}

void UAVSAnimationDriverComponent::ResetForPool()
{
	ActivityPlayback.Reset(); ResolvedActivity = FAVSResolvedAnimation(); ActivityClips.Reset();
	if (USkeletalMeshComponent* Mesh = GetTargetMesh())
	{
		if (UAnimInstance* Instance = Mesh->GetAnimInstance()) Instance->StopAllMontages(0.0f);
		Mesh->Stop(); Mesh->bPauseAnims = false;
		Mesh->SetPlayRate(1.0f);
		if (UAnimSingleNodeInstance* Instance = Mesh->GetSingleNodeInstance()) Instance->SetPlaying(false);
	}
	CurrentAnimation = nullptr; ActiveDynamicMontage = nullptr; LastVariantIndices.Reset(); WarnedMissingLocomotionSlots.Reset();
	bActivityOverride = false; bHasStartedLocomotion = false; bPlayingTransition = false; bHasCurrentEntry = false;
	bPlayingComposedStart = false; bPlayingComposedEnd = false; bResumeLocomotionAfterEnd = false; bHasPendingLocomotionAfterEnd = false;
	CurrentEntry = FAVSNamedAnimation(); PendingMainEntry = FAVSNamedAnimation(); ActiveActivityCustomName = NAME_None;
	CurrentSlot = EAVSAnimationSlot::Idle; CurrentLocomotionSlot = EAVSAnimationSlot::Idle;
	TransitionTimeRemaining = ComposedTimeRemaining = MovementPreparationGraceRemaining = 0.0f;
	CurrentBasePlayRate = CurrentAppliedPlayRate = 1.0f;
}

bool UAVSAnimationDriverComponent::StartSelectedVariant(EAVSAnimationSlot Slot, FName CustomName, bool bLoop, bool bAllowMontageBlend)
{
	if (!AnimationProfile)
	{
		return false;
	}
	FAVSNamedAnimation Entry;
	int32 SelectedIndex = INDEX_NONE;
	const FString Key = MakeVariantKey(Slot, CustomName);
	const int32 AvoidIndex = LastVariantIndices.Contains(Key) ? LastVariantIndices[Key] : INDEX_NONE;
	const USkeletalMeshComponent* Mesh = GetTargetMesh();
	const USkeleton* Skeleton = Mesh && Mesh->GetSkeletalMeshAsset() ? Mesh->GetSkeletalMeshAsset()->GetSkeleton() : nullptr;
	if (!AnimationProfile->SelectCompatibleAnimationVariant(Slot, CustomName, Skeleton, RandomStream, AvoidIndex, Entry, SelectedIndex))
	{
		return false;
	}
	if (!Entry.Animation.IsNull())
	{
		if (StartAnimationEntry(Entry, Slot, bLoop, bAllowMontageBlend))
		{
			LastVariantIndices.Add(Key, SelectedIndex);
			return true;
		}
	}
	return false;
}

bool UAVSAnimationDriverComponent::StartAnimationEntry(const FAVSNamedAnimation& Entry, EAVSAnimationSlot Slot,
	bool bLoop, bool bAllowMontageBlend)
{
	UAnimSequenceBase* MainAnimation = Entry.Animation.LoadSynchronous();
	if (!MainAnimation)
	{
		return false;
	}

	UAnimSequenceBase* StartAnimation = Entry.StartAnimation.LoadSynchronous();
	bool bReverseStart = false;
	if (!StartAnimation && ShouldUseReverseTransitionFallback(Entry))
	{
		StartAnimation = Entry.EndAnimation.LoadSynchronous();
		bReverseStart = StartAnimation != nullptr;
	}

	if (StartAnimation)
	{
		if (StartAsset(StartAnimation, false, Entry.PlayRate, Slot, bAllowMontageBlend, bReverseStart))
		{
			PendingMainEntry = Entry;
			PendingMainSlot = Slot;
			bPendingMainLoop = bLoop;
			bPendingMainAllowMontageBlend = bAllowMontageBlend;
			bPlayingComposedStart = true;
			bPlayingComposedEnd = false;
			ComposedTimeRemaining = StartAnimation->GetPlayLength() / CurrentBasePlayRate;
			CurrentEntry = Entry;
			bHasCurrentEntry = true;
			return true;
		}
	}

	if (!StartAsset(MainAnimation, bLoop, Entry.PlayRate, Slot, bAllowMontageBlend))
	{
		return false;
	}
	CurrentEntry = Entry;
	bHasCurrentEntry = true;
	UpdateDynamicLocomotionPlayRate(1.0f);
	return true;
}

bool UAVSAnimationDriverComponent::StartCurrentEntryEnd(EAVSAnimationSlot NextLocomotionSlot, bool bResumeLocomotion)
{
	if (!bHasCurrentEntry || bPlayingComposedStart || bPlayingComposedEnd)
	{
		return false;
	}
	UAnimSequenceBase* EndAnimation = CurrentEntry.EndAnimation.LoadSynchronous();
	bool bReverseEnd = false;
	if (!EndAnimation && ShouldUseReverseTransitionFallback(CurrentEntry))
	{
		EndAnimation = CurrentEntry.StartAnimation.LoadSynchronous();
		bReverseEnd = EndAnimation != nullptr;
	}
	if (!EndAnimation)
	{
		return false;
	}
	if (!StartAsset(EndAnimation, false, CurrentEntry.PlayRate, CurrentSlot, true, bReverseEnd))
	{
		return false;
	}
	bPlayingComposedEnd = true;
	bResumeLocomotionAfterEnd = bResumeLocomotion;
	bHasPendingLocomotionAfterEnd = bResumeLocomotion;
	LocomotionAfterEnd = NextLocomotionSlot;
	ComposedTimeRemaining = EndAnimation->GetPlayLength() / CurrentBasePlayRate;
	return true;
}

bool UAVSAnimationDriverComponent::ShouldUseReverseTransitionFallback(const FAVSNamedAnimation& Entry) const
{
	return AnimationProfile && AnimationProfile->bEnableSmartMissingTransitionFallback && AnimationProfile->bEnableReverseTransitionFallback &&
		Entry.bAllowReverseTransitionFallback;
}

bool UAVSAnimationDriverComponent::UpdateComposedPlayback(float DeltaTime)
{
	if (!bPlayingComposedStart && !bPlayingComposedEnd)
	{
		return false;
	}
	ComposedTimeRemaining -= DeltaTime;
	if (ComposedTimeRemaining > 0.0f)
	{
		return true;
	}

	if (bPlayingComposedStart)
	{
		bPlayingComposedStart = false;
		if (UAnimSequenceBase* MainAnimation = PendingMainEntry.Animation.LoadSynchronous())
		{
			const bool bStartedMain = StartAsset(MainAnimation, bPendingMainLoop, PendingMainEntry.PlayRate,
				PendingMainSlot, bPendingMainAllowMontageBlend);
			if (!bStartedMain)
			{
				if (PendingMainSlot == EAVSAnimationSlot::Walk || PendingMainSlot == EAVSAnimationSlot::Run)
				{
					StopMovementForMissingLocomotion(PendingMainSlot);
				}
			}
			else
			{
				CurrentEntry = PendingMainEntry;
				UpdateDynamicLocomotionPlayRate(1.0f);
			}
		}
		return true;
	}

	bPlayingComposedEnd = false;
	bHasCurrentEntry = false;
	if (bResumeLocomotionAfterEnd && bHasPendingLocomotionAfterEnd)
	{
		const EAVSAnimationSlot Desired = LocomotionAfterEnd;
		bResumeLocomotionAfterEnd = false;
		bHasPendingLocomotionAfterEnd = false;
		ResumeLocomotionImmediate(Desired);
	}
	return true;
}

bool UAVSAnimationDriverComponent::CanUseMontageBlending() const
{
	const USkeletalMeshComponent* Mesh = GetTargetMesh();
	if (!AnimationProfile || !AnimationProfile->bUseSmoothMontageTransitions || AnimationProfile->MontageSlotName.IsNone() ||
		!Mesh || Mesh->GetAnimationMode() != EAnimationMode::AnimationBlueprint || !Mesh->GetAnimInstance() ||
		Mesh->GetAnimInstance()->IsA<UAnimSingleNodeInstance>()) return false;
	const UAnimBlueprintGeneratedClass* AnimClass = Cast<UAnimBlueprintGeneratedClass>(Mesh->GetAnimInstance()->GetClass());
	if (!AnimClass) return false;
	const UObject* Defaults = AnimClass->GetDefaultObject();
	for (const FStructProperty* Property : AnimClass->GetAnimNodeProperties())
		if (Property && Property->Struct == FAnimNode_Slot::StaticStruct())
			if (const FAnimNode_Slot* Slot = Property->ContainerPtrToValuePtr<FAnimNode_Slot>(Defaults))
				if (Slot->SlotName == AnimationProfile->MontageSlotName) return true;
	return false;
}

bool UAVSAnimationDriverComponent::StartAsset(UAnimSequenceBase* Animation, bool bLoop, float PlayRate,
	EAVSAnimationSlot Slot, bool bAllowMontageBlend, bool bReverse)
{
	USkeletalMeshComponent* Mesh = GetTargetMesh();
	if (!Mesh || !Animation)
	{
		return false;
	}
	if (Mesh->GetSkeletalMeshAsset() && Animation->GetSkeleton() != Mesh->GetSkeletalMeshAsset()->GetSkeleton())
	{
		UE_LOG(LogAVSArchvizCharacters, Warning, TEXT("AVS rejected animation '%s' on '%s': Skeletons do not match. Retarget it first."),
			*GetNameSafe(Animation), *GetNameSafe(Mesh));
		return false;
	}
	if (bReverse && Animation->HasRootMotion() && !CurrentEntry.bAllowReverseRootMotion) return false;
	CurrentBasePlayRate = static_cast<float>(AVS::Composed::Safe(PlayRate, 1.0, 0.01, 8.0));
	CurrentAppliedPlayRate = CurrentBasePlayRate;

	if (bAllowMontageBlend && CanUseMontageBlending())
	{
		if (UAnimInstance* Instance = Mesh->GetAnimInstance())
		{
			if (ActiveDynamicMontage)
			{
				Instance->Montage_Stop(AnimationProfile->BlendOutTime, ActiveDynamicMontage);
			}
			const float StartPosition = bReverse
				? FMath::Max(0.0f, Animation->GetPlayLength() - KINDA_SMALL_NUMBER)
				: 0.0f;
			ActiveDynamicMontage = Instance->PlaySlotAnimationAsDynamicMontage(
				Animation,
				AnimationProfile->MontageSlotName,
				AnimationProfile->BlendInTime,
				AnimationProfile->BlendOutTime,
				CurrentBasePlayRate,
				bLoop ? 9999 : 1,
				-1.0f,
				StartPosition);
			if (ActiveDynamicMontage)
			{
				if (bReverse)
				{
					Instance->Montage_SetPlayRate(ActiveDynamicMontage, -CurrentBasePlayRate);
				}
				CurrentAnimation = Animation;
				CurrentSlot = Slot;
				return true;
			}
		}
	}

	Mesh->SetAnimationMode(EAnimationMode::AnimationSingleNode);
	Mesh->PlayAnimation(Animation, bLoop);
	Mesh->SetPosition(bReverse
		? FMath::Max(0.0f, Animation->GetPlayLength() - KINDA_SMALL_NUMBER)
		: 0.0f, false);
	Mesh->SetPlayRate(bReverse ? -CurrentBasePlayRate : CurrentBasePlayRate);
	ActiveDynamicMontage = nullptr;
	CurrentAnimation = Animation;
	CurrentSlot = Slot;
	return true;
}

void UAVSAnimationDriverComponent::ResumeLocomotion()
{
	if (ActivityPlayback.IsActive()) { CancelActivityPlayback(false); return; }
	// Repeated requests during a composed exit must not clear/restart that exit.
	if (bPlayingComposedEnd) return;
	bActivityOverride = false;
	bPlayingTransition = false;
	bPlayingComposedStart = false;
	const ACharacter* OwnerCharacter = Cast<ACharacter>(GetOwner());
	const EAVSAnimationSlot Desired = DetermineLocomotionSlot(OwnerCharacter ? OwnerCharacter->GetVelocity().Size2D() : 0.0f);
	if (!StartCurrentEntryEnd(Desired, true))
	{
		ResumeLocomotionImmediate(Desired);
	}
}

void UAVSAnimationDriverComponent::ResumeLocomotionImmediate(EAVSAnimationSlot DesiredSlot)
{
	if (USkeletalMeshComponent* Mesh = GetTargetMesh(); Mesh && SavedAnimationBlueprintClass &&
		Mesh->GetAnimationMode() != EAnimationMode::AnimationBlueprint)
	{
		Mesh->SetAnimInstanceClass(SavedAnimationBlueprintClass.Get());
	}
	bPlayingComposedStart = false;
	bPlayingComposedEnd = false;
	bResumeLocomotionAfterEnd = false;
	bHasPendingLocomotionAfterEnd = false;
	bHasCurrentEntry = false;
	CurrentAnimation = nullptr;
	bHasStartedLocomotion = false;
	CurrentLocomotionSlot = DesiredSlot;
	MovementPreparationGraceRemaining = DesiredSlot == EAVSAnimationSlot::Walk || DesiredSlot == EAVSAnimationSlot::Run
		? 0.35f
		: 0.0f;
	bHasStartedLocomotion = StartSelectedVariant(DesiredSlot, NAME_None, true, true);
	if (!bHasStartedLocomotion && (DesiredSlot == EAVSAnimationSlot::Walk || DesiredSlot == EAVSAnimationSlot::Run))
	{
		StopMovementForMissingLocomotion(DesiredSlot);
	}
	if (DesiredSlot == EAVSAnimationSlot::Idle)
	{
		ScheduleIdleVariant();
	}
}

bool UAVSAnimationDriverComponent::HasValidMovementAnimation() const
{
	const USkeletalMeshComponent* Mesh = GetTargetMesh();
	const USkeletalMesh* SkeletalMesh = Mesh ? Mesh->GetSkeletalMeshAsset() : nullptr;
	const USkeleton* Skeleton = SkeletalMesh ? SkeletalMesh->GetSkeleton() : nullptr;
	return AnimationProfile && Skeleton &&
		AnimationProfile->HasCompatibleAnimationForSkeleton(EAVSAnimationSlot::Walk, Skeleton);
}

bool UAVSAnimationDriverComponent::IsCurrentAnimationMovementCapable() const
{
	const bool bLocomotionSlot = CurrentSlot == EAVSAnimationSlot::Walk || CurrentSlot == EAVSAnimationSlot::Run ||
		CurrentSlot == EAVSAnimationSlot::WalkStart || CurrentSlot == EAVSAnimationSlot::WalkStop ||
		CurrentSlot == EAVSAnimationSlot::RunStart || CurrentSlot == EAVSAnimationSlot::RunStop;
	return !ActivityPlayback.IsActive() && bLocomotionSlot && CurrentAnimation != nullptr;
}

bool UAVSAnimationDriverComponent::IsMovementTemporarilyLocked() const
{
	return ActivityPlayback.IsActive() || ((bPlayingComposedStart || bPlayingComposedEnd) && !IsCurrentAnimationMovementCapable());
}

bool UAVSAnimationDriverComponent::PrepareForMovement()
{
	if (ActivityPlayback.IsActive()) { CancelActivityPlayback(false); return false; }
	if (!HasValidMovementAnimation())
	{
		StopMovementForMissingLocomotion(EAVSAnimationSlot::Walk);
		return false;
	}
	if (IsMovementTemporarilyLocked())
	{
		return false;
	}
	if (IsCurrentAnimationMovementCapable())
	{
		return true;
	}
	if (StartCurrentEntryEnd(EAVSAnimationSlot::Walk, true))
	{
		return false;
	}
	ResumeLocomotionImmediate(EAVSAnimationSlot::Walk);
	return IsCurrentAnimationMovementCapable() && !IsMovementTemporarilyLocked();
}

void UAVSAnimationDriverComponent::StopMovementForMissingLocomotion(EAVSAnimationSlot DesiredSlot)
{
	ACharacter* OwnerCharacter = Cast<ACharacter>(GetOwner());
	if (OwnerCharacter)
	{
		if (AAIController* AI = Cast<AAIController>(OwnerCharacter->GetController()))
		{
			AI->StopMovement();
		}
		OwnerCharacter->GetCharacterMovement()->StopMovementImmediately();
	}
	const uint8 SlotValue = static_cast<uint8>(DesiredSlot);
	if (!WarnedMissingLocomotionSlots.Contains(SlotValue))
	{
		WarnedMissingLocomotionSlots.Add(SlotValue);
		UE_LOG(LogAVSArchvizCharacters, Warning,
			TEXT("%s cannot move: the %s slot has no animation matching the current mesh Skeleton. Movement was stopped to prevent a stationary pose from sliding."),
			*GetNameSafe(GetOwner()), *UEnum::GetValueAsString(DesiredSlot));
	}
}

void UAVSAnimationDriverComponent::ScheduleIdleVariant()
{
	if (!AnimationProfile)
	{
		IdleVariantTimeRemaining = 10.0f;
		return;
	}
	IdleVariantTimeRemaining = RandomStream.FRandRange(
		FMath::Max(0.1f, AnimationProfile->IdleVariantMinTime),
		FMath::Max(AnimationProfile->IdleVariantMinTime, AnimationProfile->IdleVariantMaxTime));
}

FString UAVSAnimationDriverComponent::MakeVariantKey(EAVSAnimationSlot Slot, FName CustomName) const
{
	return Slot == EAVSAnimationSlot::Custom
		? FString::Printf(TEXT("Custom:%s"), *CustomName.ToString())
		: UEnum::GetValueAsString(Slot);
}

USkeletalMeshComponent* UAVSAnimationDriverComponent::GetTargetMesh() const
{
	const ACharacter* OwnerCharacter = Cast<ACharacter>(GetOwner());
	return OwnerCharacter ? OwnerCharacter->GetMesh() : nullptr;
}
