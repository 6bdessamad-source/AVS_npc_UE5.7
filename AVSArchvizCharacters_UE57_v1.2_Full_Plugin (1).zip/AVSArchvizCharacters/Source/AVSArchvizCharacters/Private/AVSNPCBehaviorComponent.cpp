#include "AVSNPCBehaviorComponent.h"

#include "AVSAnimationDriverComponent.h"
#include "AVSAnimationProfile.h"
#include "AVSArchvizNPCCharacter.h"
#include "AVSActivityProbability.h"
#include "AVSComposedAnimationPolicy.h"
#include "AVSArchvizSettings.h"
#include "AVSCrowdZone.h"
#include "AVSSplineCrowdZone.h"
#include "Components/CapsuleComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/SkeletalMesh.h"
#include "Navigation/PathFollowingComponent.h"
#include "AVSCrowdGlobalController.h"
#include "AVSCrowdRoute.h"
#include "AVSCrowdSubsystem.h"
#include "AVSPointOfInterest.h"
#include "AIController.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Engine/World.h"
#include "NavigationSystem.h"

UAVSNPCBehaviorComponent::UAVSNPCBehaviorComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.TickInterval = 0.25f;

	FAVSWeightedActivity Phone;
	Phone.Slot = EAVSAnimationSlot::PhoneLoop;
	Phone.Weight = 1.0f;
	Phone.MinDuration = 4.0f;
	Phone.MaxDuration = 10.0f;
	IdleActivities.Add(Phone);

	FAVSWeightedActivity Texting;
	Texting.Slot = EAVSAnimationSlot::Texting;
	Texting.Weight = 1.0f;
	Texting.MinDuration = 3.0f;
	Texting.MaxDuration = 8.0f;
	IdleActivities.Add(Texting);

	FAVSWeightedActivity Stretch;
	Stretch.Slot = EAVSAnimationSlot::Stretch;
	Stretch.Weight = 0.5f;
	Stretch.MinDuration = 2.0f;
	Stretch.MaxDuration = 5.0f;
	IdleActivities.Add(Stretch);
}

void UAVSNPCBehaviorComponent::BeginPlay()
{
	Super::BeginPlay();
	BehaviorRandom.Initialize(GetTypeHash(GetOwner()->GetFName()) ^ GetOwner()->GetUniqueID());
	WanderOrigin = GetOwner()->GetActorLocation();
	ScheduleNextActivity();
}

void UAVSNPCBehaviorComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	ResetBehavior();
	Super::EndPlay(EndPlayReason);
}

void UAVSNPCBehaviorComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	TimeUntilDecision -= DeltaTime;
	MoveRequestCooldownRemaining = FMath::Max(0.0f, MoveRequestCooldownRemaining - DeltaTime);
	RouteTransferCooldown = FMath::Max(0.0f, RouteTransferCooldown - DeltaTime);
	ConversationCooldownRemaining = FMath::Max(0.0f, ConversationCooldownRemaining - DeltaTime);
	if (bHasPendingStateChange)
	{
		const AAVSArchvizNPCCharacter* NPC = Cast<AAVSArchvizNPCCharacter>(GetOwner());
		if (NPC && NPC->AnimationDriver && NPC->AnimationDriver->IsActivityPlaybackActive())
		{
			return;
		}
		bHasPendingStateChange = false;
		AAVSPointOfInterest* PendingPOI = PendingPointOfInterest.Get();
		const bool bQueueOnly = bPendingPOIQueue;
		PendingPointOfInterest.Reset();
		SetBehaviorState(PendingState);
		if (IsValid(PendingPOI)) { RequestPointOfInterest(PendingPOI, bQueueOnly, true); }
	}

	if (bExternalBehaviorOwner) { return; }

	switch (State)
	{
	case EAVSNPCState::Idle: UpdateIdle(DeltaTime); break;
	case EAVSNPCState::Activity: UpdateActivity(DeltaTime); break;
	case EAVSNPCState::Wander: UpdateWander(); break;
	case EAVSNPCState::FollowActor: UpdateFollowActor(); break;
	case EAVSNPCState::FollowRoute: UpdateRoute(); break;
	case EAVSNPCState::Queue: POIElapsedTime += DeltaTime; UpdateQueue(); break;
	case EAVSNPCState::AtPointOfInterest: UpdatePointOfInterest(DeltaTime); break;
	case EAVSNPCState::Conversation: UpdateConversation(DeltaTime); break;
	default: break;
	}
}

void UAVSNPCBehaviorComponent::SetBehaviorState(EAVSNPCState NewState)
{
	if (State == NewState)
	{
		return;
	}

	PendingPointOfInterest.Reset();
	AAVSArchvizNPCCharacter* OwnerNPC = Cast<AAVSArchvizNPCCharacter>(GetOwner());
	const bool bLeavingPlaybackState = State == EAVSNPCState::Activity ||
		State == EAVSNPCState::Conversation || (State == EAVSNPCState::AtPointOfInterest && bStartedPOIActivity);
	if (NewState != EAVSNPCState::Inactive && bLeavingPlaybackState && OwnerNPC &&
		OwnerNPC->AnimationDriver && OwnerNPC->AnimationDriver->IsActivityPlaybackActive())
	{
		// Retain the behavior and reservation until the composed exit has finished.
		PendingState = NewState;
		bHasPendingStateChange = true;
		OwnerNPC->AnimationDriver->CancelActivityPlayback(false);
		return;
	}

	bHasPendingStateChange = false;
	const EAVSNPCState Previous = State;
	const bool bPreviousPOIState = Previous == EAVSNPCState::AtPointOfInterest || Previous == EAVSNPCState::Queue;
	const bool bNewPOIState = NewState == EAVSNPCState::AtPointOfInterest || NewState == EAVSNPCState::Queue;
	if (bPreviousPOIState && !bNewPOIState)
	{
		if (PointOfInterest.IsValid())
		{
			if (Previous == EAVSNPCState::Queue)
			{
				PointOfInterest->LeaveQueue(GetOwner());
			}
			else
			{
				PointOfInterest->Release(GetOwner());
			}
		}
		PointOfInterest.Reset();
		bStartedPOIActivity = false;
		POITimeRemaining = 0.0f;
		POIElapsedTime = 0.0f;
		POIAlignmentElapsedTime = 0.0f;
		RestoreFacingControl();
		if (AAVSArchvizNPCCharacter* NPC = Cast<AAVSArchvizNPCCharacter>(GetOwner()))
		{
			if (NPC->AnimationDriver) { NPC->AnimationDriver->ResumeLocomotion(); }
		}
	}

	if (Previous == EAVSNPCState::Activity && NewState != EAVSNPCState::Activity)
	{
		if (AAVSArchvizNPCCharacter* NPC = Cast<AAVSArchvizNPCCharacter>(GetOwner()))
		{
			if (NPC->AnimationDriver) { NPC->AnimationDriver->ResumeLocomotion(); }
		}
		OnActivityFinished.Broadcast(ActiveActivitySlot, ActiveActivityName);
		ActivityTimeRemaining = 0.0f;
		ScheduleNextActivity();
	}

	if (Previous == EAVSNPCState::Conversation && NewState != EAVSNPCState::Conversation)
	{
		ClearConversationState();
	}

	if (NewState == EAVSNPCState::Inactive && OwnerNPC && OwnerNPC->AnimationDriver)
	{
		OwnerNPC->AnimationDriver->CancelActivityPlayback(true);
	}
	State = NewState;
	TimeUntilDecision = 0.0f;
	MoveRequestCooldownRemaining = 0.0f;
	bHasLastMoveRequest = false;
	if (NewState == EAVSNPCState::Idle || NewState == EAVSNPCState::Paused ||
		NewState == EAVSNPCState::Inactive || NewState == EAVSNPCState::Activity ||
		NewState == EAVSNPCState::Conversation)
	{
		if (ACharacter* OwnerCharacter = Cast<ACharacter>(GetOwner()))
		{
			if (AAIController* AI = Cast<AAIController>(OwnerCharacter->GetController()))
			{
				AI->StopMovement();
			}
			if (NewState == EAVSNPCState::Conversation)
			{
				OwnerCharacter->GetCharacterMovement()->StopMovementImmediately();
			}
		}
	}
	OnStateChanged.Broadcast(Previous, NewState);
}

void UAVSNPCBehaviorComponent::StartWandering(FVector NewOrigin, float NewRadius)
{
	SetWanderArea(NewOrigin, NewRadius);
	SetBehaviorState(EAVSNPCState::Wander);
}

void UAVSNPCBehaviorComponent::SetWanderArea(FVector NewOrigin, float NewRadius)
{
	if (!NewOrigin.ContainsNaN()) { WanderOrigin = NewOrigin; }
	WanderRadius = static_cast<float>(AVS::Composed::Safe(NewRadius, 1000.0, 0.0, 1000000.0));
}

void UAVSNPCBehaviorComponent::FollowActor(AActor* NewTarget, FVector Offset)
{
	FollowTarget = NewTarget;
	FollowOffset = Offset;
	SetBehaviorState(NewTarget ? EAVSNPCState::FollowActor : EAVSNPCState::Idle);
}

void UAVSNPCBehaviorComponent::FollowRoute(AAVSCrowdRoute* NewRoute, bool bLoopRoute)
{
	FollowRouteWithCompletion(NewRoute, bLoopRoute, EAVSNPCState::Idle);
}

void UAVSNPCBehaviorComponent::FollowRouteWithCompletion(AAVSCrowdRoute* NewRoute, bool bLoopRoute, EAVSNPCState CompletionState)
{
	FollowRouteWithOptions(NewRoute, bLoopRoute, CompletionState, 0.0f, INDEX_NONE);
}

void UAVSNPCBehaviorComponent::FollowRouteWithOptions(AAVSCrowdRoute* NewRoute, bool bLoopRoute,
	EAVSNPCState CompletionState, float LateralOffset, int32 StartPointIndex)
{
	Route = NewRoute;
	RouteLateralOffset = LateralOffset;
	RoutePointIndex = StartPointIndex;
	if (NewRoute && NewRoute->GetRoutePointCount() > 0)
	{
		if (RoutePointIndex == INDEX_NONE)
		{
			float BestDistanceSquared = TNumericLimits<float>::Max();
			RoutePointIndex = 0;
			for (int32 Index = 0; Index < NewRoute->GetRoutePointCount(); ++Index)
			{
				const FVector Candidate = NewRoute->GetRoutePoint(Index) + NewRoute->GetRouteRightVector(Index) * RouteLateralOffset;
				const float DistanceSquared = FVector::DistSquared2D(GetOwner()->GetActorLocation(), Candidate);
				if (DistanceSquared < BestDistanceSquared)
				{
					BestDistanceSquared = DistanceSquared;
					RoutePointIndex = Index;
				}
			}
		}
		RoutePointIndex = FMath::Clamp(RoutePointIndex, 0, NewRoute->GetRoutePointCount() - 1);
	}
	else
	{
		RoutePointIndex = 0;
	}
	bLoop = bLoopRoute;
	RouteCompletionState = CompletionState == EAVSNPCState::Wander ? EAVSNPCState::Wander : EAVSNPCState::Idle;
	SetBehaviorState(NewRoute ? EAVSNPCState::FollowRoute : EAVSNPCState::Idle);
}

void UAVSNPCBehaviorComponent::UsePointOfInterest(AAVSPointOfInterest* NewPOI)
{
	RequestPointOfInterest(NewPOI, false);
}

void UAVSNPCBehaviorComponent::QueueAtPointOfInterest(AAVSPointOfInterest* NewPOI)
{
	RequestPointOfInterest(NewPOI, true);
}

void UAVSNPCBehaviorComponent::RequestPointOfInterest(AAVSPointOfInterest* NewPOI, bool bQueueOnly, bool bPreserveReturnState)
{
	if (PointOfInterest == NewPOI && (State == EAVSNPCState::AtPointOfInterest || State == EAVSNPCState::Queue)) { return; }
	if (!bPreserveReturnState && State != EAVSNPCState::AtPointOfInterest && State != EAVSNPCState::Queue)
	{
		const EAVSNPCState PreviousIntent = State == EAVSNPCState::Activity ? ReturnStateAfterActivity : State;
		ReturnStateAfterPOI = PreviousIntent == EAVSNPCState::Wander || PreviousIntent == EAVSNPCState::FollowRoute || PreviousIntent == EAVSNPCState::FollowActor
			? PreviousIntent : EAVSNPCState::Idle;
	}
	bPendingWanderAfterConversation = false;
	if (State == EAVSNPCState::AtPointOfInterest || State == EAVSNPCState::Queue ||
		State == EAVSNPCState::Activity || State == EAVSNPCState::Conversation)
	{
		SetBehaviorState(EAVSNPCState::Idle);
		if (bHasPendingStateChange)
		{
			PendingPointOfInterest = NewPOI;
			bPendingPOIQueue = bQueueOnly;
			return;
		}
	}
	if (!IsValid(NewPOI)) { SetBehaviorState(ReturnStateAfterPOI); return; }
	if (!bQueueOnly && NewPOI->Reserve(GetOwner()))
	{
		PointOfInterest = NewPOI;
		bStartedPOIActivity = false;
		POIElapsedTime = POIAlignmentElapsedTime = 0.0f;
		SetBehaviorState(EAVSNPCState::AtPointOfInterest);
		// Failed or pending local navigation is retried with backoff until arrival timeout.
		UpdatePointOfInterest(0.0f);
	}
	else if (NewPOI->JoinQueue(GetOwner()))
	{
		PointOfInterest = NewPOI;
		bStartedPOIActivity = false;
		POIElapsedTime = 0.0f;
		SetBehaviorState(EAVSNPCState::Queue);
		UpdateQueue();
	}
	else { SetBehaviorState(ReturnStateAfterPOI); }
}

void UAVSNPCBehaviorComponent::UpdateIdle(float DeltaTime)
{
	if (bPendingWanderAfterConversation)
	{
		PostConversationIdleRemaining -= DeltaTime;
		if (PostConversationIdleRemaining <= 0.0f)
		{
			bPendingWanderAfterConversation = false;
			StartWandering(ConversationWanderOrigin, WanderRadius);
		}
		return;
	}

	if (!bEnableIdleActivities)
	{
		return;
	}
	TimeUntilNextActivity -= DeltaTime;
	if (TimeUntilNextActivity <= 0.0f && !StartRandomIdleActivity())
	{
		ScheduleNextActivity();
	}
}

FAVSAmbientActivityWeights UAVSNPCBehaviorComponent::GetAmbientActivityWeights() const
{
	if (bOverrideAmbientActivityWeights) { return AmbientActivityWeights; }
	const AAVSArchvizNPCCharacter* NPC = Cast<AAVSArchvizNPCCharacter>(GetOwner());
	const AAVSCrowdZone* Zone = NPC ? Cast<AAVSCrowdZone>(NPC->GetOwningGenerator()) : nullptr;
	if (Zone && Zone->bOverrideAmbientActivityWeights) { return Zone->AmbientActivityWeights; }
	const AAVSSplineCrowdZone* SplineZone = NPC ? Cast<AAVSSplineCrowdZone>(NPC->GetOwningGenerator()) : nullptr;
	if (SplineZone && SplineZone->bOverrideAmbientActivityWeights) { return SplineZone->AmbientActivityWeights; }
	const UAVSCrowdSubsystem* Subsystem = GetWorld() ? GetWorld()->GetSubsystem<UAVSCrowdSubsystem>() : nullptr;
	const AAVSCrowdGlobalController* Controller = Subsystem ? Subsystem->GetGlobalController() : nullptr;
	return Controller && Controller->bOverrideAmbientActivityWeights ? Controller->AmbientActivityWeights : GetDefault<UAVSArchvizSettings>()->AmbientActivityWeights;
}

FAVSConversationSettings UAVSNPCBehaviorComponent::GetConversationSettings() const
{
	const AAVSArchvizNPCCharacter* NPC = Cast<AAVSArchvizNPCCharacter>(GetOwner());
	const AAVSCrowdZone* Zone = NPC ? Cast<AAVSCrowdZone>(NPC->GetOwningGenerator()) : nullptr;
	if (Zone && Zone->bOverrideConversationSettings) { return Zone->Conversations; }
	const AAVSSplineCrowdZone* SplineZone = NPC ? Cast<AAVSSplineCrowdZone>(NPC->GetOwningGenerator()) : nullptr;
	if (SplineZone && SplineZone->bOverrideConversationSettings) { return SplineZone->Conversations; }
	const UAVSCrowdSubsystem* Subsystem = GetWorld() ? GetWorld()->GetSubsystem<UAVSCrowdSubsystem>() : nullptr;
	const AAVSCrowdGlobalController* Controller = Subsystem ? Subsystem->GetGlobalController() : nullptr;
	return Controller && Controller->bOverrideConversationSettings ? Controller->Conversations : GetDefault<UAVSArchvizSettings>()->Conversations;
}

bool UAVSNPCBehaviorComponent::StartRandomIdleActivity()
{
	AAVSArchvizNPCCharacter* NPC = Cast<AAVSArchvizNPCCharacter>(GetOwner());
	if (!NPC || State != EAVSNPCState::Idle || bHasPendingStateChange || !NPC->AnimationDriver ||
		NPC->AnimationDriver->IsActivityPlaybackActive() || !NPC->AnimationDriver->AnimationProfile)
	{
		return false;
	}
	UAVSAnimationProfile* Profile = NPC->AnimationDriver->AnimationProfile;
	USkeletalMeshComponent* Mesh = NPC->AnimationDriver->GetTargetMesh();
	const USkeleton* Skeleton = Mesh && Mesh->GetSkeletalMeshAsset() ? Mesh->GetSkeletalMeshAsset()->GetSkeleton() : nullptr;
	if (!Skeleton) { return false; }

	// Preserve configured legacy activities; always offer ordinary Idle, Smoke and Stretch
	// when their profile entries are usable. Selection happens by category, then by row.
	TArray<FAVSWeightedActivity> Choices = IdleActivities;
	const int32 ConfiguredChoiceCount = Choices.Num();
	auto AddDefaultSlot = [&Choices](EAVSAnimationSlot Slot)
	{
		if (!Choices.ContainsByPredicate([Slot](const FAVSWeightedActivity& Activity) { return Activity.Slot == Slot; }))
		{
			FAVSWeightedActivity Activity;
			Activity.Slot = Slot;
			Choices.Add(Activity);
		}
	};
	AddDefaultSlot(EAVSAnimationSlot::Idle);
	AddDefaultSlot(EAVSAnimationSlot::Smoke);
	AddDefaultSlot(EAVSAnimationSlot::Stretch);
	for (const FAVSNamedAnimation& Entry : Profile->Animations)
	{
		if (Entry.Slot == EAVSAnimationSlot::Custom && !Choices.ContainsByPredicate(
			[&Entry](const FAVSWeightedActivity& Activity) { return Activity.Slot == Entry.Slot && Activity.CustomName == Entry.CustomName; }))
		{
			FAVSWeightedActivity Activity;
			Activity.Slot = Entry.Slot;
			Activity.CustomName = Entry.CustomName;
			Choices.Add(Activity);
		}
	}
	auto CategoryOf = [](EAVSAnimationSlot Slot)
	{
		return Slot == EAVSAnimationSlot::Idle ? 0 : Slot == EAVSAnimationSlot::Smoke ? 1 : Slot == EAVSAnimationSlot::Stretch ? 2 : 3;
	};
	TArray<int32> Available[4];
	for (int32 Index = 0; Index < Choices.Num(); ++Index)
	{
		const FAVSWeightedActivity& Activity = Choices[Index];
		// Never allow a walking row into the stationary activity scheduler.
		if (Activity.Slot == EAVSAnimationSlot::Walk || Activity.Slot == EAVSAnimationSlot::Run ||
			Activity.Slot == EAVSAnimationSlot::WalkStart || Activity.Slot == EAVSAnimationSlot::WalkStop ||
			Activity.Slot == EAVSAnimationSlot::RunStart || Activity.Slot == EAVSAnimationSlot::RunStop ||
			AVSActivityProbability::AvailableWeight(Activity.Weight) <= 0.0)
		{
			continue;
		}
		FAVSNamedAnimation Unused;
		int32 UnusedIndex = INDEX_NONE;
		FRandomStream Probe(0);
		if (Profile->SelectCompatibleAnimationVariant(Activity.Slot, Activity.CustomName, Skeleton, Probe, INDEX_NONE, Unused, UnusedIndex))
		{
			Available[CategoryOf(Activity.Slot)].Add(Index);
		}
	}
	const FAVSAmbientActivityWeights Weights = GetAmbientActivityWeights();
	const double CategoryWeights[] = {
		AVSActivityProbability::AvailableWeight(Weights.Idle, !Available[0].IsEmpty()),
		AVSActivityProbability::AvailableWeight(Weights.Smoking, !Available[1].IsEmpty()),
		AVSActivityProbability::AvailableWeight(Weights.Stretching, !Available[2].IsEmpty()),
		AVSActivityProbability::AvailableWeight(Weights.Custom, !Available[3].IsEmpty())};
	const int32 Category = AVSActivityProbability::ChooseWeighted(CategoryWeights, 4, BehaviorRandom.FRand());
	if (Category == INDEX_NONE) { return false; }
	TArray<double> RowWeights;
	for (int32 Index : Available[Category]) { RowWeights.Add(Choices[Index].Weight); }
	const int32 Row = AVSActivityProbability::ChooseWeighted(RowWeights.GetData(), RowWeights.Num(), BehaviorRandom.FRand());
	if (Row == INDEX_NONE) { return false; }
	const int32 SelectedChoiceIndex = Available[Category][Row];
	const FAVSWeightedActivity& Selected = Choices[SelectedChoiceIndex];
	const FString Key = FString::Printf(TEXT("%d:%s"), static_cast<int32>(Selected.Slot), *Selected.CustomName.ToString());
	const int32* PreviousIndex = LastActivityVariantIndices.Find(Key);
	FAVSNamedAnimation Entry;
	int32 EntryIndex = INDEX_NONE;
	if (!Profile->SelectCompatibleAnimationVariant(Selected.Slot, Selected.CustomName, Skeleton, BehaviorRandom,
		PreviousIndex ? *PreviousIndex : INDEX_NONE, Entry, EntryIndex)) { return false; }
	if (SelectedChoiceIndex < ConfiguredChoiceCount) { Entry.bLoop = Selected.bLoop; }
	const float MinDuration = static_cast<float>(AVS::Composed::Safe(Selected.MinDuration, 3.0, 0.1, 86400.0));
	ActivityTimeRemaining = BehaviorRandom.FRandRange(MinDuration,
		static_cast<float>(AVS::Composed::Safe(Selected.MaxDuration, MinDuration, MinDuration, 86400.0)));
	if (!NPC->AnimationDriver->PlayAnimationEntry(Entry, Selected.Slot, ActivityTimeRemaining)) { return false; }
	LastActivityVariantIndices.Add(Key, EntryIndex);
	ReturnStateAfterActivity = State;
	ActiveActivitySlot = Selected.Slot;
	ActiveActivityName = Selected.CustomName;
	SetBehaviorState(EAVSNPCState::Activity);
	OnActivityStarted.Broadcast(ActiveActivitySlot, ActiveActivityName);
	return true;
}

void UAVSNPCBehaviorComponent::UpdateActivity(float DeltaTime)
{
	const AAVSArchvizNPCCharacter* NPC = Cast<AAVSArchvizNPCCharacter>(GetOwner());
	if (!NPC || !NPC->AnimationDriver || !NPC->AnimationDriver->IsActivityPlaybackActive())
	{
		SetBehaviorState(ReturnStateAfterActivity);
	}
}

void UAVSNPCBehaviorComponent::CancelActivity()
{
	if (State == EAVSNPCState::Activity)
	{
		SetBehaviorState(ReturnStateAfterActivity);
	}
}

bool UAVSNPCBehaviorComponent::CanJoinConversation() const
{
	const AActor* OwnerActor = GetOwner();
	const AAVSArchvizNPCCharacter* NPC = Cast<AAVSArchvizNPCCharacter>(OwnerActor);
	if (!bAllowProximityConversations || !NPC || OwnerActor->IsHidden() || !IsComponentTickEnabled() ||
		bExternalBehaviorOwner || bHasPendingStateChange || bPendingWanderAfterConversation ||
		ConversationCooldownRemaining > 0.0f || (State != EAVSNPCState::Idle && State != EAVSNPCState::Wander) ||
		!NPC->AnimationDriver || !NPC->AnimationDriver->AnimationProfile || NPC->AnimationDriver->IsActivityPlaybackActive())
	{
		return false;
	}
	const FAVSConversationSettings Settings = GetConversationSettings();
	USkeletalMeshComponent* Mesh = NPC->AnimationDriver->GetTargetMesh();
	const USkeleton* Skeleton = Mesh && Mesh->GetSkeletalMeshAsset() ? Mesh->GetSkeletalMeshAsset()->GetSkeleton() : nullptr;
	return Skeleton && ((AVSActivityProbability::AvailableWeight(Settings.IdleAnimationWeight) > 0.0 &&
		NPC->AnimationDriver->AnimationProfile->HasCompatibleAnimationForSkeleton(EAVSAnimationSlot::Idle, Skeleton)) ||
		(AVSActivityProbability::AvailableWeight(Settings.TalkAnimationWeight) > 0.0 &&
		NPC->AnimationDriver->AnimationProfile->HasCompatibleAnimationForSkeleton(EAVSAnimationSlot::Talk, Skeleton)));
}

int32 UAVSNPCBehaviorComponent::GetConversationParticipantCount() const
{
	int32 Count = 0;
	for (const TWeakObjectPtr<AAVSArchvizNPCCharacter>& Participant : ConversationParticipants)
	{
		const AAVSArchvizNPCCharacter* NPC = Participant.Get();
		if (NPC && NPC->Behavior && NPC->Behavior->GetBehaviorState() == EAVSNPCState::Conversation)
		{
			++Count;
		}
	}
	return Count;
}

void UAVSNPCBehaviorComponent::DeferConversations(float Duration)
{
	ConversationCooldownRemaining = FMath::Max(ConversationCooldownRemaining, FMath::Max(0.0f, Duration));
}

bool UAVSNPCBehaviorComponent::StartConversation(const TArray<AAVSArchvizNPCCharacter*>& Participants,
	float Duration, float Cooldown, float PostConversationIdleTime, float FacingInterpSpeed)
{
	if (!CanJoinConversation())
	{
		return false;
	}

	ConversationParticipants.Reset();
	for (AAVSArchvizNPCCharacter* Participant : Participants)
	{
		if (IsValid(Participant))
		{
			ConversationParticipants.AddUnique(Participant);
		}
	}
	const AAVSArchvizNPCCharacter* OwnerNPC = Cast<AAVSArchvizNPCCharacter>(GetOwner());
	const bool bContainsOwner = ConversationParticipants.ContainsByPredicate(
		[OwnerNPC](const TWeakObjectPtr<AAVSArchvizNPCCharacter>& Participant)
		{
			return Participant.Get() == OwnerNPC;
		});
	if (ConversationParticipants.Num() < 2 || !bContainsOwner)
	{
		ConversationParticipants.Reset();
		return false;
	}

	ConversationTimeRemaining = static_cast<float>(AVS::Composed::Safe(Duration, 10.0, 0.1, 86400.0));
	PendingConversationCooldown = static_cast<float>(AVS::Composed::Safe(Cooldown, 15.0, 0.0, 86400.0));
	PostConversationIdleRemaining = static_cast<float>(AVS::Composed::Safe(PostConversationIdleTime, 1.0, 0.0, 86400.0));
	ConversationFacingSpeed = static_cast<float>(AVS::Composed::Safe(FacingInterpSpeed, 3.0, 0.1, 100.0));
	ConversationAnimationTimeRemaining = 0.0f;
	bConversationVariantPending = false;
	LastConversationSlot = EAVSAnimationSlot::Custom;
	LastConversationVariantIndex = INDEX_NONE;
	bPendingWanderAfterConversation = false;
	ConversationWanderOrigin = GetOwner()->GetActorLocation();

	if (ACharacter* OwnerCharacter = Cast<ACharacter>(GetOwner()))
	{
		bSavedOrientRotationToMovement = OwnerCharacter->GetCharacterMovement()->bOrientRotationToMovement;
		bHasSavedFacingControl = true;
		OwnerCharacter->GetCharacterMovement()->bOrientRotationToMovement = false;
	}

	SetBehaviorState(EAVSNPCState::Conversation);
	if (!PlayConversationVariant()) { ConversationAnimationTimeRemaining = 2.0f; }
	return true;
}

void UAVSNPCBehaviorComponent::LeaveConversation(bool bReturnToWander)
{
	if (State != EAVSNPCState::Conversation)
	{
		return;
	}
	ConversationWanderOrigin = GetOwner()->GetActorLocation();
	bPendingWanderAfterConversation = bReturnToWander;
	ConversationCooldownRemaining = FMath::Max(ConversationCooldownRemaining, PendingConversationCooldown);
	SetBehaviorState(EAVSNPCState::Idle);
}

bool UAVSNPCBehaviorComponent::SelectConversationVariant(FAVSNamedAnimation& OutEntry, EAVSAnimationSlot& OutSlot, int32& OutIndex)
{
	AAVSArchvizNPCCharacter* NPC = Cast<AAVSArchvizNPCCharacter>(GetOwner());
	if (!NPC || !NPC->AnimationDriver || !NPC->AnimationDriver->AnimationProfile) { return false; }
	UAVSAnimationProfile* Profile = NPC->AnimationDriver->AnimationProfile;
	USkeletalMeshComponent* Mesh = NPC->AnimationDriver->GetTargetMesh();
	const USkeleton* Skeleton = Mesh && Mesh->GetSkeletalMeshAsset() ? Mesh->GetSkeletalMeshAsset()->GetSkeleton() : nullptr;
	FAVSNamedAnimation Selected[2];
	int32 SelectedIndices[2] = { INDEX_NONE, INDEX_NONE };
	const EAVSAnimationSlot Slots[2] = { EAVSAnimationSlot::Idle, EAVSAnimationSlot::Talk };
	bool Available[2];
	for (int32 Category = 0; Category < 2; ++Category)
	{
		Available[Category] = Skeleton && Profile->SelectCompatibleAnimationVariant(Slots[Category], NAME_None,
			Skeleton, BehaviorRandom, Slots[Category] == LastConversationSlot ? LastConversationVariantIndex : INDEX_NONE,
			Selected[Category], SelectedIndices[Category]);
	}
	const FAVSConversationSettings Settings = GetConversationSettings();
	const double Weights[] = {
		AVSActivityProbability::AvailableWeight(Settings.IdleAnimationWeight, Available[0]),
		AVSActivityProbability::AvailableWeight(Settings.TalkAnimationWeight, Available[1])};
	const int32 Category = AVSActivityProbability::ChooseWeighted(Weights, 2, BehaviorRandom.FRand());
	if (Category == INDEX_NONE) { return false; }
	OutEntry = Selected[Category];
	OutSlot = Slots[Category];
	OutIndex = SelectedIndices[Category];
	return true;
}

void UAVSNPCBehaviorComponent::ScheduleConversationAnimation()
{
	const FAVSConversationSettings Settings = GetConversationSettings();
	const float MinInterval = static_cast<float>(AVS::Composed::Safe(Settings.MinAnimationInterval, 3.0, 0.1, 86400.0));
	ConversationAnimationTimeRemaining = BehaviorRandom.FRandRange(MinInterval,
		static_cast<float>(AVS::Composed::Safe(Settings.MaxAnimationInterval, MinInterval, MinInterval, 86400.0)));
}

bool UAVSNPCBehaviorComponent::PlayConversationVariant()
{
	AAVSArchvizNPCCharacter* NPC = Cast<AAVSArchvizNPCCharacter>(GetOwner());
	if (!NPC || !NPC->AnimationDriver || NPC->AnimationDriver->IsActivityPlaybackActive()) { return false; }
	FAVSNamedAnimation Entry;
	EAVSAnimationSlot Slot = EAVSAnimationSlot::Idle;
	int32 Index = INDEX_NONE;
	if (bConversationVariantPending)
	{
		Entry = PendingConversationEntry;
		Slot = PendingConversationSlot;
		Index = PendingConversationVariantIndex;
	}
	else if (!SelectConversationVariant(Entry, Slot, Index)) { return false; }
	if (!NPC->AnimationDriver->PlayAnimationEntry(Entry, Slot)) { return false; }
	LastConversationSlot = Slot;
	LastConversationVariantIndex = Index;
	ScheduleConversationAnimation();
	bConversationVariantPending = false;
	PendingConversationEntry = FAVSNamedAnimation();
	PendingConversationVariantIndex = INDEX_NONE;
	return true;
}

void UAVSNPCBehaviorComponent::UpdateConversation(float DeltaTime)
{
	ConversationTimeRemaining -= DeltaTime;
	ConversationParticipants.RemoveAll([](const TWeakObjectPtr<AAVSArchvizNPCCharacter>& Participant)
	{
		const AAVSArchvizNPCCharacter* Other = Participant.Get();
		return !Other || Other->IsHidden() || !Other->Behavior || Other->Behavior->GetBehaviorState() != EAVSNPCState::Conversation;
	});
	FVector OtherPeopleCenter = FVector::ZeroVector;
	int32 OtherPeopleCount = 0;
	for (const TWeakObjectPtr<AAVSArchvizNPCCharacter>& Participant : ConversationParticipants)
	{
		AAVSArchvizNPCCharacter* Other = Participant.Get();
		if (!Other || Other == GetOwner() || !Other->Behavior ||
			Other->Behavior->GetBehaviorState() != EAVSNPCState::Conversation)
		{
			continue;
		}
		OtherPeopleCenter += Other->GetActorLocation();
		++OtherPeopleCount;
	}

	if (OtherPeopleCount == 0 || ConversationTimeRemaining <= 0.0f)
	{
		LeaveConversation(true);
		return;
	}

	AAVSArchvizNPCCharacter* NPC = Cast<AAVSArchvizNPCCharacter>(GetOwner());
	if (NPC && NPC->AnimationDriver)
	{
		if (bConversationVariantPending)
		{
			if (!NPC->AnimationDriver->IsActivityPlaybackActive() && !PlayConversationVariant())
			{
				bConversationVariantPending = false;
				ConversationAnimationTimeRemaining = 2.0f;
			}
		}
		else if (NPC->AnimationDriver->IsActivityBodyActive())
		{
			// Start and End traversal never consume the body change interval.
			ConversationAnimationTimeRemaining -= DeltaTime;
			if (ConversationAnimationTimeRemaining <= 0.0f)
			{
				if (!SelectConversationVariant(PendingConversationEntry, PendingConversationSlot, PendingConversationVariantIndex))
				{
					ConversationAnimationTimeRemaining = 2.0f;
				}
				else if (PendingConversationSlot == LastConversationSlot && PendingConversationVariantIndex == LastConversationVariantIndex)
				{
					// A repeated singleton-category draw keeps the existing pose untouched.
					// Forcing Talk here would bias the requested 50/50 category distribution.
					ScheduleConversationAnimation();
				}
				else
				{
					bConversationVariantPending = true;
					NPC->AnimationDriver->CancelActivityPlayback(false);
				}
			}
		}
		else if (!NPC->AnimationDriver->IsActivityPlaybackActive())
		{
			ConversationAnimationTimeRemaining -= DeltaTime;
			if (ConversationAnimationTimeRemaining <= 0.0f && !PlayConversationVariant()) { ConversationAnimationTimeRemaining = 2.0f; }
		}
	}

	OtherPeopleCenter /= static_cast<float>(OtherPeopleCount);
	FVector LookDirection = OtherPeopleCenter - GetOwner()->GetActorLocation();
	LookDirection.Z = 0.0f;
	if (!LookDirection.IsNearlyZero())
	{
		const FRotator TargetRotation(0.0f, LookDirection.Rotation().Yaw, 0.0f);
		const FRotator NewRotation = FMath::RInterpTo(GetOwner()->GetActorRotation(), TargetRotation, DeltaTime, ConversationFacingSpeed);
		GetOwner()->SetActorRotation(NewRotation);
	}
}

void UAVSNPCBehaviorComponent::ClearConversationState()
{
	ConversationCooldownRemaining = FMath::Max(ConversationCooldownRemaining, PendingConversationCooldown);
	ConversationParticipants.Reset();
	ConversationTimeRemaining = 0.0f;
	PendingConversationCooldown = 0.0f;
	bConversationVariantPending = false;
	PendingConversationEntry = FAVSNamedAnimation();
	PendingConversationVariantIndex = INDEX_NONE;
	if (AAVSArchvizNPCCharacter* NPC = Cast<AAVSArchvizNPCCharacter>(GetOwner()))
	{
		if (NPC->AnimationDriver)
		{
			NPC->AnimationDriver->ResumeLocomotion();
		}
		RestoreFacingControl();
	}
}

void UAVSNPCBehaviorComponent::RestoreFacingControl()
{
	if (bHasSavedFacingControl)
	{
		if (ACharacter* OwnerCharacter = Cast<ACharacter>(GetOwner()))
		{
			OwnerCharacter->GetCharacterMovement()->bOrientRotationToMovement = bSavedOrientRotationToMovement;
		}
		bHasSavedFacingControl = false;
	}
}

void UAVSNPCBehaviorComponent::ScheduleNextActivity()
{
	const float MinInterval = static_cast<float>(AVS::Composed::Safe(MinActivityInterval, 8.0, 0.1, 86400.0));
	TimeUntilNextActivity = BehaviorRandom.FRandRange(MinInterval,
		static_cast<float>(AVS::Composed::Safe(MaxActivityInterval, MinInterval, MinInterval, 86400.0)));
}

void UAVSNPCBehaviorComponent::ResetBehavior()
{
	bHasPendingStateChange = false;
	bExternalBehaviorOwner = false;
	PendingState = EAVSNPCState::Idle;
	PendingPointOfInterest.Reset();
	bPendingPOIQueue = false;
	if (AAVSArchvizNPCCharacter* NPC = Cast<AAVSArchvizNPCCharacter>(GetOwner()))
	{
		if (NPC->AnimationDriver) { NPC->AnimationDriver->CancelActivityPlayback(true); }
	}
	SetBehaviorState(EAVSNPCState::Inactive);
	// Explicit cleanup also handles a partially initialized or previously Inactive entry.
	if (PointOfInterest.IsValid())
	{
		PointOfInterest->LeaveQueue(GetOwner());
		PointOfInterest->Release(GetOwner());
	}
	PointOfInterest.Reset();
	ClearConversationState();
	RestoreFacingControl();
	FollowTarget.Reset();
	Route.Reset();
	RoutePointIndex = 0;
	RouteLateralOffset = 0.0f;
	RouteTransferCooldown = 0.0f;
	RouteCompletionState = EAVSNPCState::Idle;
	ReturnStateAfterActivity = EAVSNPCState::Idle;
	ReturnStateAfterPOI = EAVSNPCState::Idle;
	bStartedPOIActivity = false;
	bPendingWanderAfterConversation = false;
	PostConversationIdleRemaining = 0.0f;
	ConversationCooldownRemaining = 0.0f;
	PendingConversationCooldown = 0.0f;
	ConversationAnimationTimeRemaining = 0.0f;
	bConversationVariantPending = false;
	ConversationParticipants.Reset();
	LastConversationSlot = EAVSAnimationSlot::Custom;
	LastConversationVariantIndex = INDEX_NONE;
	LastActivityVariantIndices.Reset();
	MoveRequestCooldownRemaining = 0.0f;
	TimeUntilDecision = 0.0f;
	NavigationFailureBackoff = 0.25f;
	bHasLastMoveRequest = false;
	LastMoveRequestDestination = FVector::ZeroVector;
	ActivityTimeRemaining = POITimeRemaining = POIElapsedTime = POIAlignmentElapsedTime = 0.0f;
	ActiveActivitySlot = EAVSAnimationSlot::Idle;
	ActiveActivityName = NAME_None;
	WanderOrigin = GetOwner() ? GetOwner()->GetActorLocation() : FVector::ZeroVector;
	ScheduleNextActivity();
	if (ACharacter* OwnerCharacter = Cast<ACharacter>(GetOwner()))
	{
		if (AAIController* AI = Cast<AAIController>(OwnerCharacter->GetController())) { AI->StopMovement(); }
		OwnerCharacter->GetCharacterMovement()->StopMovementImmediately();
	}
}

bool UAVSNPCBehaviorComponent::IssueMoveTo(const FVector& Destination, float DestinationAcceptanceRadius)
{
	if (bHasPendingStateChange || Destination.ContainsNaN()) { return false; }
	if (const AAVSArchvizNPCCharacter* NPC = Cast<AAVSArchvizNPCCharacter>(GetOwner()))
	{
		if (!NPC->AnimationDriver || !NPC->AnimationDriver->PrepareForMovement())
		{
			return false;
		}
	}
	UAVSCrowdSubsystem* CrowdSubsystem = nullptr;
	if (UWorld* World = GetWorld())
	{
		CrowdSubsystem = World->GetSubsystem<UAVSCrowdSubsystem>();
		if (CrowdSubsystem)
		{
			if (CrowdSubsystem->IsLocationExcluded(Destination, false))
			{
				return false;
			}
		}
	}

	const AAVSCrowdGlobalController* Controller = CrowdSubsystem
		? CrowdSubsystem->GetGlobalController()
		: nullptr;
	const bool bOptimizePaths = !Controller || Controller->bOptimizeRepeatedPathRequests;
	if (bOptimizePaths && bHasLastMoveRequest &&
		MoveRequestCooldownRemaining > 0.0f &&
		FVector::DistSquared(LastMoveRequestDestination, Destination) <=
		FMath::Square(Controller ? FMath::Max(1.0f, Controller->PathDestinationChangeThreshold) : 25.0f))
	{
		const ACharacter* OwnerCharacter = Cast<ACharacter>(GetOwner());
		const AAIController* ExistingAI = OwnerCharacter ? Cast<AAIController>(OwnerCharacter->GetController()) : nullptr;
		if (ExistingAI && ExistingAI->GetMoveStatus() != EPathFollowingStatus::Idle) { return true; }
	}

	ACharacter* OwnerCharacter = Cast<ACharacter>(GetOwner());
	AAIController* AI = OwnerCharacter ? Cast<AAIController>(OwnerCharacter->GetController()) : nullptr;
	if (AI)
	{
		if (MoveRequestCooldownRemaining > 0.0f) { return false; }
		const EPathFollowingRequestResult::Type Result = AI->MoveToLocation(Destination,
			FMath::Max(1.0f, DestinationAcceptanceRadius >= 0.0f ? DestinationAcceptanceRadius : AcceptanceRadius),
			false, true, true, false, nullptr, true);
		if (Result == EPathFollowingRequestResult::Failed)
		{
			bHasLastMoveRequest = false;
			MoveRequestCooldownRemaining = NavigationFailureBackoff;
			NavigationFailureBackoff = FMath::Min(4.0f, NavigationFailureBackoff * 2.0f);
			return false;
		}
		NavigationFailureBackoff = 0.25f;
		LastMoveRequestDestination = Destination;
		bHasLastMoveRequest = true;
		MoveRequestCooldownRemaining = bOptimizePaths
			? (Controller ? FMath::Max(0.1f, Controller->MinimumPathRequestInterval) : 0.5f) : 0.0f;
		return true;
	}
	return false;
}

void UAVSNPCBehaviorComponent::UpdateWander()
{
	if (TimeUntilDecision > 0.0f)
	{
		return;
	}
	UNavigationSystemV1* Nav = FNavigationSystem::GetCurrent<UNavigationSystemV1>(GetWorld());
	FNavLocation Location;
	if (!Nav || !Nav->GetRandomReachablePointInRadius(WanderOrigin, WanderRadius, Location))
	{
		TimeUntilDecision = NavigationFailureBackoff;
		NavigationFailureBackoff = FMath::Min(4.0f, NavigationFailureBackoff * 2.0f);
		return;
	}
	if (!IssueMoveTo(Location.Location))
	{
		TimeUntilDecision = FMath::Max(0.25f, MoveRequestCooldownRemaining);
		return;
	}
	TimeUntilDecision = BehaviorRandom.FRandRange(3.0f, 8.0f);
}

void UAVSNPCBehaviorComponent::UpdateFollowActor()
{
	if (!FollowTarget.IsValid())
	{
		SetBehaviorState(EAVSNPCState::Idle);
		return;
	}
	if (TimeUntilDecision <= 0.0f)
	{
		TimeUntilDecision = IssueMoveTo(FollowTarget->GetActorTransform().TransformPosition(FollowOffset)) ? 0.5f : 0.1f;
	}
}

void UAVSNPCBehaviorComponent::UpdateRoute()
{
	if (!Route.IsValid() || Route->GetRoutePointCount() == 0)
	{
		SetBehaviorState(EAVSNPCState::Idle);
		return;
	}
	if (const UAVSCrowdSubsystem* Subsystem = GetWorld() ? GetWorld()->GetSubsystem<UAVSCrowdSubsystem>() : nullptr)
	{
		int32 SkippedPoints = 0;
		while (SkippedPoints < Route->GetRoutePointCount() &&
			Subsystem->IsLocationExcluded(GetRouteTarget(RoutePointIndex), false))
		{
			++RoutePointIndex;
			++SkippedPoints;
			if (RoutePointIndex >= Route->GetRoutePointCount())
			{
				if (bLoop)
				{
					RoutePointIndex = 0;
				}
				else
				{
					CompleteCurrentRoute();
					return;
				}
			}
		}
		if (SkippedPoints >= Route->GetRoutePointCount())
		{
			CompleteCurrentRoute();
			return;
		}
	}

	const FVector Target = GetRouteTarget(RoutePointIndex);
	if (FVector::DistSquared2D(GetOwner()->GetActorLocation(), Target) <= FMath::Square(AcceptanceRadius * 2.0f))
	{
		if (RouteTransferCooldown <= 0.0f)
		{
			AAVSCrowdRoute* TransferRoute = nullptr;
			int32 TransferPoint = INDEX_NONE;
			if (Route->TrySelectTransfer(Cast<AAVSArchvizNPCCharacter>(GetOwner()), RoutePointIndex,
				BehaviorRandom, TransferRoute, TransferPoint))
			{
				RouteTransferCooldown = 2.0f;
				const float NewOffset = FMath::Clamp(RouteLateralOffset, -TransferRoute->LaneHalfWidth, TransferRoute->LaneHalfWidth);
				FollowRouteWithOptions(TransferRoute, TransferRoute->bLoopRoute, RouteCompletionState, NewOffset, TransferPoint);
				return;
			}
		}
		++RoutePointIndex;
		if (RoutePointIndex >= Route->GetRoutePointCount())
		{
			if (bLoop)
			{
				RoutePointIndex = 0;
			}
			else
			{
				CompleteCurrentRoute();
				return;
			}
		}
	}
	if (TimeUntilDecision <= 0.0f)
	{
		TimeUntilDecision = IssueMoveTo(GetRouteTarget(RoutePointIndex)) ? 0.5f : 0.1f;
	}
}

FVector UAVSNPCBehaviorComponent::GetRouteTarget(int32 PointIndex) const
{
	return Route.IsValid()
		? Route->GetRoutePoint(PointIndex) + Route->GetRouteRightVector(PointIndex) * RouteLateralOffset
		: GetOwner()->GetActorLocation();
}

bool UAVSNPCBehaviorComponent::CompleteCurrentRoute()
{
	AAVSCrowdRoute* CompletedRoute = Route.Get();
	if (CompletedRoute)
	{
		DeferConversations(CompletedRoute->ConversationReengageDelayAfterExit);
	}
	if (CompletedRoute && CompletedRoute->HandleNPCReachedEnd(Cast<AAVSArchvizNPCCharacter>(GetOwner())))
	{
		Route.Reset();
		return true;
	}
	Route.Reset();
	SetBehaviorState(RouteCompletionState);
	return false;
}

void UAVSNPCBehaviorComponent::UpdatePointOfInterest(float DeltaTime)
{
	if (!PointOfInterest.IsValid())
	{
		SetBehaviorState(ReturnStateAfterPOI);
		return;
	}
	AAVSPointOfInterest* POI = PointOfInterest.Get();
	AAVSArchvizNPCCharacter* NPC = Cast<AAVSArchvizNPCCharacter>(GetOwner());
	if (!NPC || !NPC->AnimationDriver)
	{
		SetBehaviorState(ReturnStateAfterPOI);
		return;
	}
	if (bStartedPOIActivity)
	{
		if (!NPC->AnimationDriver->IsActivityPlaybackActive()) { SetBehaviorState(ReturnStateAfterPOI); }
		return;
	}
	POIElapsedTime += DeltaTime;
	if (POIElapsedTime >= static_cast<float>(AVS::Composed::Safe(POI->ArrivalTimeout, 30.0, 0.1, 86400.0)))
	{
		SetBehaviorState(ReturnStateAfterPOI);
		return;
	}
	const FVector Target = POI->GetUseLocation();
	const float VerticalTolerance = FMath::Max(FMath::Max(1.0f, POI->ArrivalDistanceTolerance), NPC->GetCapsuleComponent()->GetScaledCapsuleHalfHeight());
	if (FVector::DistSquared2D(GetOwner()->GetActorLocation(), Target) > FMath::Square(FMath::Max(1.0f, POI->ArrivalDistanceTolerance)) ||
		FMath::Abs(GetOwner()->GetActorLocation().Z - Target.Z) > VerticalTolerance)
	{
		POIAlignmentElapsedTime = 0.0f;
		if (TimeUntilDecision <= 0.0f)
		{
			TimeUntilDecision = IssueMoveTo(Target, POI->ArrivalDistanceTolerance) ? 0.5f : FMath::Max(0.25f, MoveRequestCooldownRemaining);
		}
		return;
	}
	if (AAIController* AI = Cast<AAIController>(NPC->GetController())) { AI->StopMovement(); }
	if (!bHasSavedFacingControl)
	{
		bSavedOrientRotationToMovement = NPC->GetCharacterMovement()->bOrientRotationToMovement;
		bHasSavedFacingControl = true;
		NPC->GetCharacterMovement()->bOrientRotationToMovement = false;
	}
	if (POI->bFacePOIDirection)
	{
		const float Yaw = POI->GetActorRotation().Yaw;
		if (FMath::Abs(FMath::FindDeltaAngleDegrees(GetOwner()->GetActorRotation().Yaw, Yaw)) > FMath::Max(0.1f, POI->ArrivalYawTolerance))
		{
			POIAlignmentElapsedTime += DeltaTime;
			GetOwner()->SetActorRotation(FMath::RInterpTo(GetOwner()->GetActorRotation(), FRotator(0.0f, Yaw, 0.0f), DeltaTime, FMath::Max(0.1f, POI->FacingInterpSpeed)));
			if (POIAlignmentElapsedTime >= static_cast<float>(AVS::Composed::Safe(POI->AlignmentTimeout, 6.0, 0.1, 86400.0))) { SetBehaviorState(ReturnStateAfterPOI); }
			return;
		}
	}
	// Wait for braking before entering contact animation; alignment never relocates the actor.
	if (NPC->GetVelocity().SizeSquared2D() > FMath::Square(5.0f)) { return; }
	USkeletalMeshComponent* Mesh = NPC->AnimationDriver->GetTargetMesh();
	const USkeleton* Skeleton = Mesh && Mesh->GetSkeletalMeshAsset() ? Mesh->GetSkeletalMeshAsset()->GetSkeleton() : nullptr;
	FAVSNamedAnimation Entry;
	if (!POI->ResolveRuntimeAnimation(NPC->AnimationDriver->AnimationProfile, Skeleton, BehaviorRandom, Entry))
	{
		SetBehaviorState(ReturnStateAfterPOI);
		return;
	}
	Entry.bLoop = POI->bLoopActivity;
	const float MinUse = static_cast<float>(AVS::Composed::Safe(POI->MinUseDuration, 5.0, 0.1, 86400.0));
	POITimeRemaining = BehaviorRandom.FRandRange(MinUse,
		static_cast<float>(AVS::Composed::Safe(POI->MaxUseDuration, MinUse, MinUse, 86400.0)));
	if (!NPC->AnimationDriver->PlayAnimationEntry(Entry, POI->ActivityAnimation,
		POI->bAutoLeaveAfterUse ? POITimeRemaining : -1.0f, POI->bUseSmartMissingTransitionFallback,
		POI->bAllowPoseHoldFallback, POI->HoldNormalizedPosition))
	{
		SetBehaviorState(ReturnStateAfterPOI);
		return;
	}
	bStartedPOIActivity = true;
}

void UAVSNPCBehaviorComponent::UpdateQueue()
{
	if (!PointOfInterest.IsValid())
	{
		SetBehaviorState(EAVSNPCState::Idle);
		return;
	}
	if (POIElapsedTime >= static_cast<float>(AVS::Composed::Safe(PointOfInterest->QueueTimeout, 60.0, 0.1, 86400.0)))
	{
		SetBehaviorState(ReturnStateAfterPOI);
		return;
	}
	const int32 QueueIndex = PointOfInterest->GetQueueIndex(GetOwner());
	if (QueueIndex == 0 && PointOfInterest->HasCapacity())
	{
		PointOfInterest->LeaveQueue(GetOwner());
		if (PointOfInterest->Reserve(GetOwner()))
		{
			POIElapsedTime = POIAlignmentElapsedTime = 0.0f;
			IssueMoveTo(PointOfInterest->GetUseLocation(), PointOfInterest->ArrivalDistanceTolerance);
			SetBehaviorState(EAVSNPCState::AtPointOfInterest);
			return;
		}
		PointOfInterest->JoinQueue(GetOwner());
	}
	const int32 CurrentIndex = PointOfInterest->GetQueueIndex(GetOwner());
	if (CurrentIndex >= 0 && TimeUntilDecision <= 0.0f)
	{
		const AAVSArchvizNPCCharacter* NPC = Cast<AAVSArchvizNPCCharacter>(GetOwner());
		const bool bMovementPending = NPC && NPC->AnimationDriver && NPC->AnimationDriver->IsMovementTemporarilyLocked();
		if (!IssueMoveTo(PointOfInterest->GetQueueLocation(CurrentIndex)) && !bMovementPending)
		{
			TimeUntilDecision = FMath::Max(0.25f, MoveRequestCooldownRemaining);
			return;
		}
		TimeUntilDecision = 0.5f;
	}
}
