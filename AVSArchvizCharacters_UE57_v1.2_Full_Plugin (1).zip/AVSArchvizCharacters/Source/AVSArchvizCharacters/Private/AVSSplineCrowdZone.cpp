#include "AVSSplineCrowdZone.h"

#include "AVSArchvizNPCCharacter.h"
#include "AVSCrowdRoute.h"
#include "AVSNPCBehaviorComponent.h"
#include "Components/SplineComponent.h"
#include "DrawDebugHelpers.h"
#include "EngineUtils.h"
#include "NavigationSystem.h"

AAVSSplineCrowdZone::AAVSSplineCrowdZone()
{
	SurfaceSpline = CreateDefaultSubobject<USplineComponent>(TEXT("SurfaceSpline"));
	SurfaceSpline->SetupAttachment(SceneRoot);
	SurfaceSpline->SetClosedLoop(true);
	NPCCount = 20;
}

void AAVSSplineCrowdZone::BeginPlay()
{
	Super::BeginPlay();
	RefreshContainedRoutes();
}

void AAVSSplineCrowdZone::GetSurfacePolygon(TArray<FVector>& OutPoints) const
{
	OutPoints.Reset();
	if (!SurfaceSpline)
	{
		return;
	}
	const float Length = SurfaceSpline->GetSplineLength();
	if (Length <= KINDA_SMALL_NUMBER)
	{
		return;
	}
	const int32 SampleCount = FMath::Max(3, FMath::CeilToInt(Length / FMath::Max(50.0f, SurfaceSampleSpacing)));
	OutPoints.Reserve(SampleCount);
	for (int32 Index = 0; Index < SampleCount; ++Index)
	{
		const float Distance = Length * static_cast<float>(Index) / static_cast<float>(SampleCount);
		OutPoints.Add(SurfaceSpline->GetLocationAtDistanceAlongSpline(Distance, ESplineCoordinateSpace::World));
	}
}

bool AAVSSplineCrowdZone::ContainsWorldLocation(const FVector& Location) const
{
	TArray<FVector> Polygon;
	GetSurfacePolygon(Polygon);
	if (Polygon.Num() < 3)
	{
		return false;
	}

	bool bInside = false;
	for (int32 Index = 0, Previous = Polygon.Num() - 1; Index < Polygon.Num(); Previous = Index++)
	{
		const FVector& A = Polygon[Index];
		const FVector& B = Polygon[Previous];
		const bool bCrosses = ((A.Y > Location.Y) != (B.Y > Location.Y)) &&
			(Location.X < (B.X - A.X) * (Location.Y - A.Y) / (B.Y - A.Y + UE_SMALL_NUMBER) + A.X);
		if (bCrosses)
		{
			bInside = !bInside;
		}
	}
	return bInside;
}

void AAVSSplineCrowdZone::RefreshContainedRoutes()
{
	CachedRouteChoices.Reset();
	for (const FAVSZoneRouteChoice& Choice : RouteChoices)
	{
		if (IsValid(Choice.Route) && Choice.Weight > 0.0f)
		{
			CachedRouteChoices.Add(Choice);
		}
	}

	if (!bAutoDiscoverContainedRoutes || !GetWorld())
	{
		return;
	}

	for (TActorIterator<AAVSCrowdRoute> It(GetWorld()); It; ++It)
	{
		AAVSCrowdRoute* Candidate = *It;
		const bool bAlreadyListed = CachedRouteChoices.ContainsByPredicate(
			[Candidate](const FAVSZoneRouteChoice& Choice) { return Choice.Route == Candidate; });
		if (!Candidate || bAlreadyListed || !Candidate->CanConnectCrowdZones())
		{
			continue;
		}
		const float RouteLength = Candidate->RouteSpline ? Candidate->RouteSpline->GetSplineLength() : 0.0f;
		const int32 SampleCount = FMath::Max(1, FMath::CeilToInt(RouteLength / FMath::Max(25.0f, RouteDetectionSampleSpacing)));
		for (int32 PointIndex = 0; PointIndex <= SampleCount; ++PointIndex)
		{
			const float Distance = RouteLength * static_cast<float>(PointIndex) / static_cast<float>(SampleCount);
			const FVector Sample = Candidate->RouteSpline->GetLocationAtDistanceAlongSpline(Distance, ESplineCoordinateSpace::World);
			if (ContainsWorldLocation(Sample))
			{
				FAVSZoneRouteChoice Choice;
				Choice.Route = Candidate;
				Choice.Weight = 1.0f;
				Choice.bLoop = Candidate->bLoopRoute;
				CachedRouteChoices.Add(Choice);
				break;
			}
		}
	}
}

const FAVSZoneRouteChoice* AAVSSplineCrowdZone::SelectRouteChoice(const AAVSArchvizNPCCharacter* NPC)
{
	float TotalWeight = 0.0f;
	const FAVSZoneRouteChoice* LastValid = nullptr;
	for (const FAVSZoneRouteChoice& Choice : CachedRouteChoices)
	{
		if (IsValid(Choice.Route) && Choice.Weight > 0.0f && NPC &&
			Choice.Route->SupportsProfiles(NPC->DefaultCharacterProfile, NPC->DefaultAnimationProfile))
		{
			TotalWeight += Choice.Weight;
			LastValid = &Choice;
		}
	}
	if (TotalWeight <= 0.0f)
	{
		return nullptr;
	}

	float Pick = RandomStream.FRandRange(0.0f, TotalWeight);
	for (const FAVSZoneRouteChoice& Choice : CachedRouteChoices)
	{
		if (!IsValid(Choice.Route) || Choice.Weight <= 0.0f || !NPC ||
			!Choice.Route->SupportsProfiles(NPC->DefaultCharacterProfile, NPC->DefaultAnimationProfile))
		{
			continue;
		}
		Pick -= Choice.Weight;
		if (Pick <= 0.0f)
		{
			return &Choice;
		}
	}
	return LastValid;
}

bool AAVSSplineCrowdZone::MakeSpawnTransform(int32 NPCIndex, FTransform& OutTransform)
{
	TArray<FVector> Polygon;
	GetSurfacePolygon(Polygon);
	if (Polygon.Num() < 3)
	{
		return false;
	}

	FBox Bounds(ForceInit);
	float AverageZ = 0.0f;
	for (const FVector& Point : Polygon)
	{
		Bounds += Point;
		AverageZ += Point.Z;
	}
	AverageZ /= static_cast<float>(Polygon.Num());

	for (int32 Attempt = 0; Attempt < MaxSpawnAttemptsPerNPC; ++Attempt)
	{
		FVector WorldPoint(
			RandomStream.FRandRange(Bounds.Min.X, Bounds.Max.X),
			RandomStream.FRandRange(Bounds.Min.Y, Bounds.Max.Y),
			AverageZ);
		if (!ContainsWorldLocation(WorldPoint))
		{
			continue;
		}
		if (bProjectToNavMesh)
		{
			UNavigationSystemV1* Nav = FNavigationSystem::GetCurrent<UNavigationSystemV1>(GetWorld());
			FNavLocation Projected;
			if (!Nav || !Nav->ProjectPointToNavigation(WorldPoint, Projected, NavProjectionExtent) || !ContainsWorldLocation(Projected.Location))
			{
				continue;
			}
			WorldPoint = Projected.Location;
		}
		OutTransform = FTransform(FRotator(0.0f, RandomStream.FRandRange(-180.0f, 180.0f), 0.0f), WorldPoint);
		return true;
	}
	return false;
}

void AAVSSplineCrowdZone::ConfigureSpawnedNPC(AAVSArchvizNPCCharacter* NPC, int32 NPCIndex)
{
	if (!NPC || !NPC->Behavior)
	{
		return;
	}
	NPC->Behavior->SetWanderArea(NPC->GetActorLocation(), WanderRadius);
	if (RandomStream.FRand() < FMath::Clamp(RouteDecisionChance, 0.0f, 1.0f))
	{
		if (const FAVSZoneRouteChoice* Choice = SelectRouteChoice(NPC))
		{
			NPC->Behavior->FollowRouteWithCompletion(Choice->Route, Choice->bLoop, EAVSNPCState::Wander);
			return;
		}
	}
	if (RandomStream.FRandRange(0.0f, 100.0f) >= FMath::Clamp(IdlePercentageWeight, 0.0f, 100.0f))
	{
		NPC->Behavior->StartWandering(NPC->GetActorLocation(), WanderRadius);
	}
	else
	{
		NPC->Behavior->SetBehaviorState(EAVSNPCState::Idle);
	}
}

void AAVSSplineCrowdZone::AcceptConnectorArrival(AAVSArchvizNPCCharacter* NPC)
{
	if (NPC && NPC->Behavior)
	{
		NPC->Behavior->StartWandering(NPC->GetActorLocation(), WanderRadius);
	}
}

void AAVSSplineCrowdZone::DrawGeneratorDebug(const FAVSViewerState& ViewerState) const
{
	Super::DrawGeneratorDebug(ViewerState);
	TArray<FVector> Polygon;
	GetSurfacePolygon(Polygon);
	for (int32 Index = 0; Index < Polygon.Num(); ++Index)
	{
		DrawDebugLine(GetWorld(), Polygon[Index], Polygon[(Index + 1) % Polygon.Num()], FColor::Green, false, 0.6f, 0, 5.0f);
	}
}
