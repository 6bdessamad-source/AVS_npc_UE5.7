#include "AVSArchvizCrowdComponent.h"

#include "AVSCrowdSubsystem.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/PlayerController.h"
#include "Kismet/GameplayStatics.h"
#include "UObject/UnrealType.h"

UAVSArchvizCrowdComponent::UAVSArchvizCrowdComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.TickInterval = 0.1f;
}

void UAVSArchvizCrowdComponent::BeginPlay()
{
	Super::BeginPlay();
	if (UAVSCrowdSubsystem* Subsystem = GetWorld()->GetSubsystem<UAVSCrowdSubsystem>())
	{
		Subsystem->RegisterViewer(this);
	}
	RefreshFromOwner();
	RefreshActivationState();
	BroadcastIfChanged();
}

void UAVSArchvizCrowdComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (GetWorld())
	{
		if (UAVSCrowdSubsystem* Subsystem = GetWorld()->GetSubsystem<UAVSCrowdSubsystem>())
		{
			Subsystem->UnregisterViewer(this);
		}
	}
	Super::EndPlay(EndPlayReason);
}

void UAVSArchvizCrowdComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	RefreshFromOwner();
	RefreshActivationState();
	BroadcastIfChanged();
}

void UAVSArchvizCrowdComponent::SetViewerMode(EAVSViewerMode NewMode)
{
	ViewerMode = NewMode;
	RefreshActivationState();
	BroadcastIfChanged();
}

void UAVSArchvizCrowdComponent::SetOrbitZoom(float NewZoom)
{
	OrbitZoom = FMath::Max(0.0f, NewZoom);
	RefreshActivationState();
	BroadcastIfChanged();
}

void UAVSArchvizCrowdComponent::SetCrowdEnabled(bool bEnabled)
{
	bCrowdEnabled = bEnabled;
	BroadcastIfChanged();
}

void UAVSArchvizCrowdComponent::RefreshFromOwner()
{
	if (!bReadOwnerProperties || !GetOwner())
	{
		return;
	}
	double ModeValue = 0.0;
	if (ReadNumericProperty(GetOwner(), ModePropertyName, ModeValue))
	{
		const int64 IntegralMode = static_cast<int64>(ModeValue);
		if (IntegralMode == WalkingEnumValue)
		{
			ViewerMode = EAVSViewerMode::Walking;
		}
		else if (IntegralMode == OrbitingEnumValue)
		{
			ViewerMode = EAVSViewerMode::Orbiting;
		}
	}
	double ZoomValue = 0.0;
	if (ReadNumericProperty(GetOwner(), ZoomPropertyName, ZoomValue))
	{
		OrbitZoom = static_cast<float>(FMath::Max(0.0, ZoomValue));
	}
}

bool UAVSArchvizCrowdComponent::ReadNumericProperty(const UObject* Object, FName PropertyName, double& OutValue) const
{
	if (!Object || PropertyName.IsNone())
	{
		return false;
	}
	const FProperty* Property = Object->GetClass()->FindPropertyByName(PropertyName);
	if (!Property)
	{
		return false;
	}
	const void* Address = Property->ContainerPtrToValuePtr<void>(Object);
	if (const FFloatProperty* FloatProperty = CastField<FFloatProperty>(Property))
	{
		OutValue = FloatProperty->GetPropertyValue(Address);
		return true;
	}
	if (const FDoubleProperty* DoubleProperty = CastField<FDoubleProperty>(Property))
	{
		OutValue = DoubleProperty->GetPropertyValue(Address);
		return true;
	}
	if (const FEnumProperty* EnumProperty = CastField<FEnumProperty>(Property))
	{
		OutValue = static_cast<double>(EnumProperty->GetUnderlyingProperty()->GetSignedIntPropertyValue(Address));
		return true;
	}
	if (const FByteProperty* ByteProperty = CastField<FByteProperty>(Property))
	{
		OutValue = static_cast<double>(ByteProperty->GetPropertyValue(Address));
		return true;
	}
	if (const FIntProperty* IntProperty = CastField<FIntProperty>(Property))
	{
		OutValue = static_cast<double>(IntProperty->GetPropertyValue(Address));
		return true;
	}
	return false;
}

void UAVSArchvizCrowdComponent::RefreshActivationState()
{
	if (ViewerMode == EAVSViewerMode::Walking)
	{
		bZoomAllowsCrowd = true;
		return;
	}
	if (bZoomAllowsCrowd)
	{
		if (OrbitZoom > OrbitDeactivationZoom)
		{
			bZoomAllowsCrowd = false;
		}
	}
	else if (OrbitZoom < OrbitActivationZoom)
	{
		bZoomAllowsCrowd = true;
	}
}

FAVSViewerState UAVSArchvizCrowdComponent::GetCurrentViewerState() const
{
	FAVSViewerState Result;
	Result.Mode = ViewerMode;
	Result.OrbitZoom = OrbitZoom;
	Result.bCrowdEnabled = bCrowdEnabled && bZoomAllowsCrowd;
	Result.ViewLocation = GetOwner() ? GetOwner()->GetActorLocation() : FVector::ZeroVector;
	Result.ViewDirection = GetOwner() ? GetOwner()->GetActorForwardVector() : FVector::ForwardVector;

	if (GetWorld())
	{
		if (const APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0))
		{
			FVector CameraLocation;
			FRotator CameraRotation;
			PC->GetPlayerViewPoint(CameraLocation, CameraRotation);
			Result.ViewLocation = CameraLocation;
			Result.ViewDirection = CameraRotation.Vector();
		}
	}
	return Result;
}

bool UAVSArchvizCrowdComponent::GetAVSViewerState_Implementation(FAVSViewerState& OutState) const
{
	OutState = GetCurrentViewerState();
	return true;
}

void UAVSArchvizCrowdComponent::BroadcastIfChanged()
{
	const FAVSViewerState Current = GetCurrentViewerState();
	const bool bChanged = !bHasBroadcastState || Current.Mode != LastBroadcastState.Mode ||
		!FMath::IsNearlyEqual(Current.OrbitZoom, LastBroadcastState.OrbitZoom, 1.0f) ||
		Current.bCrowdEnabled != LastBroadcastState.bCrowdEnabled ||
		!Current.ViewLocation.Equals(LastBroadcastState.ViewLocation, 10.0f);
	if (bChanged)
	{
		LastBroadcastState = Current;
		bHasBroadcastState = true;
		OnViewerStateChanged.Broadcast(Current);
	}
}
