#include "AVSAnimationProfile.h"

#include "AVSArchvizCharacters.h"
#include "AVSCharacterProfile.h"
#include "AVSResolvedAnimation.h"
#include "Animation/AnimSequenceBase.h"
#include "Animation/Skeleton.h"

UAnimSequenceBase* UAVSAnimationProfile::ResolveAnimation(EAVSAnimationSlot Slot, FName CustomName) const
{
	const USkeleton* RequiredSkeleton = TargetSkeleton.LoadSynchronous();
	for (const FAVSNamedAnimation& Entry : Animations)
	{
		if (Entry.Slot == Slot && (Slot != EAVSAnimationSlot::Custom || Entry.CustomName == CustomName))
		{
			UAnimSequenceBase* Animation = Entry.Animation.LoadSynchronous();
			if (Animation && (!RequiredSkeleton || Animation->GetSkeleton() == RequiredSkeleton))
			{
				return Animation;
			}
		}
	}
	return nullptr;
}

bool UAVSAnimationProfile::HasCompatibleEntryForSkeleton(const FAVSNamedAnimation& Entry, const USkeleton* Skeleton) const
{
	return AVSResolveAnimation(this, Entry, Skeleton).Plan.Valid;
}

bool UAVSAnimationProfile::HasAnimation(EAVSAnimationSlot Slot, FName CustomName) const
{
	return HasCompatibleAnimationForSkeleton(Slot, TargetSkeleton.LoadSynchronous(), CustomName);
}

int32 UAVSAnimationProfile::GetVariantCount(EAVSAnimationSlot Slot, FName CustomName) const
{
	int32 Count = 0;
	const USkeleton* Skeleton = TargetSkeleton.LoadSynchronous();
	for (const FAVSNamedAnimation& Entry : Animations)
		if (Entry.Slot == Slot && (Slot != EAVSAnimationSlot::Custom || Entry.CustomName == CustomName) &&
			FMath::IsFinite(Entry.SelectionWeight) && Entry.SelectionWeight > 0 && HasCompatibleEntryForSkeleton(Entry, Skeleton)) ++Count;
	return Count;
}

bool UAVSAnimationProfile::HasCompatibleAnimationForSkeleton(EAVSAnimationSlot Slot, const USkeleton* Skeleton, FName CustomName) const
{
	for (const FAVSNamedAnimation& Entry : Animations)
		if (Entry.Slot == Slot && (Slot != EAVSAnimationSlot::Custom || Entry.CustomName == CustomName) &&
			FMath::IsFinite(Entry.SelectionWeight) && Entry.SelectionWeight > 0 && HasCompatibleEntryForSkeleton(Entry, Skeleton)) return true;
	return false;
}

bool UAVSAnimationProfile::SelectAnimationVariant(EAVSAnimationSlot Slot, FName CustomName, FRandomStream& Stream,
	int32 AvoidIndex, FAVSNamedAnimation& OutEntry, int32& OutIndex) const
{
	return SelectCompatibleAnimationVariant(Slot, CustomName, TargetSkeleton.LoadSynchronous(), Stream, AvoidIndex, OutEntry, OutIndex);
}

bool UAVSAnimationProfile::SelectCompatibleAnimationVariant(EAVSAnimationSlot Slot, FName CustomName, const USkeleton* Skeleton,
	FRandomStream& Stream, int32 AvoidIndex, FAVSNamedAnimation& OutEntry, int32& OutIndex) const
{
	TArray<int32> Candidates;
	double TotalWeight = 0.0;
	for (int32 Index = 0; Index < Animations.Num(); ++Index)
	{
		const FAVSNamedAnimation& Entry = Animations[Index];
		if (Entry.Slot == Slot && (Slot != EAVSAnimationSlot::Custom || Entry.CustomName == CustomName) &&
			FMath::IsFinite(Entry.SelectionWeight) && Entry.SelectionWeight > 0 && HasCompatibleEntryForSkeleton(Entry, Skeleton))
			Candidates.Add(Index);
	}
	if (Candidates.Num() > 1) Candidates.Remove(AvoidIndex);
	for (int32 Index : Candidates) TotalWeight += Animations[Index].SelectionWeight;
	if (Candidates.IsEmpty() || TotalWeight <= 0) return false;
	double Choice = Stream.FRand() * TotalWeight;
	int32 Selected = Candidates.Last();
	for (int32 Index : Candidates)
	{
		Choice -= Animations[Index].SelectionWeight;
		if (Choice < 0) { Selected = Index; break; }
	}
	OutEntry = Animations[Selected]; OutIndex = Selected;
	return true;
}

bool UAVSAnimationProfile::IsCompatibleWithCharacter(const UAVSCharacterProfile* CharacterProfile) const
{
	if (!CharacterProfile || !AVSIsSexCompatible(CharacterProfile->Sex, CompatibleSex))
	{
		return false;
	}
	if (!RigId.IsNone() && !CharacterProfile->RigId.IsNone() && RigId != CharacterProfile->RigId)
	{
		return false;
	}

	USkeleton* CharacterSkeleton = CharacterProfile->ResolveAnimationSkeleton();
	USkeleton* AnimationSkeleton = TargetSkeleton.LoadSynchronous();
	return CharacterSkeleton && AnimationSkeleton && CharacterSkeleton == AnimationSkeleton &&
		HasAnimation(EAVSAnimationSlot::Idle) && HasAnimation(EAVSAnimationSlot::Walk);
}

void UAVSAnimationProfile::ValidateAndLog() const
{
	TArray<FText> Issues;
	if (ValidateProfile(Issues))
	{
		UE_LOG(LogAVSArchvizCharacters, Display, TEXT("Animation Profile '%s' is valid."), *GetName());
		return;
	}
	for (const FText& Issue : Issues)
	{
		UE_LOG(LogAVSArchvizCharacters, Warning, TEXT("Animation Profile '%s': %s"), *GetName(), *Issue.ToString());
	}
}

bool UAVSAnimationProfile::ValidateProfile(TArray<FText>& OutIssues) const
{
	OutIssues.Reset();
	USkeleton* RequiredSkeleton = TargetSkeleton.LoadSynchronous();
	if (!RequiredSkeleton)
	{
		OutIssues.Add(NSLOCTEXT("AVS", "MissingTargetSkeleton", "Animation Profile has no Target Skeleton."));
	}

	for (const FAVSNamedAnimation& Entry : Animations)
	{
		const FString Key = Entry.Slot == EAVSAnimationSlot::Custom
			? FString::Printf(TEXT("Custom:%s"), *Entry.CustomName.ToString())
			: UEnum::GetValueAsString(Entry.Slot);
		UAnimSequenceBase* Animation = Entry.Animation.LoadSynchronous();
		if (!HasCompatibleEntryForSkeleton(Entry, RequiredSkeleton))
		{
			OutIssues.Add(FText::FromString(FString::Printf(TEXT("Animation slot '%s' cannot resolve a compatible loop or safe hold/exit. Check clips, Skeleton and fallback permissions."), *Key)));
		}
		if (Animation && RequiredSkeleton && Animation->GetSkeleton() != RequiredSkeleton)
		{
			OutIssues.Add(FText::FromString(FString::Printf(TEXT("Animation slot '%s' uses another Skeleton and must be retargeted."), *Key)));
		}
		if (UAnimSequenceBase* StartAnimation = Entry.StartAnimation.LoadSynchronous())
		{
			if (RequiredSkeleton && StartAnimation->GetSkeleton() != RequiredSkeleton)
			{
				OutIssues.Add(FText::FromString(FString::Printf(TEXT("Start animation for slot '%s' uses another Skeleton."), *Key)));
			}
		}
		if (UAnimSequenceBase* EndAnimation = Entry.EndAnimation.LoadSynchronous())
		{
			if (RequiredSkeleton && EndAnimation->GetSkeleton() != RequiredSkeleton)
			{
				OutIssues.Add(FText::FromString(FString::Printf(TEXT("End animation for slot '%s' uses another Skeleton."), *Key)));
			}
		}
	}
	if (!HasAnimation(EAVSAnimationSlot::Idle))
	{
		OutIssues.Add(NSLOCTEXT("AVS", "MissingIdleAnimation", "Animation Profile has no Idle animation."));
	}
	if (!HasAnimation(EAVSAnimationSlot::Walk))
	{
		OutIssues.Add(NSLOCTEXT("AVS", "MissingLocomotionAnimation", "Animation Profile has no Walk animation. Normal NPC movement will be blocked to prevent sliding in a stationary pose."));
	}
	return OutIssues.IsEmpty();
}
