#include "AVSCrowdSubsystem.h"

#include "AVSArchvizCharacters.h"
#include "AVSActivityProbability.h"
#include "AVSComposedAnimationPolicy.h"
#include "AVSCrowdZone.h"
#include "AVSSplineCrowdZone.h"
#include "AVSArchvizCrowdComponent.h"
#include "AVSArchvizNPCCharacter.h"
#include "AVSArchvizSettings.h"
#include "AVSCrowdExclusionMask.h"
#include "AVSCrowdGenerator.h"
#include "AVSCrowdGlobalController.h"
#include "AVSCrowdRoute.h"
#include "AVSNavigationInvokerAnchor.h"
#include "AVSNPCBehaviorComponent.h"
#include "Engine/World.h"

void UAVSCrowdSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	SocialRandom.Initialize(GetWorld() ? GetTypeHash(GetWorld()->GetFName()) ^ 0x51A7C0DE : 1337);
}

void UAVSCrowdSubsystem::Deinitialize()
{
	DestroyViewerNavigationInvoker();
	for (AAVSArchvizNPCCharacter* NPC : ActiveNPCs)
	{
		if (IsValid(NPC))
		{
			NPC->Destroy();
		}
	}
	for (AAVSArchvizNPCCharacter* NPC : PooledNPCs)
	{
		if (IsValid(NPC))
		{
			NPC->Destroy();
		}
	}
	ActiveNPCs.Reset();
	PooledNPCs.Reset();
	Viewers.Reset();
	Generators.Reset();
	ExclusionMasks.Reset();
	RegisteredNPCs.Reset();
	GlobalController.Reset();
	ZoneConversationEvaluationTimes.Reset();
	Super::Deinitialize();
}

bool UAVSCrowdSubsystem::DoesSupportWorldType(EWorldType::Type WorldType) const
{
	return WorldType == EWorldType::Game || WorldType == EWorldType::PIE || WorldType == EWorldType::GamePreview;
}

TStatId UAVSCrowdSubsystem::GetStatId() const
{
	RETURN_QUICK_DECLARE_CYCLE_STAT(UAVSCrowdSubsystem, STATGROUP_Tickables);
}

void UAVSCrowdSubsystem::Tick(float DeltaTime)
{
	UpdateProximityConversations();
	TimeUntilEvaluation -= DeltaTime;
	if (TimeUntilEvaluation > 0.0f)
	{
		return;
	}
	const UAVSArchvizSettings* Settings = GetDefault<UAVSArchvizSettings>();
	TimeUntilEvaluation = GlobalController.IsValid()
		? FMath::Max(0.05f, GlobalController->EvaluationInterval)
		: (Settings ? Settings->EvaluationInterval : 0.5f);
	CompactReferences();
	while (ActiveNPCs.Num() > GetEffectiveMaxActiveNPCs())
	{
		ReleaseNPC(ActiveNPCs.Last());
	}
	while (PooledNPCs.Num() > GetEffectiveWarmPoolSize())
	{
		if (AAVSArchvizNPCCharacter* NPC = PooledNPCs.Pop())
		{
			NPC->Destroy();
		}
	}

	FAVSViewerState ViewerState;
	if (!GetPrimaryViewerState(ViewerState))
	{
		DestroyViewerNavigationInvoker();
		return;
	}
	if (GlobalController.IsValid())
	{
		ViewerState.bCrowdEnabled = ViewerState.bCrowdEnabled && GlobalController->bCrowdEnabled;
	}
	UpdateViewerNavigationInvoker(ViewerState);
	for (const TWeakObjectPtr<AAVSCrowdGenerator>& Generator : Generators)
	{
		if (Generator.IsValid())
		{
			Generator->UpdateForViewer(ViewerState);
		}
	}
	ApplyQualityTiers(ViewerState);
}

void UAVSCrowdSubsystem::UpdateViewerNavigationInvoker(const FAVSViewerState& ViewerState)
{
	AAVSCrowdGlobalController* Controller = GlobalController.Get();
	if (!Controller || !Controller->bEnableViewerNavigationInvoker || !ViewerState.bCrowdEnabled)
	{
		DestroyViewerNavigationInvoker();
		return;
	}

	const float GenerationRadius = ViewerState.Mode == EAVSViewerMode::Orbiting
		? Controller->OrbitNavigationGenerationRadius
		: Controller->WalkingNavigationGenerationRadius;
	const float SafeGenerationRadius = FMath::Max(500.0f, GenerationRadius);
	const float RemovalRadius = SafeGenerationRadius +
		FMath::Max(100.0f, Controller->NavigationRemovalRadiusPadding);

	if (!IsValid(ViewerNavigationInvoker))
	{
		FActorSpawnParameters Parameters;
		Parameters.ObjectFlags |= RF_Transient;
		Parameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		ViewerNavigationInvoker = GetWorld()->SpawnActor<AAVSNavigationInvokerAnchor>(
			AAVSNavigationInvokerAnchor::StaticClass(),
			ViewerState.ViewLocation,
			FRotator::ZeroRotator,
			Parameters);
		if (ViewerNavigationInvoker)
		{
			ViewerNavigationInvoker->SetActorHiddenInGame(true);
			ViewerNavigationInvoker->ConfigureRadii(SafeGenerationRadius, RemovalRadius);
			UE_LOG(LogAVSArchvizCharacters, Display,
				TEXT("AVS local navigation invoker enabled. Project Settings must use Runtime Generation = Dynamic and Generate Navigation Only Around Navigation Invokers."));
		}
		return;
	}

	ViewerNavigationInvoker->ConfigureRadii(SafeGenerationRadius, RemovalRadius);
	const float MoveThreshold = FMath::Max(0.0f, Controller->NavigationInvokerMoveThreshold);
	if (FVector::DistSquared2D(ViewerNavigationInvoker->GetActorLocation(), ViewerState.ViewLocation) >=
		FMath::Square(MoveThreshold))
	{
		ViewerNavigationInvoker->SetActorLocation(ViewerState.ViewLocation, false, nullptr, ETeleportType::TeleportPhysics);
	}
}

void UAVSCrowdSubsystem::DestroyViewerNavigationInvoker()
{
	if (IsValid(ViewerNavigationInvoker))
	{
		ViewerNavigationInvoker->Destroy();
	}
	ViewerNavigationInvoker = nullptr;
}

void UAVSCrowdSubsystem::RegisterViewer(UAVSArchvizCrowdComponent* Viewer)
{
	if (Viewer && !Viewers.Contains(Viewer))
	{
		Viewers.Add(Viewer);
	}
}

void UAVSCrowdSubsystem::UnregisterViewer(UAVSArchvizCrowdComponent* Viewer)
{
	Viewers.Remove(Viewer);
}

void UAVSCrowdSubsystem::RegisterGenerator(AAVSCrowdGenerator* Generator)
{
	if (Generator && !Generators.Contains(Generator))
	{
		Generators.Add(Generator);
	}
}

void UAVSCrowdSubsystem::UnregisterGenerator(AAVSCrowdGenerator* Generator)
{
	Generators.Remove(Generator);
	ReleaseNPCsOwnedBy(Generator);
}

void UAVSCrowdSubsystem::RegisterExclusionMask(AAVSCrowdExclusionMask* Mask)
{
	if (Mask && !ExclusionMasks.Contains(Mask))
	{
		ExclusionMasks.Add(Mask);
	}
}

void UAVSCrowdSubsystem::UnregisterExclusionMask(AAVSCrowdExclusionMask* Mask)
{
	ExclusionMasks.Remove(Mask);
}

void UAVSCrowdSubsystem::RegisterGlobalController(AAVSCrowdGlobalController* Controller)
{
	if (Controller)
	{
		GlobalController = Controller;
	}
}

void UAVSCrowdSubsystem::UnregisterGlobalController(AAVSCrowdGlobalController* Controller)
{
	if (GlobalController.Get() == Controller)
	{
		GlobalController.Reset();
	}
}

void UAVSCrowdSubsystem::RegisterNPC(AAVSArchvizNPCCharacter* NPC)
{
	if (NPC && !RegisteredNPCs.Contains(NPC))
	{
		RegisteredNPCs.Add(NPC);
	}
}

void UAVSCrowdSubsystem::UnregisterNPC(AAVSArchvizNPCCharacter* NPC)
{
	RegisteredNPCs.Remove(NPC);
}

AAVSArchvizNPCCharacter* UAVSCrowdSubsystem::AcquireNPC(TSubclassOf<AAVSArchvizNPCCharacter> NPCClass, const FAVSSpawnRequest& Request)
{
	if (!NPCClass)
	{
		NPCClass = AAVSArchvizNPCCharacter::StaticClass();
	}
	if (Request.Transform.ContainsNaN() || IsLocationExcluded(Request.Transform.GetLocation(), true) ||
		ActiveNPCs.Num() >= GetEffectiveMaxActiveNPCs())
	{
		return nullptr;
	}

	AAVSArchvizNPCCharacter* NPC = nullptr;
	for (int32 Index = PooledNPCs.Num() - 1; Index >= 0; --Index)
	{
		AAVSArchvizNPCCharacter* Candidate = PooledNPCs[Index];
		if (IsValid(Candidate) && Candidate->IsA(NPCClass))
		{
			NPC = Candidate;
			PooledNPCs.RemoveAtSwap(Index);
			break;
		}
	}
	if (!NPC)
	{
		NPC = GetWorld()->SpawnActorDeferred<AAVSArchvizNPCCharacter>(NPCClass, Request.Transform, Request.Generator,
			nullptr, ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn);
		if (NPC)
		{
			NPC->SetActorHiddenInGame(true);
			NPC->FinishSpawning(Request.Transform);
		}
	}
	if (NPC)
	{
		NPC->InitializeNPC(Request);
		if (NPC->IsHidden())
		{
			// Profile/mesh validation failed; keep it reusable without counting it active.
			ReleaseNPC(NPC);
			return nullptr;
		}
		ActiveNPCs.AddUnique(NPC);
	}
	return NPC;
}

void UAVSCrowdSubsystem::ReleaseNPC(AAVSArchvizNPCCharacter* NPC)
{
	if (!IsValid(NPC) || PooledNPCs.Contains(NPC))
	{
		return;
	}
	ActiveNPCs.Remove(NPC);
	NPC->SetPooled(true);
	if (PooledNPCs.Num() < GetEffectiveWarmPoolSize())
	{
		PooledNPCs.AddUnique(NPC);
	}
	else
	{
		NPC->Destroy();
	}
}

void UAVSCrowdSubsystem::ClearAllGeneratedCrowds()
{
	for (const TWeakObjectPtr<AAVSCrowdGenerator>& Generator : Generators)
	{
		if (Generator.IsValid())
		{
			Generator->ClearGeneratedNPCs();
		}
	}
}

bool UAVSCrowdSubsystem::IsLocationExcluded(const FVector& WorldLocation, bool bForSpawning) const
{
	for (const TWeakObjectPtr<AAVSCrowdExclusionMask>& Mask : ExclusionMasks)
	{
		if (Mask.IsValid() && (bForSpawning ? Mask->bBlockSpawning : Mask->bBlockMovementDestinations) &&
			Mask->ContainsWorldLocation(WorldLocation))
		{
			return true;
		}
	}
	return false;
}

float UAVSCrowdSubsystem::GetDensityScale() const
{
	return GlobalController.IsValid() ? FMath::Max(0.0f, GlobalController->DensityScale) : 1.0f;
}

int32 UAVSCrowdSubsystem::GetEffectiveMaxActiveNPCs() const
{
	if (GlobalController.IsValid())
	{
		return FMath::Max(1, GlobalController->MaxActiveNPCs);
	}
	const UAVSArchvizSettings* Settings = GetDefault<UAVSArchvizSettings>();
	return Settings ? FMath::Max(1, Settings->MaxActiveNPCs) : 100;
}

int32 UAVSCrowdSubsystem::GetEffectiveWarmPoolSize() const
{
	if (GlobalController.IsValid())
	{
		return FMath::Max(0, GlobalController->WarmPoolSize);
	}
	const UAVSArchvizSettings* Settings = GetDefault<UAVSArchvizSettings>();
	return Settings ? FMath::Max(0, Settings->WarmPoolSize) : 10;
}

void UAVSCrowdSubsystem::ReleaseNPCsOwnedBy(AActor* Generator)
{
	for (int32 Index = ActiveNPCs.Num() - 1; Index >= 0; --Index)
	{
		AAVSArchvizNPCCharacter* NPC = ActiveNPCs[Index];
		if (IsValid(NPC) && NPC->GetOwningGenerator() == Generator)
		{
			ReleaseNPC(NPC);
		}
	}
}

bool UAVSCrowdSubsystem::GetPrimaryViewerState(FAVSViewerState& OutState) const
{
	for (const TWeakObjectPtr<UAVSArchvizCrowdComponent>& Viewer : Viewers)
	{
		if (Viewer.IsValid())
		{
			OutState = Viewer->GetCurrentViewerState();
			return true;
		}
	}
	return false;
}

void UAVSCrowdSubsystem::CompactReferences()
{
	Viewers.RemoveAll([](const TWeakObjectPtr<UAVSArchvizCrowdComponent>& Item) { return !Item.IsValid(); });
	Generators.RemoveAll([](const TWeakObjectPtr<AAVSCrowdGenerator>& Item) { return !Item.IsValid(); });
	ExclusionMasks.RemoveAll([](const TWeakObjectPtr<AAVSCrowdExclusionMask>& Item) { return !Item.IsValid(); });
	RegisteredNPCs.RemoveAll([](const TWeakObjectPtr<AAVSArchvizNPCCharacter>& Item) { return !Item.IsValid(); });
	ActiveNPCs.RemoveAll([](const TObjectPtr<AAVSArchvizNPCCharacter>& Item) { return !IsValid(Item); });
	PooledNPCs.RemoveAll([](const TObjectPtr<AAVSArchvizNPCCharacter>& Item) { return !IsValid(Item); });
}

void UAVSCrowdSubsystem::UpdateProximityConversations()
{
	AAVSCrowdGlobalController* Controller = GlobalController.Get();
	if (!GetWorld() || (Controller && (!Controller->bCrowdEnabled || !Controller->bEnableProximityConversations))) { return; }
	FAVSViewerState ViewerState;
	if (GetPrimaryViewerState(ViewerState) && !ViewerState.bCrowdEnabled) { return; }
	const UAVSArchvizSettings* ProjectSettings = GetDefault<UAVSArchvizSettings>();
	FAVSConversationSettings Global = ProjectSettings->Conversations;
	if (Controller && Controller->bOverrideConversationSettings) { Global = Controller->Conversations; }
	else if (Controller)
	{
		// Preserve the existing serialized Global Controller controls.
		Global.FormationPercentage = Controller->ConversationStartChancePerEvaluation * 100.0f;
		Global.DetectionRadius = Controller->ConversationDetectionRadius;
		Global.MaxGroupSize = Controller->MaxConversationGroupSize;
		Global.MinDuration = Controller->MinConversationDuration;
		Global.MaxDuration = Controller->MaxConversationDuration;
		Global.MinCooldown = Controller->MinConversationCooldown;
		Global.MaxCooldown = Controller->MaxConversationCooldown;
		Global.MinPostIdleTime = Controller->MinPostConversationIdleTime;
		Global.MaxPostIdleTime = Controller->MaxPostConversationIdleTime;
		Global.FacingInterpSpeed = Controller->ConversationFacingInterpSpeed;
	}
	const float Now = GetWorld()->GetTimeSeconds();
	const bool bGlobalDue = Now >= NextConversationEvaluationTime;
	if (bGlobalDue) { NextConversationEvaluationTime = Now + static_cast<float>(AVS::Composed::Safe(Global.EvaluationInterval, 2.0, 0.1, 86400.0)); }
	auto OverrideSettings = [](const AAVSCrowdGenerator* Generator) -> const FAVSConversationSettings*
	{
		const AAVSCrowdZone* Zone = Cast<AAVSCrowdZone>(Generator);
		if (Zone && Zone->bOverrideConversationSettings) { return &Zone->Conversations; }
		const AAVSSplineCrowdZone* Spline = Cast<AAVSSplineCrowdZone>(Generator);
		return Spline && Spline->bOverrideConversationSettings ? &Spline->Conversations : nullptr;
	};
	TSet<AAVSCrowdGenerator*> DueZones;
	float GridCellSize = static_cast<float>(AVS::Composed::Safe(Global.DetectionRadius, 260.0, 50.0, 100000.0));
	for (const TWeakObjectPtr<AAVSCrowdGenerator>& Generator : Generators)
	{
		if (const FAVSConversationSettings* Config = OverrideSettings(Generator.Get()))
		{
			GridCellSize = FMath::Max(GridCellSize, static_cast<float>(AVS::Composed::Safe(Config->DetectionRadius, 260.0, 50.0, 100000.0)));
			float& NextTime = ZoneConversationEvaluationTimes.FindOrAdd(Generator);
			if (Now >= NextTime)
			{
				NextTime = Now + static_cast<float>(AVS::Composed::Safe(Config->EvaluationInterval, 2.0, 0.1, 86400.0));
				DueZones.Add(Generator.Get());
			}
		}
	}
	if (!bGlobalDue && DueZones.IsEmpty()) { return; }
	for (auto It = ZoneConversationEvaluationTimes.CreateIterator(); It; ++It)
	{
		if (!It.Key().IsValid()) { It.RemoveCurrent(); }
	}
	auto OverrideZone = [&OverrideSettings](const AAVSArchvizNPCCharacter* NPC) -> AAVSCrowdGenerator*
	{
		AAVSCrowdGenerator* Generator = NPC ? Cast<AAVSCrowdGenerator>(NPC->GetOwningGenerator()) : nullptr;
		return OverrideSettings(Generator) ? Generator : nullptr;
	};
	TSet<AAVSCrowdRoute*> OccupiedRoutes;
	if (!Controller || Controller->bWaitForOccupiedRoutesBeforeConversation)
	{
		for (const TWeakObjectPtr<AAVSArchvizNPCCharacter>& NPCPtr : RegisteredNPCs)
		{
			const AAVSArchvizNPCCharacter* NPC = NPCPtr.Get();
			AAVSCrowdRoute* Route = NPC && NPC->Behavior && NPC->Behavior->GetBehaviorState() == EAVSNPCState::FollowRoute
				? NPC->Behavior->GetCurrentRoute() : nullptr;
			if (Route && Route->bBlockNearbyConversationsWhileOccupied) { OccupiedRoutes.Add(Route); }
		}
	}
	auto IsBlockedByOccupiedRoute = [&](const AAVSArchvizNPCCharacter* NPC)
	{
		for (const AAVSCrowdRoute* Route : OccupiedRoutes)
		{
			if (IsValid(Route) && Route->IsLocationNearRoute(NPC->GetActorLocation(),
				Controller ? Controller->OccupiedRouteConversationClearance : 220.0f)) { return true; }
		}
		return false;
	};
	auto GetCell = [GridCellSize](const FVector& Location)
	{
		return FIntPoint(FMath::FloorToInt(Location.X / GridCellSize), FMath::FloorToInt(Location.Y / GridCellSize));
	};
	TArray<AAVSArchvizNPCCharacter*> Eligible;
	TMap<FIntPoint, TArray<AAVSArchvizNPCCharacter*>> Grid;
	for (const TWeakObjectPtr<AAVSArchvizNPCCharacter>& NPCPtr : RegisteredNPCs)
	{
		AAVSArchvizNPCCharacter* NPC = NPCPtr.Get();
		if (NPC && NPC->Behavior && NPC->Behavior->CanJoinConversation())
		{
			Eligible.Add(NPC);
			Grid.FindOrAdd(GetCell(NPC->GetActorLocation())).Add(NPC);
		}
	}
	if (Eligible.Num() < 2) { return; }
	const int32 MaxLeaders = FMath::Min(Eligible.Num(), FMath::Max(1, ProjectSettings->MaxConversationCandidatesPerEvaluation));
	const int32 MaxNewGroups = Controller ? FMath::Max(1, Controller->MaxNewConversationsPerEvaluation) : 4;
	TSet<AAVSArchvizNPCCharacter*> Claimed;
	int32 NewGroupCount = 0;
	const int32 StartIndex = ConversationCandidateCursor % Eligible.Num();
	int32 Examined = 0;
	struct FNearbyCandidate { AAVSArchvizNPCCharacter* NPC; float DistanceSquared; };
	for (; Examined < MaxLeaders && NewGroupCount < MaxNewGroups; ++Examined)
	{
		AAVSArchvizNPCCharacter* Leader = Eligible[(StartIndex + Examined) % Eligible.Num()];
		AAVSCrowdGenerator* Zone = OverrideZone(Leader);
		const FAVSConversationSettings& Config = Zone ? *OverrideSettings(Zone) : Global;
		if (!Config.bEnabled || !(Zone ? DueZones.Contains(Zone) : bGlobalDue) || Claimed.Contains(Leader) ||
			!Leader->Behavior->CanJoinConversation() || IsBlockedByOccupiedRoute(Leader) ||
			!AVSActivityProbability::PassesPercentage(Config.FormationPercentage, SocialRandom.FRand())) { continue; }
		const float RadiusSquared = FMath::Square(static_cast<float>(AVS::Composed::Safe(Config.DetectionRadius, 260.0, 50.0, 100000.0)));
		TArray<FNearbyCandidate> Nearby;
		const FIntPoint LeaderCell = GetCell(Leader->GetActorLocation());
		for (int32 CellY = LeaderCell.Y - 1; CellY <= LeaderCell.Y + 1; ++CellY)
		{
			for (int32 CellX = LeaderCell.X - 1; CellX <= LeaderCell.X + 1; ++CellX)
			{
				const TArray<AAVSArchvizNPCCharacter*>* Candidates = Grid.Find(FIntPoint(CellX, CellY));
				if (!Candidates) { continue; }
				for (AAVSArchvizNPCCharacter* Candidate : *Candidates)
				{
					if (Candidate == Leader || Claimed.Contains(Candidate) || OverrideZone(Candidate) != Zone ||
						!Candidate->Behavior->CanJoinConversation() || IsBlockedByOccupiedRoute(Candidate)) { continue; }
					const float Distance = FVector::DistSquared2D(Leader->GetActorLocation(), Candidate->GetActorLocation());
					if (Distance <= RadiusSquared && FMath::Abs(Leader->GetActorLocation().Z - Candidate->GetActorLocation().Z) <= static_cast<float>(AVS::Composed::Safe(Config.MaxVerticalSeparation, 100.0, 0.0, 10000.0)))
					{
						Nearby.Add(FNearbyCandidate{ Candidate, Distance });
					}
				}
			}
		}
		if (Nearby.IsEmpty()) { continue; }
		Nearby.Sort([](const FNearbyCandidate& A, const FNearbyCandidate& B) { return A.DistanceSquared < B.DistanceSquared; });
		TArray<AAVSArchvizNPCCharacter*> Group;
		Group.Add(Leader);
		const int32 TargetSize = SocialRandom.RandRange(2, FMath::Clamp(Config.MaxGroupSize, 2, 4));
		for (const FNearbyCandidate& Candidate : Nearby)
		{
			if (Group.Num() >= TargetSize) { break; }
			Group.Add(Candidate.NPC);
		}
		int32 Started = 0;
		for (AAVSArchvizNPCCharacter* Member : Group)
		{
			const float MinDuration = static_cast<float>(AVS::Composed::Safe(Config.MinDuration, 6.0, 0.1, 86400.0));
			const float MinCooldown = static_cast<float>(AVS::Composed::Safe(Config.MinCooldown, 12.0, 0.0, 86400.0));
			const float MinIdle = static_cast<float>(AVS::Composed::Safe(Config.MinPostIdleTime, 0.75, 0.0, 86400.0));
			if (Member->Behavior->StartConversation(Group,
				SocialRandom.FRandRange(MinDuration, static_cast<float>(AVS::Composed::Safe(Config.MaxDuration, MinDuration, MinDuration, 86400.0))),
				SocialRandom.FRandRange(MinCooldown, static_cast<float>(AVS::Composed::Safe(Config.MaxCooldown, MinCooldown, MinCooldown, 86400.0))),
				SocialRandom.FRandRange(MinIdle, static_cast<float>(AVS::Composed::Safe(Config.MaxPostIdleTime, MinIdle, MinIdle, 86400.0))), Config.FacingInterpSpeed))
			{
				Claimed.Add(Member);
				++Started;
			}
		}
		if (Started >= 2) { ++NewGroupCount; }
		else if (Started == 1)
		{
			for (AAVSArchvizNPCCharacter* Member : Group)
			{
				if (Claimed.Contains(Member)) { Member->Behavior->LeaveConversation(false); }
			}
		}
	}
	ConversationCandidateCursor = (StartIndex + FMath::Max(1, Examined)) % Eligible.Num();
}

void UAVSCrowdSubsystem::ApplyQualityTiers(const FAVSViewerState& ViewerState)
{
	const UAVSArchvizSettings* Settings = GetDefault<UAVSArchvizSettings>();
	const TArray<FAVSQualityTier>* QualityTiers = GlobalController.IsValid() && !GlobalController->QualityTiers.IsEmpty()
		? &GlobalController->QualityTiers
		: (Settings ? &Settings->QualityTiers : nullptr);
	if (!QualityTiers || QualityTiers->IsEmpty())
	{
		return;
	}
	const int32 Count = ActiveNPCs.Num();
	if (Count == 0) { QualityUpdateCursor = 0; return; }
	const int32 Budget = FMath::Min(Count, Settings ? FMath::Max(1, Settings->MaxQualityUpdatesPerEvaluation) : 64);
	const int32 StartIndex = QualityUpdateCursor % Count;
	for (int32 Offset = 0; Offset < Budget; ++Offset)
	{
		AAVSArchvizNPCCharacter* NPC = ActiveNPCs[(StartIndex + Offset) % Count];
		if (!IsValid(NPC)) { continue; }
		const float Distance = FVector::Dist(ViewerState.ViewLocation, NPC->GetActorLocation());
		const FAVSQualityTier* Chosen = &QualityTiers->Last();
		for (const FAVSQualityTier& Tier : *QualityTiers)
		{
			if (Distance <= Tier.MaxDistance)
			{
				Chosen = &Tier;
				break;
			}
		}
		FAVSQualityTier EffectiveTier = *Chosen;
		if (GlobalController.IsValid())
		{
			EffectiveTier.bCastShadows = EffectiveTier.bCastShadows && GlobalController->bAllowShadows;
			EffectiveTier.bEnableCollision = EffectiveTier.bEnableCollision && GlobalController->bAllowCollision;
			EffectiveTier.bEnableAvoidance = EffectiveTier.bEnableAvoidance && GlobalController->bAllowLightweightAvoidance;
			EffectiveTier.bUseAnimationUpdateRateOptimization = EffectiveTier.bUseAnimationUpdateRateOptimization &&
				GlobalController->bEnableAnimationUpdateRateOptimization;
			if (GlobalController->GlobalMaxDrawDistance > 0.0f)
			{
				EffectiveTier.MaxDrawDistance = EffectiveTier.MaxDrawDistance > 0.0f
					? FMath::Min(EffectiveTier.MaxDrawDistance, GlobalController->GlobalMaxDrawDistance)
					: GlobalController->GlobalMaxDrawDistance;
			}
		}
		NPC->ApplyQualityTier(EffectiveTier);
	}
	QualityUpdateCursor = (StartIndex + Budget) % Count;
}
