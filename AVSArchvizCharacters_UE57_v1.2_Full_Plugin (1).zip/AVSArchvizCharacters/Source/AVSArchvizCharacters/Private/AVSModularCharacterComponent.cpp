#include "AVSModularCharacterComponent.h"

#include "AVSArchvizCharacters.h"
#include "AVSCharacterProfile.h"
#include "Animation/AnimInstance.h"
#include "Animation/AnimBlueprintGeneratedClass.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/SkeletalMesh.h"
#include "GameFramework/Character.h"
#include "Materials/MaterialInterface.h"

UAVSModularCharacterComponent::UAVSModularCharacterComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}

void UAVSModularCharacterComponent::BeginPlay()
{
	Super::BeginPlay();
	if (bApplyOnBeginPlay && CharacterProfile)
	{
		ApplyProfile(CharacterProfile);
	}
}

void UAVSModularCharacterComponent::OnUnregister()
{
	ClearModularParts();
	RestoreOriginalBody();
	Super::OnUnregister();
}

USkeletalMeshComponent* UAVSModularCharacterComponent::GetBodyMesh() const
{
	const ACharacter* OwnerCharacter = Cast<ACharacter>(GetOwner());
	return OwnerCharacter ? OwnerCharacter->GetMesh() : nullptr;
}

const FAVSSkinnedPartDefinition* UAVSModularCharacterComponent::SelectPartForSlot(
	const TArray<const FAVSSkinnedPartDefinition*>& Candidates,
	FRandomStream& Stream) const
{
	if (Candidates.IsEmpty())
	{
		return nullptr;
	}
	if (!CharacterProfile || !CharacterProfile->bRandomizeModularParts)
	{
		return Candidates[0];
	}

	float TotalWeight = 0.0f;
	for (const FAVSSkinnedPartDefinition* Candidate : Candidates)
	{
		TotalWeight += Candidate ? FMath::Max(0.0f, Candidate->SelectionWeight) : 0.0f;
	}
	if (TotalWeight <= 0.0f)
	{
		return Candidates[Stream.RandRange(0, Candidates.Num() - 1)];
	}

	float Choice = Stream.FRandRange(0.0f, TotalWeight);
	for (const FAVSSkinnedPartDefinition* Candidate : Candidates)
	{
		Choice -= Candidate ? FMath::Max(0.0f, Candidate->SelectionWeight) : 0.0f;
		if (Choice <= 0.0f)
		{
			return Candidate;
		}
	}
	return Candidates.Last();
}

bool UAVSModularCharacterComponent::ApplyProfile(UAVSCharacterProfile* NewProfile)
{
	ACharacter* OwnerCharacter = Cast<ACharacter>(GetOwner());
	USkeletalMeshComponent* Leader = OwnerCharacter ? OwnerCharacter->GetMesh() : nullptr;
	if (!Leader || !NewProfile)
	{
		UE_LOG(LogAVSArchvizCharacters, Warning, TEXT("ApplyProfile requires an ACharacter owner and a valid Character Profile."));
		return false;
	}

	if (!bSavedOriginalBody)
	{
		OriginalBodyMesh = Leader->GetSkeletalMeshAsset();
		OriginalAnimClass = Leader->GetAnimClass();
		bSavedOriginalBody = true;
	}

	USkeletalMesh* Body = NewProfile->BodyMesh.LoadSynchronous();
	if (!Body)
	{
		UE_LOG(LogAVSArchvizCharacters, Warning, TEXT("Character Profile '%s' has no valid Body Mesh."), *GetNameSafe(NewProfile));
		return false;
	}

	if (const UAnimBlueprintGeneratedClass* AnimationClass = Cast<UAnimBlueprintGeneratedClass>(NewProfile->AnimationBlueprint.LoadSynchronous()))
		if (AnimationClass->GetTargetSkeleton() != Body->GetSkeleton())
		{
			UE_LOG(LogAVSArchvizCharacters, Warning, TEXT("Character Profile '%s' has an Animation Blueprint for another Skeleton. Assign a target-specific class."), *GetNameSafe(NewProfile));
			return false;
		}
	CharacterProfile = NewProfile;
	if (NewProfile->bRandomizeModularParts && NewProfile->bRandomizeOnEverySpawn)
	{
		++AppearanceRoll;
	}
	Leader->SetSkeletalMeshAsset(Body);
	Leader->SetRelativeTransform(NewProfile->BodyMeshRelativeTransform);
	if (UClass* AnimClass = NewProfile->AnimationBlueprint.LoadSynchronous())
	{
		Leader->SetAnimationMode(EAnimationMode::AnimationBlueprint);
		Leader->SetAnimInstanceClass(AnimClass);
	}
	else
	{
		Leader->SetAnimInstanceClass(nullptr);
		Leader->SetAnimationMode(EAnimationMode::AnimationSingleNode);
	}

	FRandomStream Stream;
	const int32 Seed = HashCombineFast(
		GetTypeHash(NewProfile->ModularRandomSeed + RandomSeedOffset + AppearanceRoll),
		GetTypeHash(GetOwner()->GetFName()));
	Stream.Initialize(Seed);

	TMap<EAVSModularSlot, TArray<const FAVSSkinnedPartDefinition*>> CandidatesBySlot;
	for (const FAVSSkinnedPartDefinition& Definition : NewProfile->ModularParts)
	{
		if (Definition.bEnabled && (Definition.bNoPart || !Definition.Mesh.IsNull()) &&
			AVSIsSexCompatible(NewProfile->Sex, Definition.CompatibleSex))
		{
			CandidatesBySlot.FindOrAdd(Definition.Slot).Add(&Definition);
		}
	}

	TSet<EAVSModularSlot> DefinedSlots;
	for (const TPair<EAVSModularSlot, TArray<const FAVSSkinnedPartDefinition*>>& Pair : CandidatesBySlot)
	{
		if (const FAVSSkinnedPartDefinition* Selected = SelectPartForSlot(Pair.Value, Stream))
		{
			if (!Selected->bNoPart)
			{
				DefinedSlots.Add(Pair.Key);
			}
			ApplyPart(*Selected, Leader);
		}
	}

	TArray<EAVSModularSlot> ExistingSlots;
	GeneratedParts.GetKeys(ExistingSlots);
	for (EAVSModularSlot Slot : ExistingSlots)
	{
		if (!DefinedSlots.Contains(Slot))
		{
			if (USkeletalMeshComponent* Part = GeneratedParts.FindRef(Slot))
			{
				Part->DestroyComponent();
			}
			GeneratedParts.Remove(Slot);
		}
	}

	ApplyProp(NewProfile->RightHandProp, true, Leader);
	ApplyProp(NewProfile->LeftHandProp, false, Leader);
	return true;
}

bool UAVSModularCharacterComponent::RandomizeModularParts()
{
	if (!CharacterProfile)
	{
		return false;
	}
	if (!CharacterProfile->bRandomizeOnEverySpawn)
	{
		++AppearanceRoll;
	}
	return ApplyProfile(CharacterProfile);
}

void UAVSModularCharacterComponent::ApplyPart(const FAVSSkinnedPartDefinition& Definition, USkeletalMeshComponent* Leader)
{
	USkeletalMesh* PartMesh = Definition.Mesh.LoadSynchronous();
	USkeletalMeshComponent* Part = GeneratedParts.FindRef(Definition.Slot);
	if (!PartMesh)
	{
		if (Part)
		{
			Part->DestroyComponent();
			GeneratedParts.Remove(Definition.Slot);
		}
		return;
	}

	if (CharacterProfile && CharacterProfile->bRequireSameSkeleton && Leader->GetSkeletalMeshAsset() &&
		PartMesh->GetSkeleton() != Leader->GetSkeletalMeshAsset()->GetSkeleton())
	{
		UE_LOG(LogAVSArchvizCharacters, Warning, TEXT("%s: modular slot %s has an incompatible Skeleton."),
			*GetNameSafe(GetOwner()), *UEnum::GetValueAsString(Definition.Slot));
		if (Part)
		{
			Part->DestroyComponent();
			GeneratedParts.Remove(Definition.Slot);
		}
		return;
	}

	if (!Part)
	{
		const FName ComponentName(*FString::Printf(TEXT("AVS_%s"), *UEnum::GetValueAsString(Definition.Slot)));
		Part = NewObject<USkeletalMeshComponent>(GetOwner(), ComponentName, RF_Transient);
		GetOwner()->AddInstanceComponent(Part);
		Part->SetupAttachment(Leader);
		Part->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		Part->SetGenerateOverlapEvents(false);
		Part->SetCanEverAffectNavigation(false);
		Part->RegisterComponent();
		GeneratedParts.Add(Definition.Slot, Part);
	}

	Part->AttachToComponent(Leader, FAttachmentTransformRules::SnapToTargetNotIncludingScale);
	Part->SetSkeletalMeshAsset(PartMesh);
	Part->EmptyOverrideMaterials();
	for (int32 Index = 0; Index < Definition.MaterialOverrides.Num(); ++Index)
	{
		if (UMaterialInterface* Material = Definition.MaterialOverrides[Index].LoadSynchronous())
		{
			Part->SetMaterial(Index, Material);
		}
	}
	Part->SetLeaderPoseComponent(Leader, false, false);
	Part->SetVisibility(true, true);
}

void UAVSModularCharacterComponent::ApplyProp(const FAVSPropDefinition& Definition, bool bRightHand, USkeletalMeshComponent* Leader)
{
	TObjectPtr<UStaticMeshComponent>& Stored = bRightHand ? RightPropComponent : LeftPropComponent;
	UStaticMeshComponent* Component = Stored.Get();
	UStaticMesh* Mesh = Definition.Mesh.LoadSynchronous();
	if (!Mesh || Definition.SocketName.IsNone() || !Leader->DoesSocketExist(Definition.SocketName))
	{
		if (Component)
		{
			Component->DestroyComponent();
			Stored = nullptr;
		}
		return;
	}

	if (!Component)
	{
		Component = NewObject<UStaticMeshComponent>(GetOwner(), bRightHand ? TEXT("AVS_RightProp") : TEXT("AVS_LeftProp"), RF_Transient);
		GetOwner()->AddInstanceComponent(Component);
		Component->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		Component->SetGenerateOverlapEvents(false);
		Component->SetCanEverAffectNavigation(false);
		Component->RegisterComponent();
		Stored = Component;
	}
	Component->AttachToComponent(Leader, FAttachmentTransformRules::SnapToTargetNotIncludingScale, Definition.SocketName);
	Component->SetStaticMesh(Mesh);
	Component->SetRelativeTransform(Definition.RelativeTransform);
	Component->SetVisibility(true, true);
}

void UAVSModularCharacterComponent::ClearModularParts()
{
	for (TPair<EAVSModularSlot, TObjectPtr<USkeletalMeshComponent>>& Pair : GeneratedParts)
	{
		if (Pair.Value)
		{
			Pair.Value->DestroyComponent();
		}
	}
	GeneratedParts.Empty();
	if (RightPropComponent)
	{
		RightPropComponent->DestroyComponent();
		RightPropComponent = nullptr;
	}
	if (LeftPropComponent)
	{
		LeftPropComponent->DestroyComponent();
		LeftPropComponent = nullptr;
	}
}

void UAVSModularCharacterComponent::RestoreOriginalBody()
{
	USkeletalMeshComponent* Leader = GetBodyMesh();
	if (!Leader || !bSavedOriginalBody)
	{
		return;
	}
	Leader->SetSkeletalMeshAsset(OriginalBodyMesh);
	if (OriginalAnimClass)
	{
		Leader->SetAnimationMode(EAnimationMode::AnimationBlueprint);
		Leader->SetAnimInstanceClass(OriginalAnimClass);
	}
	else
	{
		Leader->SetAnimInstanceClass(nullptr);
		Leader->SetAnimationMode(EAnimationMode::AnimationSingleNode);
	}
	bSavedOriginalBody = false;
}

USkeletalMeshComponent* UAVSModularCharacterComponent::GetPartComponent(EAVSModularSlot Slot) const
{
	return GeneratedParts.FindRef(Slot);
}

bool UAVSModularCharacterComponent::ValidateCurrentAppearance(TArray<FText>& OutIssues) const
{
	if (!CharacterProfile)
	{
		OutIssues.Reset();
		OutIssues.Add(NSLOCTEXT("AVS", "NoCharacterProfile", "No Character Profile is assigned."));
		return false;
	}
	return CharacterProfile->ValidateProfile(OutIssues);
}
