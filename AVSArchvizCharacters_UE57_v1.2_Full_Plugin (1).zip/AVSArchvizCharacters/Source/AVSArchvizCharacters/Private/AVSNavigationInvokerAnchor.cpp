#include "AVSNavigationInvokerAnchor.h"

#include "Components/SceneComponent.h"
#include "NavigationInvokerComponent.h"

AAVSNavigationInvokerAnchor::AAVSNavigationInvokerAnchor()
{
	PrimaryActorTick.bCanEverTick = false;
	SetActorEnableCollision(false);
	SetCanBeDamaged(false);

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	SetRootComponent(SceneRoot);

	NavigationInvoker = CreateDefaultSubobject<UNavigationInvokerComponent>(TEXT("NavigationInvoker"));
	NavigationInvoker->SetGenerationRadii(12000.0f, 16000.0f);
}

void AAVSNavigationInvokerAnchor::ConfigureRadii(float GenerationRadius, float RemovalRadius)
{
	if (NavigationInvoker)
	{
		const float SafeGenerationRadius = FMath::Max(500.0f, GenerationRadius);
		NavigationInvoker->SetGenerationRadii(
			SafeGenerationRadius,
			FMath::Max(SafeGenerationRadius + 100.0f, RemovalRadius));
	}
}
