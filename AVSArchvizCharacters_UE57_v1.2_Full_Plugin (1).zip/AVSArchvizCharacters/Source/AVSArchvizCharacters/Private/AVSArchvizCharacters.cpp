#include "AVSArchvizCharacters.h"

#include "Modules/ModuleManager.h"

DEFINE_LOG_CATEGORY(LogAVSArchvizCharacters);

void FAVSArchvizCharactersModule::StartupModule()
{
	UE_LOG(LogAVSArchvizCharacters, Log, TEXT("AVS ArchViz Characters runtime module started."));
}

void FAVSArchvizCharactersModule::ShutdownModule()
{
}

IMPLEMENT_MODULE(FAVSArchvizCharactersModule, AVSArchvizCharacters)
