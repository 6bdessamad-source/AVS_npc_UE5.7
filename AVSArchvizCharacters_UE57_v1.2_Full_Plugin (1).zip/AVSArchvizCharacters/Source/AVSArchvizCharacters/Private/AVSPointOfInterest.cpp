#include "AVSPointOfInterest.h"

#include "AVSArchvizNPCCharacter.h"
#include "AVSAnimationProfile.h"
#include "AVSResolvedAnimation.h"
#include "AVSNPCBehaviorComponent.h"
#include "Components/BillboardComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/SphereComponent.h"
#include "Components/SceneComponent.h"
#include "Animation/AnimSequenceBase.h"
#include "Engine/SkeletalMesh.h"
#include "Engine/Texture2D.h"
#include "Engine/World.h"
#include "UObject/ConstructorHelpers.h"

AAVSPointOfInterest::AAVSPointOfInterest()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bStartWithTickEnabled = false;
	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	SetRootComponent(SceneRoot);

	AutoTrigger = CreateDefaultSubobject<USphereComponent>(TEXT("AutoTrigger"));
	AutoTrigger->SetupAttachment(SceneRoot);
	AutoTrigger->SetSphereRadius(250.0f);
	AutoTrigger->SetCollisionObjectType(ECC_WorldDynamic);
	AutoTrigger->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
	AutoTrigger->SetCollisionResponseToAllChannels(ECR_Ignore);
	AutoTrigger->SetCollisionResponseToChannel(ECC_Pawn, ECR_Overlap);
	AutoTrigger->SetGenerateOverlapEvents(true);
	AutoTrigger->SetCanEverAffectNavigation(false);
	AutoTrigger->SetHiddenInGame(true);

#if WITH_EDITORONLY_DATA
	EditorBillboard = CreateEditorOnlyDefaultSubobject<UBillboardComponent>(TEXT("EditorBillboard"));
	if (EditorBillboard)
	{
		EditorBillboard->SetupAttachment(SceneRoot);
		EditorBillboard->SetRelativeLocation(FVector(0.0f, 0.0f, 100.0f));
		EditorBillboard->SetHiddenInGame(true);
		EditorBillboard->SetIsVisualizationComponent(true);
		static ConstructorHelpers::FObjectFinder<UTexture2D> Sprite(TEXT("/Engine/EditorResources/S_Note.S_Note"));
		if (Sprite.Succeeded())
		{
			EditorBillboard->SetSprite(Sprite.Object);
		}
	}

	EditorPreviewMesh = CreateEditorOnlyDefaultSubobject<USkeletalMeshComponent>(TEXT("EditorPreviewMesh"));
	if (EditorPreviewMesh)
	{
		EditorPreviewMesh->SetupAttachment(SceneRoot);
		EditorPreviewMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		EditorPreviewMesh->SetGenerateOverlapEvents(false);
		EditorPreviewMesh->SetCanEverAffectNavigation(false);
		EditorPreviewMesh->SetHiddenInGame(true);
		EditorPreviewMesh->SetCastShadow(false);
		EditorPreviewMesh->bSelectable = false;
	}
#endif
}

void AAVSPointOfInterest::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);
	RefreshAutoTrigger();
	RefreshEditorPreview();
}

void AAVSPointOfInterest::BeginPlay()
{
	Super::BeginPlay();
	SetActorTickEnabled(false);
	if (AutoTrigger)
	{
		AutoTrigger->OnComponentBeginOverlap.AddUniqueDynamic(this, &AAVSPointOfInterest::HandleAutoTriggerBeginOverlap);
	}
	RefreshAutoTrigger();
}

void AAVSPointOfInterest::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	TSet<AActor*> Users;
	for (AActor* User : ReservedUsers) Users.Add(User);
	for (AActor* User : QueuedUsers) Users.Add(User);
	for (AActor* User : Users)
	{
		if (IsValid(User))
		{
			User->OnDestroyed.RemoveDynamic(this, &AAVSPointOfInterest::HandleUserDestroyed);
			User->OnEndPlay.RemoveDynamic(this, &AAVSPointOfInterest::HandleUserEndPlay);
		}
	}
	ReservedUsers.Reset();
	QueuedUsers.Reset();
	if (AutoTrigger)
	{
		AutoTrigger->OnComponentBeginOverlap.RemoveDynamic(this, &AAVSPointOfInterest::HandleAutoTriggerBeginOverlap);
	}
#if WITH_EDITORONLY_DATA
	PreviewPlayback.Reset();
	ResolvedPreviewClips.Reset();
	ActivePreviewClip = nullptr;
	if (EditorPreviewMesh)
	{
		EditorPreviewMesh->Stop();
		EditorPreviewMesh->SetAnimation(nullptr);
		EditorPreviewMesh->bPauseAnims = false;
	}
#endif
	Super::EndPlay(EndPlayReason);
}

void AAVSPointOfInterest::RefreshAutoTrigger()
{
	if (!AutoTrigger)
	{
		return;
	}
	AutoTrigger->SetRelativeLocation(UseOffset.ContainsNaN() ? FVector::ZeroVector : UseOffset);
	AutoTrigger->SetCollisionEnabled(bAutoTriggerNearbyNPCs ? ECollisionEnabled::QueryOnly : ECollisionEnabled::NoCollision);
	AutoTrigger->SetGenerateOverlapEvents(bAutoTriggerNearbyNPCs);
}

bool AAVSPointOfInterest::ResolveRuntimeAnimation(UAVSAnimationProfile* Profile, const USkeleton* Skeleton,
	FRandomStream& Stream, FAVSNamedAnimation& OutEntry) const
{
	if (!Profile || !Skeleton || Profile->TargetSkeleton.LoadSynchronous() != Skeleton)
	{
		return false;
	}
	FAVSResolveSettings Settings;
	Settings.bAllowReverse = bUseSmartMissingTransitionFallback;
	Settings.bAllowHold = bAllowPoseHoldFallback;
	Settings.HoldPosition = HoldNormalizedPosition;
	Settings.Duration = bAutoLeaveAfterUse
		? static_cast<float>(AVS::Composed::Safe(MinUseDuration, 5.0, 0.1, 86400.0)) : -1.0f;
	auto MergeOverrides = [this, Skeleton](FAVSNamedAnimation& Entry)
	{
		Entry.bLoop = bLoopActivity;
		if (!bUseRuntimeAnimationOverrides)
		{
			return;
		}
		auto Merge = [Skeleton](const TSoftObjectPtr<UAnimSequenceBase>& Override, TSoftObjectPtr<UAnimSequenceBase>& Clip)
		{
			if (UAnimSequenceBase* Asset = Override.LoadSynchronous())
			{
				if (Asset->GetSkeleton() == Skeleton && Asset->GetPlayLength() > 0.0f)
				{
					Clip = Asset;
				}
			}
		};
		Merge(RuntimeStartAnimation, Entry.StartAnimation);
		Merge(RuntimeAnimation, Entry.Animation);
		Merge(RuntimeEndAnimation, Entry.EndAnimation);
	};
	TArray<FAVSNamedAnimation> Candidates;
	double TotalWeight = 0.0;
	bool bMatchingProfileRow = false;
	for (const FAVSNamedAnimation& Source : Profile->Animations)
	{
		if (Source.Slot != ActivityAnimation || (ActivityAnimation == EAVSAnimationSlot::Custom && Source.CustomName != CustomAnimationName))
		{
			continue;
		}
		bMatchingProfileRow = true;
		FAVSNamedAnimation Entry = Source;
		MergeOverrides(Entry);
		const double Weight = AVS::Composed::Safe(Entry.SelectionWeight, 0.0, 0.0, 1000000.0);
		if (Weight > 0.0 && AVSResolveAnimation(Profile, Entry, Skeleton, Settings).Plan.Valid)
		{
			Entry.SelectionWeight = static_cast<float>(Weight);
			Candidates.Add(Entry);
			TotalWeight += Weight;
		}
	}
	// Explicit runtime overrides may supply an otherwise absent row. Preview-only fields never enter this path.
	if (!bMatchingProfileRow && bUseRuntimeAnimationOverrides)
	{
		FAVSNamedAnimation Entry;
		Entry.Slot = ActivityAnimation;
		Entry.CustomName = CustomAnimationName;
		MergeOverrides(Entry);
		if (AVSResolveAnimation(Profile, Entry, Skeleton, Settings).Plan.Valid)
		{
			Candidates.Add(Entry);
			TotalWeight += 1.0;
		}
	}
	if (Candidates.IsEmpty())
	{
		return false;
	}
	double Choice = Stream.FRand() * TotalWeight;
	for (const FAVSNamedAnimation& Entry : Candidates)
	{
		Choice -= Entry.SelectionWeight;
		if (Choice < 0.0)
		{
			OutEntry = Entry;
			return true;
		}
	}
	OutEntry = Candidates.Last();
	return true;
}

void AAVSPointOfInterest::RefreshEditorPreview()
{
#if WITH_EDITORONLY_DATA
	if (!EditorPreviewMesh)
	{
		return;
	}
	PreviewPlayback.Reset();
	PreviewPlan = AVS::Composed::Plan();
	PreviewInspectionSegment = AVS::Composed::Segment();
	PreviewInspectionElapsed = 0.0;
	ResolvedPreviewClips.Reset();
	ActivePreviewClip = nullptr;
	EditorPreviewMesh->Stop();
	EditorPreviewMesh->SetAnimation(nullptr);
	EditorPreviewMesh->bPauseAnims = false;
	SetActorTickEnabled(false);
	FTransform PreviewTransform = PreviewRelativeTransform;
	PreviewTransform.AddToTranslation(UseOffset.ContainsNaN() ? FVector::ZeroVector : UseOffset);
	EditorPreviewMesh->SetRelativeTransform(PreviewTransform);
	USkeletalMesh* PreviewMesh = PreviewSkeletalMesh.LoadSynchronous();
	EditorPreviewMesh->SetSkeletalMeshAsset(PreviewMesh);
	EditorPreviewMesh->SetVisibility(PreviewMesh != nullptr, true);
	EditorPreviewMesh->SetUpdateAnimationInEditor(bPreviewAnimationInEditor);
	if (!bPreviewAnimationInEditor || !PreviewMesh)
	{
		PreviewStatus = TEXT("Assign a Preview Skeletal Mesh and enable editor animation preview.");
		return;
	}
	UAVSAnimationProfile* Profile = PreviewAnimationProfile.LoadSynchronous();
	FAVSNamedAnimation Entry;
	FAVSResolveSettings Settings;
	Settings.bAllowReverse = bUseSmartMissingTransitionFallback;
	Settings.bAllowHold = bAllowPoseHoldFallback;
	Settings.HoldPosition = HoldNormalizedPosition;
	const double MinDuration = AVS::Composed::Safe(MinUseDuration, 5.0, 0.1, 86400.0);
	const double MaxDuration = AVS::Composed::Safe(MaxUseDuration, MinDuration, MinDuration, 86400.0);
	// Deterministic midpoint previews the runtime duration range. Caller-owned POIs remain held until explicit release.
	Settings.Duration = bAutoLeaveAfterUse ? static_cast<float>((MinDuration + MaxDuration) * 0.5) : -1.0f;
	UAnimSequenceBase* IdleClip = nullptr;
	if (bPreviewProfileDriven)
	{
		FRandomStream PreviewRandom(1337);
		if (!ResolveRuntimeAnimation(Profile, PreviewMesh->GetSkeleton(), PreviewRandom, Entry))
		{
			PreviewStatus = TEXT("Runtime sequence unavailable: select a profile for this body's exact Skeleton and configure a usable activity row or compatible Runtime Animation Overrides. Legacy preview clips do not supply runtime assets.");
			return;
		}
		IdleClip = Profile->ResolveAnimation(EAVSAnimationSlot::Idle);
		PreviewStatus = FString::Printf(TEXT("Runtime profile: %s. Compatible runtime overrides take precedence over profile clips. Duration: %s. Legacy preview clips are ignored."),
			*Profile->GetName(), bAutoLeaveAfterUse ? *FString::Printf(TEXT("%.2f s (range midpoint)"), Settings.Duration) : TEXT("manual release"));
	}
	else
	{
		// Legacy mode is explicitly pose-only, but still resolves slices through the same production policy.
		Entry.Slot = ActivityAnimation;
		Entry.Animation = PreviewAnimation;
		Entry.StartAnimation = PreviewStartAnimation;
		Entry.EndAnimation = PreviewEndAnimation;
		Entry.PlayRate = PreviewPlayRate;
		Entry.bLoop = bLoopActivity;
		Settings.bAllowReverse = bPreviewUseSmartMissingTransitionFallback;
		IdleClip = PreviewIdleAnimation.LoadSynchronous();
		PreviewStatus = TEXT("POSE ONLY: legacy editor clips never supply runtime playback. Enable Profile Driven preview to validate the runtime sequence.");
	}
	FAVSResolvedAnimation Resolved;
	if (bPreviewProfileDriven)
	{
		Resolved = AVSResolveAnimation(Profile, Entry, PreviewMesh->GetSkeleton(), Settings);
	}
	else
	{
		auto Compatible = [PreviewMesh](UAnimSequenceBase* Clip)
		{
			return Clip && Clip->GetSkeleton() == PreviewMesh->GetSkeleton() && Clip->GetPlayLength() > 0.0f ? Clip : nullptr;
		};
		Resolved.Start = Compatible(Entry.StartAnimation.LoadSynchronous());
		Resolved.Main = Compatible(Entry.Animation.LoadSynchronous());
		Resolved.End = Compatible(Entry.EndAnimation.LoadSynchronous());
		AVS::Composed::Clips Clips;
		Clips.Start = Resolved.Start ? Resolved.Start->GetPlayLength() : 0.0;
		Clips.Main = Resolved.Main ? Resolved.Main->GetPlayLength() : 0.0;
		Clips.End = Resolved.End ? Resolved.End->GetPlayLength() : 0.0;
		AVS::Composed::Options Options;
		Options.Reverse = Settings.bAllowReverse;
		Options.Hold = Settings.bAllowHold;
		Options.HoldPosition = Settings.HoldPosition;
		Options.Rate = Entry.PlayRate;
		Options.Duration = Settings.Duration;
		Options.Loop = Entry.bLoop;
		Resolved.Plan = AVS::Composed::Resolve(Clips, Options);
	}
	PreviewPlan = Resolved.Plan;
	ResolvedPreviewClips.Add(nullptr); // AVS::Composed::Clip::None
	ResolvedPreviewClips.Add(Resolved.Start);
	ResolvedPreviewClips.Add(Resolved.Main);
	ResolvedPreviewClips.Add(Resolved.End);
	if (PreviewPhase == EAVSPOIPreviewPhase::Idle && !(bPreviewProfileDriven && bPreviewPlaySequence))
	{
		if (IdleClip && IdleClip->GetSkeleton() == PreviewMesh->GetSkeleton())
		{
			ActivePreviewClip = IdleClip;
			EditorPreviewMesh->SetAnimationMode(EAnimationMode::AnimationSingleNode, true);
			EditorPreviewMesh->PlayAnimation(IdleClip, true);
			EditorPreviewMesh->SetPlayRate(1.0f);
		}
		else PreviewStatus += TEXT(" No compatible standing Idle is available for inspection.");
		return;
	}
	if (!PreviewPlan.Valid)
	{
		PreviewStatus += TEXT(" No compatible composed sequence can be resolved with these fallback settings.");
		return;
	}
	if (bPreviewProfileDriven && bPreviewPlaySequence)
	{
		PreviewPlayback.Begin(PreviewPlan);
	}
	else
	{
		PreviewInspectionSegment = PreviewPhase == EAVSPOIPreviewPhase::Start ? PreviewPlan.Entry
			: PreviewPhase == EAVSPOIPreviewPhase::End ? PreviewPlan.Exit : PreviewPlan.Body;
		if (PreviewInspectionSegment.Source == AVS::Composed::Clip::None)
		{
			PreviewStatus += TEXT(" Selected phase has no runtime segment; inspect Activity or enable full sequence preview.");
			return;
		}
	}
	UpdateEditorPreviewPose();
	SetActorTickEnabled(GetWorld() && !GetWorld()->IsGameWorld());
#endif
}

void AAVSPointOfInterest::RestartEditorPreview()
{
#if WITH_EDITOR
	if (GetWorld() && !GetWorld()->IsGameWorld()) RefreshEditorPreview();
#endif
}

void AAVSPointOfInterest::RequestEditorPreviewExit()
{
#if WITH_EDITORONLY_DATA
	if (GetWorld() && !GetWorld()->IsGameWorld() && bPreviewProfileDriven && bPreviewPlaySequence)
	{
		PreviewPlayback.RequestExit();
		UpdateEditorPreviewPose();
	}
#endif
}

void AAVSPointOfInterest::UpdateEditorPreviewPose()
{
#if WITH_EDITORONLY_DATA
	if (!EditorPreviewMesh || !PreviewPlan.Valid)
	{
		return;
	}
	const bool bSequence = bPreviewProfileDriven && bPreviewPlaySequence;
	const AVS::Composed::Segment& Segment = bSequence ? PreviewPlayback.GetSegment() : PreviewInspectionSegment;
	const int32 ClipIndex = static_cast<int32>(Segment.Source);
	UAnimSequenceBase* Clip = ResolvedPreviewClips.IsValidIndex(ClipIndex) ? ResolvedPreviewClips[ClipIndex].Get() : nullptr;
	if (!Clip)
	{
		return;
	}
	double Position = PreviewPlayback.GetPosition();
	if (!bSequence)
	{
		const bool bLoop = PreviewPhase == EAVSPOIPreviewPhase::ActivityLoop && !PreviewPlan.Hold && bLoopActivity;
		const double Elapsed = bLoop && Segment.Seconds > 0.0 ? FMath::Fmod(PreviewInspectionElapsed, Segment.Seconds) : PreviewInspectionElapsed;
		Position = Segment.Seconds > 0.0
			? Segment.From + (Segment.To - Segment.From) * FMath::Clamp(Elapsed / Segment.Seconds, 0.0, 1.0) : Segment.From;
	}
	if (ActivePreviewClip != Clip)
	{
		ActivePreviewClip = Clip;
		EditorPreviewMesh->SetAnimationMode(EAnimationMode::AnimationSingleNode, true);
		EditorPreviewMesh->PlayAnimation(Clip, false);
		// Evaluate an explicit position; never set a component/global pause flag for held poses.
		EditorPreviewMesh->SetPlayRate(0.0f);
	}
	EditorPreviewMesh->SetPosition(static_cast<float>(FMath::Clamp(Position, 0.0, 1.0)) * Clip->GetPlayLength(), false);
#endif
}

void AAVSPointOfInterest::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);
#if WITH_EDITORONLY_DATA
	if (!GetWorld() || GetWorld()->IsGameWorld() || !bPreviewAnimationInEditor || !PreviewPlan.Valid)
	{
		return;
	}
	if (bPreviewProfileDriven && bPreviewPlaySequence)
	{
		PreviewPlayback.Advance(DeltaSeconds);
		if (!PreviewPlayback.IsActive())
		{
			if (bRepeatPreviewSequence) PreviewPlayback.Begin(PreviewPlan);
			else
			{
				const int32 ExitIndex = static_cast<int32>(PreviewPlan.Exit.Source);
				UAnimSequenceBase* Clip = ResolvedPreviewClips.IsValidIndex(ExitIndex) ? ResolvedPreviewClips[ExitIndex].Get() : nullptr;
				if (Clip && EditorPreviewMesh)
				{
					if (ActivePreviewClip != Clip)
					{
						ActivePreviewClip = Clip;
						EditorPreviewMesh->PlayAnimation(Clip, false);
						EditorPreviewMesh->SetPlayRate(0.0f);
					}
					EditorPreviewMesh->SetPosition(static_cast<float>(PreviewPlan.Exit.To) * Clip->GetPlayLength(), false);
				}
				SetActorTickEnabled(false);
				return;
			}
		}
	}
	else PreviewInspectionElapsed += AVS::Composed::Safe(DeltaSeconds, 0.0, 0.0, 60.0);
	UpdateEditorPreviewPose();
#endif
}

#if WITH_EDITOR
bool AAVSPointOfInterest::ShouldTickIfViewportsOnly() const
{
	return bPreviewAnimationInEditor && GetWorld() && !GetWorld()->IsGameWorld();
}
#endif

void AAVSPointOfInterest::HandleAutoTriggerBeginOverlap(UPrimitiveComponent* OverlappedComponent,
	AActor* OtherActor, UPrimitiveComponent* OtherComponent, int32 OtherBodyIndex,
	bool bFromSweep, const FHitResult& SweepResult)
{
	if (!bAutoTriggerNearbyNPCs)
	{
		return;
	}
	CompactUsers();
	if (bAutoTriggerOnlyWhenCompletelyClear &&
		(!ReservedUsers.IsEmpty() || !QueuedUsers.IsEmpty() ||
			(GetWorld() && GetWorld()->GetTimeSeconds() < AutoTriggerBlockedUntil)))
	{
		return;
	}
	const float Chance = static_cast<float>(AVS::Composed::Safe(AutoTriggerChance, 0.0, 0.0, 1.0));
	if (Chance <= 0.0f || (Chance < 1.0f && FMath::FRand() >= Chance))
	{
		return;
	}
	AAVSArchvizNPCCharacter* NPC = Cast<AAVSArchvizNPCCharacter>(OtherActor);
	if (!NPC || !NPC->Behavior || NPC->IsHidden())
	{
		return;
	}
	const EAVSNPCState State = NPC->Behavior->GetBehaviorState();
	if (State == EAVSNPCState::AtPointOfInterest || State == EAVSNPCState::Queue ||
		State == EAVSNPCState::Activity || State == EAVSNPCState::Conversation ||
		State == EAVSNPCState::Inactive || State == EAVSNPCState::Paused)
	{
		return;
	}
	if (bAutoTriggerOnlyIdleOrWandering && State != EAVSNPCState::Idle && State != EAVSNPCState::Wander)
	{
		return;
	}
	NPC->Behavior->UsePointOfInterest(this);
}

void AAVSPointOfInterest::CompactUsers()
{
	TSet<AActor*> Removed;
	for (AActor* User : ReservedUsers) if (!IsUsableUser(User)) Removed.Add(User);
	for (AActor* User : QueuedUsers) if (!IsUsableUser(User)) Removed.Add(User);
	for (AActor* User : Removed) Release(User);
}

bool AAVSPointOfInterest::IsUsableUser(const AActor* NPC) const
{
	return IsValid(NPC) && (!Cast<AAVSArchvizNPCCharacter>(NPC) || !NPC->IsHidden());
}

void AAVSPointOfInterest::DetachUserIfUnreferenced(AActor* NPC)
{
	if (IsValid(NPC) && !ReservedUsers.Contains(NPC) && !QueuedUsers.Contains(NPC))
	{
		NPC->OnDestroyed.RemoveDynamic(this, &AAVSPointOfInterest::HandleUserDestroyed);
		NPC->OnEndPlay.RemoveDynamic(this, &AAVSPointOfInterest::HandleUserEndPlay);
	}
}

void AAVSPointOfInterest::HandleUserDestroyed(AActor* NPC)
{
	Release(NPC);
}

void AAVSPointOfInterest::HandleUserEndPlay(AActor* NPC, EEndPlayReason::Type EndPlayReason)
{
	Release(NPC);
}

bool AAVSPointOfInterest::Reserve(AActor* NPC)
{
	CompactUsers();
	if (!IsUsableUser(NPC) || ReservedUsers.Contains(NPC) || ReservedUsers.Num() >= FMath::Max(1, Capacity))
	{
		return ReservedUsers.Contains(NPC);
	}
	ReservedUsers.Add(NPC);
	QueuedUsers.Remove(NPC);
	NPC->OnDestroyed.AddUniqueDynamic(this, &AAVSPointOfInterest::HandleUserDestroyed);
	NPC->OnEndPlay.AddUniqueDynamic(this, &AAVSPointOfInterest::HandleUserEndPlay);
	return true;
}

void AAVSPointOfInterest::Release(AActor* NPC)
{
	const bool bReleasedReservation = ReservedUsers.Remove(NPC) > 0;
	QueuedUsers.Remove(NPC);
	DetachUserIfUnreferenced(NPC);
	if (bReleasedReservation && ReservedUsers.IsEmpty() && GetWorld())
	{
		AutoTriggerBlockedUntil = GetWorld()->GetTimeSeconds() + static_cast<float>(AVS::Composed::Safe(AutoTriggerClearanceAfterUse, 2.5, 0.0, 86400.0));
	}
}

bool AAVSPointOfInterest::JoinQueue(AActor* NPC)
{
	CompactUsers();
	if (!IsUsableUser(NPC) || ReservedUsers.Contains(NPC))
	{
		return false;
	}
	QueuedUsers.AddUnique(NPC);
	NPC->OnDestroyed.AddUniqueDynamic(this, &AAVSPointOfInterest::HandleUserDestroyed);
	NPC->OnEndPlay.AddUniqueDynamic(this, &AAVSPointOfInterest::HandleUserEndPlay);
	return true;
}

void AAVSPointOfInterest::LeaveQueue(AActor* NPC)
{
	QueuedUsers.Remove(NPC);
	DetachUserIfUnreferenced(NPC);
}

int32 AAVSPointOfInterest::GetQueueIndex(AActor* NPC) const
{
	int32 ValidIndex = 0;
	for (int32 Index = 0; Index < QueuedUsers.Num(); ++Index)
	{
		if (!IsUsableUser(QueuedUsers[Index]))
		{
			continue;
		}
		if (QueuedUsers[Index] == NPC)
		{
			return ValidIndex;
		}
		++ValidIndex;
	}
	return INDEX_NONE;
}

bool AAVSPointOfInterest::HasCapacity() const
{
	int32 ValidCount = 0;
	for (const AActor* Actor : ReservedUsers)
	{
		ValidCount += IsUsableUser(Actor) ? 1 : 0;
	}
	return ValidCount < FMath::Max(1, Capacity);
}

FVector AAVSPointOfInterest::GetUseLocation() const
{
	return GetActorTransform().TransformPosition(UseOffset.ContainsNaN() ? FVector::ZeroVector : UseOffset);
}

FVector AAVSPointOfInterest::GetQueueLocation(int32 QueueIndex) const
{
	const float SafeSpacing = static_cast<float>(AVS::Composed::Safe(QueueSpacing, 100.0, 0.0, 100000.0));
	return GetUseLocation() - GetActorForwardVector() * SafeSpacing * static_cast<float>(FMath::Clamp(QueueIndex, -1, 1024) + 1);
}
