#include "AVSArchvizNPCCharacter.h"

#include "AVSAnimationDriverComponent.h"
#include "AIController.h"
#include "BrainComponent.h"
#include "AVSAnimationProfile.h"
#include "AVSArchvizCharacters.h"
#include "AVSArchvizNPCAIController.h"
#include "AVSCharacterProfile.h"
#include "AVSCrowdSubsystem.h"
#include "AVSCrowdGenerator.h"
#include "AVSModularCharacterComponent.h"
#include "AVSNPCBehaviorComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/BillboardComponent.h"
#include "Components/PrimitiveComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/Texture2D.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "UObject/ConstructorHelpers.h"

AAVSArchvizNPCCharacter::AAVSArchvizNPCCharacter()
{
	PrimaryActorTick.bCanEverTick = false;
	AIControllerClass = AAVSArchvizNPCAIController::StaticClass();
	AutoPossessAI = EAutoPossessAI::PlacedInWorldOrSpawned;
	bUseControllerRotationYaw = false;
	GetCharacterMovement()->bOrientRotationToMovement = true;
	GetCharacterMovement()->RotationRate = FRotator(0.0f, 360.0f, 0.0f);
	GetCharacterMovement()->MaxWalkSpeed = 125.0f;
	GetCharacterMovement()->AvoidanceConsiderationRadius = AvoidanceConsiderationRadius;
	GetCharacterMovement()->AvoidanceWeight = AvoidanceWeight;
	GetCharacterMovement()->SetAvoidanceEnabled(bEnableLightweightAvoidance);
	GetCapsuleComponent()->SetCanEverAffectNavigation(false);
	GetMesh()->SetCanEverAffectNavigation(false);

	ModularCharacter = CreateDefaultSubobject<UAVSModularCharacterComponent>(TEXT("ModularCharacter"));
	AnimationDriver = CreateDefaultSubobject<UAVSAnimationDriverComponent>(TEXT("AnimationDriver"));
	Behavior = CreateDefaultSubobject<UAVSNPCBehaviorComponent>(TEXT("Behavior"));

#if WITH_EDITORONLY_DATA
	EditorBillboard = CreateEditorOnlyDefaultSubobject<UBillboardComponent>(TEXT("EditorBillboard"));
	if (EditorBillboard)
	{
		EditorBillboard->SetupAttachment(GetCapsuleComponent());
		EditorBillboard->SetRelativeLocation(FVector(0.0f, 0.0f, 130.0f));
		EditorBillboard->SetHiddenInGame(true);
		EditorBillboard->SetIsVisualizationComponent(true);
		static ConstructorHelpers::FObjectFinder<UTexture2D> Sprite(TEXT("/Engine/EditorResources/S_Actor.S_Actor"));
		if (Sprite.Succeeded())
		{
			EditorBillboard->SetSprite(Sprite.Object);
		}
	}
#endif
}

void AAVSArchvizNPCCharacter::BeginPlay()
{
	Super::BeginPlay();
	if (UWorld* World = GetWorld())
	{
		if (UAVSCrowdSubsystem* Subsystem = World->GetSubsystem<UAVSCrowdSubsystem>())
		{
			Subsystem->RegisterNPC(this);
		}
	}
	if (!DefaultCharacterProfile || !DefaultAnimationProfile || !ApplyProfiles(DefaultCharacterProfile, DefaultAnimationProfile))
	{
		if (!Cast<AAVSCrowdGenerator>(GetOwner()))
			UE_LOG(LogAVSArchvizCharacters, Warning, TEXT("%s remains hidden: configure a compatible Character/Animation Profile pair or controller profile selection before activation."), *GetName());
		SetPooled(true);
	}
}

void AAVSArchvizNPCCharacter::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Behavior->ResetBehavior();
	AnimationDriver->ResetForPool();
	if (UWorld* World = GetWorld())
	{
		if (UAVSCrowdSubsystem* Subsystem = World->GetSubsystem<UAVSCrowdSubsystem>())
		{
			Subsystem->UnregisterNPC(this);
		}
	}
	Super::EndPlay(EndPlayReason);
}

void AAVSArchvizNPCCharacter::InitializeNPC(const FAVSSpawnRequest& Request)
{
	// Pool relocation and profile replacement occur only while invisible and collision-free.
	SetPooled(true);
	SetActorTransform(Request.Transform, false, nullptr, ETeleportType::TeleportPhysics);
	SetOwner(Request.Generator);
	OwningGenerator = Request.Generator;
	if (ApplyProfiles(Request.CharacterProfile, Request.AnimationProfile) && Request.AnimationProfile)
		SetPooled(false);
	else
		UE_LOG(LogAVSArchvizCharacters, Warning, TEXT("%s remains hidden: spawn profile validation failed. Assign compatible body, Idle and Walk clips."), *GetName());
}

bool AAVSArchvizNPCCharacter::ApplyProfiles(UAVSCharacterProfile* CharacterProfile, UAVSAnimationProfile* AnimationProfile)
{
	if (!CharacterProfile)
	{
		return false;
	}

	DefaultCharacterProfile = CharacterProfile;
	const bool bAppearanceApplied = ModularCharacter->ApplyProfile(CharacterProfile);
	if (AnimationProfile && !AnimationProfile->IsCompatibleWithCharacter(CharacterProfile))
	{
		UE_LOG(LogAVSArchvizCharacters, Warning,
			TEXT("%s rejected incompatible profiles. Check sex tag, Rig ID, and target Skeleton."), *GetName());
		DefaultAnimationProfile = nullptr;
		AnimationDriver->ApplyAnimationProfile(nullptr);
		return false;
	}
	if (AnimationProfile)
	{
		DefaultAnimationProfile = AnimationProfile;
		AnimationDriver->ApplyAnimationProfile(AnimationProfile);
	}
	else
	{
		DefaultAnimationProfile = nullptr;
		AnimationDriver->ApplyAnimationProfile(nullptr);
	}
	return bAppearanceApplied;
}

void AAVSArchvizNPCCharacter::SetPooled(bool bPooled)
{
	bIsPooled = bPooled;
	if (bPooled)
	{
		SetActorHiddenInGame(true);
		SetActorEnableCollision(false);
		if (AAIController* AI = Cast<AAIController>(GetController()))
		{
			AI->StopMovement();
			if (UBrainComponent* Brain = AI->GetBrainComponent()) Brain->StopLogic(TEXT("AVS pool return"));
		}
		Behavior->ResetBehavior();
		bQualitySuspended = false;
		StateBeforeQualityPause = EAVSNPCState::Idle;
		AnimationDriver->ResetForPool();
		GetCharacterMovement()->StopMovementImmediately();
		GetCharacterMovement()->DisableMovement();
		GetMesh()->SetComponentTickEnabled(false);
	}
	else
	{
		GetCharacterMovement()->SetMovementMode(MOVE_Walking);
		GetMesh()->bPauseAnims = false;
		GetMesh()->SetComponentTickEnabled(true);
		// Reset stale far-tier intervals and flags before the subsystem applies the current viewer tier.
		ApplyQualityTier(FAVSQualityTier());
		AnimationDriver->ApplyAnimationProfile(DefaultAnimationProfile);
		SetActorEnableCollision(true);
		SetActorHiddenInGame(false);
		if (AAVSArchvizNPCAIController* AI = Cast<AAVSArchvizNPCAIController>(GetController()))
			Behavior->SetExternalBehaviorOwnership(AI->bRunBehaviorTreeOnPossess && AI->BehaviorTreeAsset && AI->RunBehaviorTree(AI->BehaviorTreeAsset));
	}
	SetActorTickEnabled(!bPooled);
	AnimationDriver->SetComponentTickEnabled(!bPooled);
	Behavior->SetComponentTickEnabled(!bPooled);
	GetCharacterMovement()->SetComponentTickEnabled(!bPooled);
	for (USceneComponent* Child : GetMesh()->GetAttachChildren())
		if (USkeletalMeshComponent* Part = Cast<USkeletalMeshComponent>(Child))
		{
			Part->bPauseAnims = bPooled;
			Part->SetComponentTickEnabled(!bPooled);
		}
}

void AAVSArchvizNPCCharacter::ApplyQualityTier(const FAVSQualityTier& Tier)
{
	if (bIsPooled) return;
	const bool bMovementEnabled = Tier.bEnableMovement && Tier.bEnableAnimation && AnimationDriver->HasValidMovementAnimation();
	if (!bMovementEnabled && !bQualitySuspended)
	{
		const EAVSNPCState Previous = Behavior->GetBehaviorState();
		if (Previous != EAVSNPCState::Paused && Previous != EAVSNPCState::Inactive)
		{
			bQualitySuspended = true;
			StateBeforeQualityPause = Previous == EAVSNPCState::Activity || Previous == EAVSNPCState::Conversation ||
				Previous == EAVSNPCState::AtPointOfInterest || Previous == EAVSNPCState::Queue ? EAVSNPCState::Idle : Previous;
			Behavior->SetBehaviorState(EAVSNPCState::Paused);
		}
	}
	else if (bMovementEnabled && bQualitySuspended && !Behavior->HasPendingStateChange())
	{
		bQualitySuspended = false;
		Behavior->SetBehaviorState(StateBeforeQualityPause);
	}
	const bool bDrainExit = AnimationDriver->IsActivityPlaybackActive() || Behavior->HasPendingStateChange();
	const bool bAnimationEnabled = Tier.bEnableAnimation || bDrainExit;
	if (!bMovementEnabled)
	{
		if (AAIController* AI = Cast<AAIController>(GetController())) AI->StopMovement();
		GetCharacterMovement()->StopMovementImmediately();
	}
	Behavior->SetComponentTickInterval(FMath::Max(0.0f, Tier.TickInterval));
	Behavior->SetComponentTickEnabled(bMovementEnabled || bDrainExit);
	AnimationDriver->SetComponentTickInterval(Tier.TickInterval);
	AnimationDriver->SetComponentTickEnabled(bAnimationEnabled);
	GetCharacterMovement()->SetComponentTickEnabled(bMovementEnabled);
	RefreshAvoidanceSettings(bMovementEnabled && Tier.bEnableAvoidance && Tier.bEnableCollision);
	GetCapsuleComponent()->SetCollisionEnabled(Tier.bEnableCollision ? ECollisionEnabled::QueryAndPhysics : ECollisionEnabled::NoCollision);
	GetMesh()->bPauseAnims = !bAnimationEnabled;
	GetMesh()->SetComponentTickEnabled(bAnimationEnabled);
	GetMesh()->bEnableUpdateRateOptimizations = Tier.bUseAnimationUpdateRateOptimization;
	GetMesh()->VisibilityBasedAnimTickOption = Tier.bOnlyTickPoseWhenRendered
		? EVisibilityBasedAnimTickOption::OnlyTickPoseWhenRendered
		: EVisibilityBasedAnimTickOption::AlwaysTickPoseAndRefreshBones;
	GetMesh()->SetForcedLOD(Tier.ForcedLOD);
	GetMesh()->SetCullDistance(Tier.MaxDrawDistance);
	GetMesh()->SetCastShadow(Tier.bCastShadows);
	for (USceneComponent* Child : GetMesh()->GetAttachChildren())
	{
		if (UPrimitiveComponent* Primitive = Cast<UPrimitiveComponent>(Child))
		{
			Primitive->SetCastShadow(Tier.bCastShadows);
			Primitive->SetCullDistance(Tier.MaxDrawDistance);
		}
		if (USkeletalMeshComponent* SkeletalPart = Cast<USkeletalMeshComponent>(Child))
		{
			SkeletalPart->bPauseAnims = !bAnimationEnabled;
			SkeletalPart->SetComponentTickEnabled(bAnimationEnabled);
			SkeletalPart->bEnableUpdateRateOptimizations = Tier.bUseAnimationUpdateRateOptimization;
			SkeletalPart->VisibilityBasedAnimTickOption = Tier.bOnlyTickPoseWhenRendered
				? EVisibilityBasedAnimTickOption::OnlyTickPoseWhenRendered
				: EVisibilityBasedAnimTickOption::AlwaysTickPoseAndRefreshBones;
			SkeletalPart->SetForcedLOD(Tier.ForcedLOD);
		}
	}
}

void AAVSArchvizNPCCharacter::RefreshAvoidanceSettings(bool bQualityAllowsAvoidance)
{
	if (UCharacterMovementComponent* Movement = GetCharacterMovement())
	{
		Movement->AvoidanceConsiderationRadius = FMath::Max(50.0f, AvoidanceConsiderationRadius);
		Movement->AvoidanceWeight = FMath::Clamp(AvoidanceWeight, 0.0f, 1.0f);
		Movement->SetAvoidanceEnabled(bEnableLightweightAvoidance && bQualityAllowsAvoidance);
	}
}
