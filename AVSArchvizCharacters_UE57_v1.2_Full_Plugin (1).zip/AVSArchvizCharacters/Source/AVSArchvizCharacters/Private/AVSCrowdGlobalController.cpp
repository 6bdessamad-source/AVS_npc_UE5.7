#include "AVSCrowdGlobalController.h"

#include "AVSCrowdExclusionMask.h"
#include "AVSCrowdSubsystem.h"
#include "Components/BillboardComponent.h"
#include "Components/PrimitiveComponent.h"
#include "Components/SceneComponent.h"
#include "Engine/Texture2D.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "GameFramework/Volume.h"
#include "UObject/ConstructorHelpers.h"

AAVSCrowdGlobalController::AAVSCrowdGlobalController()
{
	PrimaryActorTick.bCanEverTick = false;
	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	SetRootComponent(SceneRoot);

#if WITH_EDITORONLY_DATA
	EditorBillboard = CreateEditorOnlyDefaultSubobject<UBillboardComponent>(TEXT("EditorBillboard"));
	if (EditorBillboard)
	{
		EditorBillboard->SetupAttachment(SceneRoot);
		EditorBillboard->SetHiddenInGame(true);
		EditorBillboard->SetIsVisualizationComponent(true);
		static ConstructorHelpers::FObjectFinder<UTexture2D> Sprite(TEXT("/Engine/EditorResources/S_Actor.S_Actor"));
		if (Sprite.Succeeded())
		{
			EditorBillboard->SetSprite(Sprite.Object);
		}
	}
#endif

	BuildPreset(EAVSGlobalQualityPreset::Balanced);

#if WITH_EDITORONLY_DATA
	RetargetOutputFolder.Path = TEXT("/Game/AVS/GeneratedRetargeted");
#endif
}

FAVSRetargetRequestDelegate& AAVSCrowdGlobalController::OnRetargetRequested()
{
	static FAVSRetargetRequestDelegate Delegate;
	return Delegate;
}

void AAVSCrowdGlobalController::ExecuteOneClickSceneRetarget()
{
#if WITH_EDITOR
	LastRetargetReport = TEXT("Retarget scan started...");
	OnRetargetRequested().Broadcast(this, false);
	if (!OnRetargetRequested().IsBound())
	{
		LastRetargetReport = TEXT("The AVS editor module is not loaded. Restart the editor and confirm the plugin's Editor module is enabled.");
	}
#endif
}

void AAVSCrowdGlobalController::UpdateGeneratedRetargets()
{
#if WITH_EDITOR
	LastRetargetReport = TEXT("Retarget update started...");
	OnRetargetRequested().Broadcast(this, true);
	if (!OnRetargetRequested().IsBound())
	{
		LastRetargetReport = TEXT("The AVS editor module is not loaded. Restart the editor and confirm the plugin's Editor module is enabled.");
	}
#endif
}

void AAVSCrowdGlobalController::BeginPlay()
{
	Super::BeginPlay();
	if (UAVSCrowdSubsystem* Subsystem = GetWorld()->GetSubsystem<UAVSCrowdSubsystem>())
	{
		Subsystem->RegisterGlobalController(this);
	}
}

void AAVSCrowdGlobalController::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (GetWorld())
	{
		if (UAVSCrowdSubsystem* Subsystem = GetWorld()->GetSubsystem<UAVSCrowdSubsystem>())
		{
			Subsystem->UnregisterGlobalController(this);
		}
	}
	Super::EndPlay(EndPlayReason);
}

void AAVSCrowdGlobalController::ApplySelectedQualityPreset()
{
	if (QualityPreset != EAVSGlobalQualityPreset::Custom)
	{
		BuildPreset(QualityPreset);
	}
}

void AAVSCrowdGlobalController::ApplyNavigationCollisionChannelFilter()
{
#if WITH_EDITOR
	UWorld* World = GetWorld();
	if (!World)
	{
		LastNavigationFilterReport = TEXT("No editor World is available.");
		return;
	}

	int32 ScannedComponents = 0;
	int32 DisabledComponents = 0;
	int32 BlockingComponents = 0;
	for (TActorIterator<AActor> ActorIterator(World); ActorIterator; ++ActorIterator)
	{
		AActor* Actor = *ActorIterator;
		if (!IsValid(Actor) || Actor == this || Actor->HasAnyFlags(RF_Transient) ||
			Actor->IsA<AVolume>() || Actor->IsA<AAVSCrowdExclusionMask>())
		{
			continue;
		}

		TInlineComponentArray<UPrimitiveComponent*> PrimitiveComponents;
		Actor->GetComponents(PrimitiveComponents);
		bool bChangedActor = false;
		for (UPrimitiveComponent* Primitive : PrimitiveComponents)
		{
			if (!IsValid(Primitive) || !Primitive->CanEverAffectNavigation())
			{
				continue;
			}
			++ScannedComponents;
			if (Primitive->GetCollisionResponseToChannel(NavigationGeometryChannel) == ECR_Block)
			{
				++BlockingComponents;
				continue;
			}

			Primitive->Modify();
			Primitive->SetCanEverAffectNavigation(false);
			++DisabledComponents;
			bChangedActor = true;
		}
		if (bChangedActor)
		{
			Actor->Modify();
			Actor->MarkPackageDirty();
		}
	}

	LastNavigationFilterReport = FString::Printf(
		TEXT("Scanned %d navigation-relevant primitive components. Kept %d that Block channel %s; disabled navigation relevance on %d. This operation never enables components."),
		ScannedComponents,
		BlockingComponents,
		*UEnum::GetValueAsString(NavigationGeometryChannel.GetValue()),
		DisabledComponents);
#endif
}

void AAVSCrowdGlobalController::BuildPreset(EAVSGlobalQualityPreset Preset)
{
	QualityTiers.Reset();
	bAllowCollision = true;
	bAllowLightweightAvoidance = true;
	bEnableAnimationUpdateRateOptimization = true;
	bOptimizeRepeatedPathRequests = true;
	GlobalMaxDrawDistance = 0.0f;

	FAVSQualityTier Near;
	FAVSQualityTier Medium;
	FAVSQualityTier Far;

	switch (Preset)
	{
	case EAVSGlobalQualityPreset::Cinematic:
		DensityScale = 1.25f;
		MaxActiveNPCs = 200;
		WarmPoolSize = 24;
		EvaluationInterval = 0.2f;
		MinimumPathRequestInterval = 0.75f;
		PathDestinationChangeThreshold = 75.0f;
		bAllowShadows = true;
		Near.MaxDistance = 6000.0f;
		Near.TickInterval = 0.03f;
		Medium.MaxDistance = 14000.0f;
		Medium.TickInterval = 0.1f;
		Far.MaxDistance = 24000.0f;
		Far.TickInterval = 0.35f;
		Far.bCastShadows = false;
		Far.bOnlyTickPoseWhenRendered = true;
		Far.bEnableAvoidance = false;
		break;

	case EAVSGlobalQualityPreset::High:
		DensityScale = 1.0f;
		MaxActiveNPCs = 150;
		WarmPoolSize = 18;
		EvaluationInterval = 0.35f;
		MinimumPathRequestInterval = 1.0f;
		PathDestinationChangeThreshold = 100.0f;
		bAllowShadows = true;
		Near.MaxDistance = 5000.0f;
		Near.TickInterval = 0.05f;
		Medium.MaxDistance = 11000.0f;
		Medium.TickInterval = 0.18f;
		Medium.bCastShadows = false;
		Far.MaxDistance = 19000.0f;
		Far.TickInterval = 0.5f;
		Far.bCastShadows = false;
		Far.bOnlyTickPoseWhenRendered = true;
		Far.bEnableAvoidance = false;
		break;

	case EAVSGlobalQualityPreset::Performance:
		DensityScale = 0.45f;
		MaxActiveNPCs = 60;
		WarmPoolSize = 8;
		EvaluationInterval = 0.75f;
		MinimumPathRequestInterval = 2.5f;
		PathDestinationChangeThreshold = 250.0f;
		bAllowShadows = false;
		bAllowCollision = false;
		bAllowLightweightAvoidance = false;
		GlobalMaxDrawDistance = 13000.0f;
		Near.MaxDistance = 3000.0f;
		Near.TickInterval = 0.1f;
		Near.bCastShadows = false;
		Medium.MaxDistance = 7000.0f;
		Medium.TickInterval = 0.4f;
		Medium.bCastShadows = false;
		Medium.bEnableCollision = false;
		Medium.bOnlyTickPoseWhenRendered = true;
		Medium.ForcedLOD = 2;
		Far.MaxDistance = 13000.0f;
		Far.TickInterval = 1.0f;
		Far.bEnableMovement = false;
		Far.bEnableAnimation = false;
		Far.bCastShadows = false;
		Far.bEnableCollision = false;
		Far.bEnableAvoidance = false;
		Far.bOnlyTickPoseWhenRendered = true;
		Far.ForcedLOD = 3;
		Far.MaxDrawDistance = 13000.0f;
		break;

	case EAVSGlobalQualityPreset::Balanced:
	default:
		DensityScale = 0.75f;
		MaxActiveNPCs = 100;
		WarmPoolSize = 12;
		EvaluationInterval = 0.5f;
		MinimumPathRequestInterval = 1.5f;
		PathDestinationChangeThreshold = 150.0f;
		bAllowShadows = true;
		Near.MaxDistance = 4000.0f;
		Near.TickInterval = 0.05f;
		Medium.MaxDistance = 9000.0f;
		Medium.TickInterval = 0.25f;
		Medium.bCastShadows = false;
		Medium.bOnlyTickPoseWhenRendered = true;
		Medium.ForcedLOD = 2;
		Far.MaxDistance = 16000.0f;
		Far.TickInterval = 0.75f;
		Far.bEnableMovement = false;
		Far.bCastShadows = false;
		Far.bEnableCollision = false;
		Far.bEnableAvoidance = false;
		Far.bOnlyTickPoseWhenRendered = true;
		Far.ForcedLOD = 3;
		Far.MaxDrawDistance = 16000.0f;
		break;
	}

	QualityTiers.Add(Near);
	QualityTiers.Add(Medium);
	QualityTiers.Add(Far);
}

void AAVSCrowdGlobalController::SetGlobalCrowdEnabled(bool bEnabled)
{
	bCrowdEnabled = bEnabled;
}

void AAVSCrowdGlobalController::SetGlobalDensityScale(float NewScale)
{
	DensityScale = FMath::Clamp(NewScale, 0.0f, 2.0f);
}

void AAVSCrowdGlobalController::ClearAllGeneratedCrowds()
{
	if (UWorld* World = GetWorld())
	{
		if (UAVSCrowdSubsystem* Subsystem = World->GetSubsystem<UAVSCrowdSubsystem>())
		{
			Subsystem->ClearAllGeneratedCrowds();
		}
	}
}

int32 AAVSCrowdGlobalController::GetActiveNPCCount() const
{
	if (UWorld* World = GetWorld())
	{
		if (const UAVSCrowdSubsystem* Subsystem = World->GetSubsystem<UAVSCrowdSubsystem>())
		{
			return Subsystem->GetActiveNPCCount();
		}
	}
	return 0;
}

int32 AAVSCrowdGlobalController::GetPooledNPCCount() const
{
	if (UWorld* World = GetWorld())
	{
		if (const UAVSCrowdSubsystem* Subsystem = World->GetSubsystem<UAVSCrowdSubsystem>())
		{
			return Subsystem->GetPooledNPCCount();
		}
	}
	return 0;
}
