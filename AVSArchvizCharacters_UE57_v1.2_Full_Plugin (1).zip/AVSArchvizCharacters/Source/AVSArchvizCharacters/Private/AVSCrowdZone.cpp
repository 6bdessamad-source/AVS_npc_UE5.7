#include "AVSCrowdZone.h"

#include "AVSArchvizNPCCharacter.h"
#include "AVSCrowdRoute.h"
#include "AVSNPCBehaviorComponent.h"
#include "Components/BoxComponent.h"
#include "Components/SplineComponent.h"
#include "DrawDebugHelpers.h"
#include "EngineUtils.h"
#include "NavigationSystem.h"

AAVSCrowdZone::AAVSCrowdZone()
{
	SpawnVolume = CreateDefaultSubobject<UBoxComponent>(TEXT("SpawnVolume"));
	SpawnVolume->SetupAttachment(SceneRoot);
	SpawnVolume->SetBoxExtent(FVector(1000.0f, 1000.0f, 200.0f));
	SpawnVolume->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	SpawnVolume->SetHiddenInGame(true);
}

void AAVSCrowdZone::BeginPlay()
{
	Super::BeginPlay();
	RefreshContainedRoutes();
}

bool AAVSCrowdZone::ContainsWorldLocation(const FVector& Location) const
{
	if (!SpawnVolume)
	{
		return false;
	}
	const FVector Local = SpawnVolume->GetComponentTransform().InverseTransformPosition(Location);
	const FVector Extent = SpawnVolume->GetUnscaledBoxExtent();
	return FMath::Abs(Local.X) <= Extent.X && FMath::Abs(Local.Y) <= Extent.Y && FMath::Abs(Local.Z) <= Extent.Z;
}

void AAVSCrowdZone::RefreshContainedRoutes()
{
	CachedRouteChoices.Reset();
	for (const FAVSZoneRouteChoice& Choice : RouteChoices)
	{
		if (IsValid(Choice.Route) && Choice.Weight > 0.0f)
		{
			CachedRouteChoices.Add(Choice);
		}
	}

	if (!bAutoDiscoverContainedRoutes || !GetWorld())
	{
		return;
	}

	for (TActorIterator<AAVSCrowdRoute> It(GetWorld()); It; ++It)
	{
		AAVSCrowdRoute* Candidate = *It;
		const bool bAlreadyListed = CachedRouteChoices.ContainsByPredicate(
			[Candidate](const FAVSZoneRouteChoice& Choice) { return Choice.Route == Candidate; });
		if (!Candidate || bAlreadyListed || !Candidate->CanConnectCrowdZones())
		{
			continue;
		}
		if (!Candidate->RouteSpline)
		{
			continue;
		}
		const float RouteLength = Candidate->RouteSpline->GetSplineLength();
		const int32 SampleCount = FMath::Max(1, FMath::CeilToInt(RouteLength / FMath::Max(25.0f, RouteDetectionSampleSpacing)));
		for (int32 PointIndex = 0; PointIndex <= SampleCount; ++PointIndex)
		{
			const float Distance = RouteLength * static_cast<float>(PointIndex) / static_cast<float>(SampleCount);
			const FVector Sample = Candidate->RouteSpline->GetLocationAtDistanceAlongSpline(Distance, ESplineCoordinateSpace::World);
			if (ContainsWorldLocation(Sample))
			{
				FAVSZoneRouteChoice Choice;
				Choice.Route = Candidate;
				Choice.Weight = 1.0f;
				Choice.bLoop = Candidate->bLoopRoute;
				CachedRouteChoices.Add(Choice);
				break;
			}
		}
	}
}

const FAVSZoneRouteChoice* AAVSCrowdZone::SelectRouteChoice(const AAVSArchvizNPCCharacter* NPC)
{
	float TotalWeight = 0.0f;
	const FAVSZoneRouteChoice* LastValid = nullptr;
	for (const FAVSZoneRouteChoice& Choice : CachedRouteChoices)
	{
		if (IsValid(Choice.Route) && Choice.Weight > 0.0f && NPC &&
			Choice.Route->SupportsProfiles(NPC->DefaultCharacterProfile, NPC->DefaultAnimationProfile))
		{
			TotalWeight += Choice.Weight;
			LastValid = &Choice;
		}
	}
	if (TotalWeight <= 0.0f)
	{
		return nullptr;
	}

	float Pick = RandomStream.FRandRange(0.0f, TotalWeight);
	for (const FAVSZoneRouteChoice& Choice : CachedRouteChoices)
	{
		if (!IsValid(Choice.Route) || Choice.Weight <= 0.0f || !NPC ||
			!Choice.Route->SupportsProfiles(NPC->DefaultCharacterProfile, NPC->DefaultAnimationProfile))
		{
			continue;
		}
		Pick -= Choice.Weight;
		if (Pick <= 0.0f)
		{
			return &Choice;
		}
	}
	return LastValid;
}

bool AAVSCrowdZone::MakeSpawnTransform(int32 NPCIndex, FTransform& OutTransform)
{
	const FVector Extent = SpawnVolume->GetScaledBoxExtent();
	const FVector LocalPoint(
		RandomStream.FRandRange(-Extent.X, Extent.X),
		RandomStream.FRandRange(-Extent.Y, Extent.Y),
		0.0f);
	FVector WorldPoint = SpawnVolume->GetComponentLocation() + SpawnVolume->GetComponentQuat().RotateVector(LocalPoint);
	if (bProjectToNavMesh)
	{
		UNavigationSystemV1* Nav = FNavigationSystem::GetCurrent<UNavigationSystemV1>(GetWorld());
		FNavLocation Projected;
		if (!Nav || !Nav->ProjectPointToNavigation(WorldPoint, Projected, NavProjectionExtent))
		{
			return false;
		}
		WorldPoint = Projected.Location;
	}
	OutTransform = FTransform(FRotator(0.0f, RandomStream.FRandRange(-180.0f, 180.0f), 0.0f), WorldPoint);
	return true;
}

void AAVSCrowdZone::ConfigureSpawnedNPC(AAVSArchvizNPCCharacter* NPC, int32 NPCIndex)
{
	if (!NPC || !NPC->Behavior)
	{
		return;
	}
	NPC->Behavior->SetWanderArea(NPC->GetActorLocation(), WanderRadius);
	if (RandomStream.FRand() < FMath::Clamp(RouteDecisionChance, 0.0f, 1.0f))
	{
		if (const FAVSZoneRouteChoice* Choice = SelectRouteChoice(NPC))
		{
			NPC->Behavior->FollowRouteWithCompletion(Choice->Route, Choice->bLoop, EAVSNPCState::Wander);
			return;
		}
	}
	if (RandomStream.FRandRange(0.0f, 100.0f) >= FMath::Clamp(IdlePercentageWeight, 0.0f, 100.0f))
	{
		NPC->Behavior->StartWandering(NPC->GetActorLocation(), WanderRadius);
	}
	else
	{
		NPC->Behavior->SetBehaviorState(EAVSNPCState::Idle);
	}
}

void AAVSCrowdZone::AcceptConnectorArrival(AAVSArchvizNPCCharacter* NPC)
{
	if (NPC && NPC->Behavior)
	{
		NPC->Behavior->StartWandering(NPC->GetActorLocation(), WanderRadius);
	}
}

void AAVSCrowdZone::DrawGeneratorDebug(const FAVSViewerState& ViewerState) const
{
	Super::DrawGeneratorDebug(ViewerState);
	DrawDebugBox(GetWorld(), SpawnVolume->GetComponentLocation(), SpawnVolume->GetScaledBoxExtent(), SpawnVolume->GetComponentQuat(), FColor::Yellow, false, 0.6f, 0, 3.0f);
}
