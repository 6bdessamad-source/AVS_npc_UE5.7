#include "AVSCrowdExclusionMask.h"

#include "AVSCrowdSubsystem.h"
#include "AVSArchvizTypes.h"
#include "Components/BillboardComponent.h"
#include "Components/BoxComponent.h"
#include "Components/SceneComponent.h"
#include "Components/SplineComponent.h"
#include "Engine/Texture2D.h"
#include "UObject/ConstructorHelpers.h"

namespace
{
	bool SegmentsIntersect2D(const FVector2D& A, const FVector2D& B, const FVector2D& C, const FVector2D& D)
	{
		auto Cross = [](const FVector2D& U, const FVector2D& V)
		{
			return U.X * V.Y - U.Y * V.X;
		};
		const FVector2D R = B - A;
		const FVector2D S = D - C;
		const float Denominator = Cross(R, S);
		if (FMath::IsNearlyZero(Denominator))
		{
			return false;
		}
		const float T = Cross(C - A, S) / Denominator;
		const float U = Cross(C - A, R) / Denominator;
		return T >= 0.0f && T <= 1.0f && U >= 0.0f && U <= 1.0f;
	}
}

AAVSCrowdExclusionMask::AAVSCrowdExclusionMask()
{
	PrimaryActorTick.bCanEverTick = false;
	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	SetRootComponent(SceneRoot);
	SceneRoot->SetMobility(EComponentMobility::Static);

	MaskSpline = CreateDefaultSubobject<USplineComponent>(TEXT("MaskSpline"));
	MaskSpline->SetupAttachment(SceneRoot);
	MaskSpline->SetMobility(EComponentMobility::Static);
	MaskSpline->SetClosedLoop(true);

	MaskBox = CreateDefaultSubobject<UBoxComponent>(TEXT("MaskBox"));
	MaskBox->SetupAttachment(SceneRoot);
	MaskBox->SetMobility(EComponentMobility::Static);
	MaskBox->SetBoxExtent(FVector(300.0f, 300.0f, 200.0f));
	MaskBox->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	MaskBox->SetHiddenInGame(true);

#if WITH_EDITORONLY_DATA
	EditorBillboard = CreateEditorOnlyDefaultSubobject<UBillboardComponent>(TEXT("EditorBillboard"));
	if (EditorBillboard)
	{
		EditorBillboard->SetupAttachment(SceneRoot);
		EditorBillboard->SetHiddenInGame(true);
		EditorBillboard->SetIsVisualizationComponent(true);
		static ConstructorHelpers::FObjectFinder<UTexture2D> Sprite(TEXT("/Engine/EditorResources/S_Note.S_Note"));
		if (Sprite.Succeeded())
		{
			EditorBillboard->SetSprite(Sprite.Object);
		}
	}
#endif
}

void AAVSCrowdExclusionMask::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);
	RebuildBoundary();
}

void AAVSCrowdExclusionMask::BeginPlay()
{
	Super::BeginPlay();
	RebuildBoundary();
	if (UAVSCrowdSubsystem* Subsystem = GetWorld()->GetSubsystem<UAVSCrowdSubsystem>())
	{
		Subsystem->RegisterExclusionMask(this);
	}
}

void AAVSCrowdExclusionMask::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (GetWorld())
	{
		if (UAVSCrowdSubsystem* Subsystem = GetWorld()->GetSubsystem<UAVSCrowdSubsystem>())
		{
			Subsystem->UnregisterExclusionMask(this);
		}
	}
	Super::EndPlay(EndPlayReason);
}

void AAVSCrowdExclusionMask::GetPolygonPoints(TArray<FVector>& OutPoints) const
{
	OutPoints.Reset();
	if (Shape == EAVSExclusionMaskShape::Box && MaskBox)
	{
		const FVector Extent = MaskBox->GetUnscaledBoxExtent();
		const FTransform Transform = MaskBox->GetComponentTransform();
		OutPoints.Add(Transform.TransformPosition(FVector(-Extent.X, -Extent.Y, 0.0f)));
		OutPoints.Add(Transform.TransformPosition(FVector( Extent.X, -Extent.Y, 0.0f)));
		OutPoints.Add(Transform.TransformPosition(FVector( Extent.X,  Extent.Y, 0.0f)));
		OutPoints.Add(Transform.TransformPosition(FVector(-Extent.X,  Extent.Y, 0.0f)));
		return;
	}
	if (!MaskSpline || MaskSpline->GetNumberOfSplinePoints() < 3)
	{
		return;
	}
	const float Length = MaskSpline->GetSplineLength();
	const int32 SampleCount = FMath::Max(3, FMath::CeilToInt(Length / FMath::Max(25.0f, BoundarySampleSpacing)));
	for (int32 Index = 0; Index < SampleCount; ++Index)
	{
		const float Distance = Length * static_cast<float>(Index) / static_cast<float>(SampleCount);
		OutPoints.Add(MaskSpline->GetLocationAtDistanceAlongSpline(Distance, ESplineCoordinateSpace::World));
	}
}

bool AAVSCrowdExclusionMask::ContainsWorldLocation(const FVector& WorldLocation) const
{
	if (Shape == EAVSExclusionMaskShape::Box && MaskBox)
	{
		const FVector Local = MaskBox->GetComponentTransform().InverseTransformPosition(WorldLocation);
		const FVector Extent = MaskBox->GetUnscaledBoxExtent();
		return FMath::Abs(Local.X) <= Extent.X && FMath::Abs(Local.Y) <= Extent.Y && FMath::Abs(Local.Z) <= Extent.Z;
	}

	const float MinZ = GetActorLocation().Z + FMath::Min(MinHeightOffset, MaxHeightOffset);
	const float MaxZ = GetActorLocation().Z + FMath::Max(MinHeightOffset, MaxHeightOffset);
	if (WorldLocation.Z < MinZ || WorldLocation.Z > MaxZ)
	{
		return false;
	}

	TArray<FVector> Polygon;
	GetPolygonPoints(Polygon);
	if (Polygon.Num() < 3)
	{
		return false;
	}

	bool bInside = false;
	for (int32 I = 0, J = Polygon.Num() - 1; I < Polygon.Num(); J = I++)
	{
		const FVector& Pi = Polygon[I];
		const FVector& Pj = Polygon[J];
		const bool bCrosses = ((Pi.Y > WorldLocation.Y) != (Pj.Y > WorldLocation.Y)) &&
			(WorldLocation.X < (Pj.X - Pi.X) * (WorldLocation.Y - Pi.Y) / (Pj.Y - Pi.Y + UE_SMALL_NUMBER) + Pi.X);
		if (bCrosses)
		{
			bInside = !bInside;
		}
	}
	return bInside;
}

bool AAVSCrowdExclusionMask::IntersectsWorldSegment(const FVector& SegmentStart, const FVector& SegmentEnd) const
{
	if (ContainsWorldLocation(SegmentStart) || ContainsWorldLocation(SegmentEnd))
	{
		return true;
	}
	TArray<FVector> Polygon;
	GetPolygonPoints(Polygon);
	for (int32 Index = 0; Index < Polygon.Num(); ++Index)
	{
		const FVector& A = Polygon[Index];
		const FVector& B = Polygon[(Index + 1) % Polygon.Num()];
		if (SegmentsIntersect2D(
			FVector2D(SegmentStart.X, SegmentStart.Y), FVector2D(SegmentEnd.X, SegmentEnd.Y),
			FVector2D(A.X, A.Y), FVector2D(B.X, B.Y)))
		{
			return true;
		}
	}
	return false;
}

void AAVSCrowdExclusionMask::RebuildBoundary()
{
	for (UBoxComponent* Component : BoundaryComponents)
	{
		if (IsValid(Component))
		{
			Component->DestroyComponent();
		}
	}
	BoundaryComponents.Reset();
	if (MaskSpline)
	{
		MaskSpline->SetVisibility(Shape == EAVSExclusionMaskShape::Spline, true);
	}
	if (MaskBox)
	{
		MaskBox->SetVisibility(Shape == EAVSExclusionMaskShape::Box, true);
		const bool bUseBoxCollision = Shape == EAVSExclusionMaskShape::Box && bBuildCollisionBoundary;
		MaskBox->SetCollisionObjectType(ECC_WorldStatic);
		MaskBox->SetCollisionEnabled(bUseBoxCollision ? ECollisionEnabled::QueryAndPhysics : ECollisionEnabled::NoCollision);
		MaskBox->SetCollisionResponseToAllChannels(ECR_Ignore);
		MaskBox->SetCollisionResponseToChannel(ECC_Pawn, ECR_Block);
		MaskBox->SetCanEverAffectNavigation(bUseBoxCollision && bAffectNavigation);
	}
	if (!bBuildCollisionBoundary)
	{
		return;
	}
	if (Shape == EAVSExclusionMaskShape::Box)
	{
		return;
	}

	TArray<FVector> Polygon;
	GetPolygonPoints(Polygon);
	if (Polygon.Num() < 3)
	{
		return;
	}

	const float MinZ = GetActorLocation().Z + FMath::Min(MinHeightOffset, MaxHeightOffset);
	const float MaxZ = GetActorLocation().Z + FMath::Max(MinHeightOffset, MaxHeightOffset);
	const float Height = FMath::Max(50.0f, MaxZ - MinZ);
	for (int32 Index = 0; Index < Polygon.Num(); ++Index)
	{
		FVector Start = Polygon[Index];
		FVector End = Polygon[(Index + 1) % Polygon.Num()];
		const float Length = FVector::Dist2D(Start, End);
		if (Length <= UE_SMALL_NUMBER)
		{
			continue;
		}

		UBoxComponent* Boundary = NewObject<UBoxComponent>(this);
		AddInstanceComponent(Boundary);
		Boundary->SetupAttachment(SceneRoot);
		Boundary->SetMobility(SceneRoot ? SceneRoot->GetMobility() : EComponentMobility::Movable);
		Boundary->RegisterComponent();
		Boundary->SetWorldLocation(FVector((Start.X + End.X) * 0.5f, (Start.Y + End.Y) * 0.5f, (MinZ + MaxZ) * 0.5f));
		Boundary->SetWorldRotation(FRotator(0.0f, (End - Start).Rotation().Yaw, 0.0f));
		Boundary->SetBoxExtent(FVector(Length * 0.5f, FMath::Max(5.0f, BoundaryThickness * 0.5f), Height * 0.5f));
		Boundary->SetCollisionObjectType(ECC_WorldStatic);
		Boundary->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
		Boundary->SetCollisionResponseToAllChannels(ECR_Ignore);
		Boundary->SetCollisionResponseToChannel(ECC_Pawn, ECR_Block);
		Boundary->SetCanEverAffectNavigation(bAffectNavigation);
		Boundary->SetHiddenInGame(true);
		BoundaryComponents.Add(Boundary);
	}
}
