#include "AVSResolvedAnimation.h"
#include "AVSAnimationProfile.h"
#include "Animation/AnimSequenceBase.h"

FAVSResolvedAnimation AVSResolveAnimation(const UAVSAnimationProfile* Profile, const FAVSNamedAnimation& Entry,
    const USkeleton* Skeleton, const FAVSResolveSettings& Settings)
{
    FAVSResolvedAnimation Result;
    // Never treat an unconfigured target as a wildcard at actual playback/preview.
    if (!Profile || !Skeleton || Profile->TargetSkeleton.LoadSynchronous() != Skeleton) return Result;
    auto Compatible = [Skeleton](UAnimSequenceBase* Clip)
    {
        return Clip && Clip->GetSkeleton() == Skeleton && Clip->GetPlayLength() > 0 ? Clip : nullptr;
    };
    Result.Start = Compatible(Entry.StartAnimation.LoadSynchronous());
    Result.Main = Compatible(Entry.Animation.LoadSynchronous());
    Result.End = Compatible(Entry.EndAnimation.LoadSynchronous());
    AVS::Composed::Clips Clips;
    Clips.Start = Result.Start ? Result.Start->GetPlayLength() : 0;
    Clips.Main = Result.Main ? Result.Main->GetPlayLength() : 0;
    Clips.End = Result.End ? Result.End->GetPlayLength() : 0;
    AVS::Composed::Options Options;
    Options.Smart = Profile->bEnableSmartMissingTransitionFallback;
    Options.Reverse = Profile->bEnableReverseTransitionFallback && Entry.bAllowReverseTransitionFallback && Settings.bAllowReverse;
    Options.Hold = Profile->bEnableHoldPoseFallback && Entry.bAllowHoldPoseFallback && Settings.bAllowHold;
    Options.HoldPosition = Settings.HoldPosition != -1 ? Settings.HoldPosition : Entry.HoldPoseNormalizedPosition;
    Options.Loop = Settings.bOverrideLoop ? Settings.bLoop : Entry.bLoop;
    Options.Rate = Entry.PlayRate;
    Options.Duration = Settings.Duration;
    Result.Plan = AVS::Composed::Resolve(Clips, Options);
    for (const AVS::Composed::Segment* Segment : { &Result.Plan.Entry, &Result.Plan.Exit })
    {
        if (Segment->Rate < 0 && !Entry.bAllowReverseRootMotion)
            if (UAnimSequenceBase* Clip = Result.GetClip(Segment->Source); Clip && Clip->HasRootMotion())
                Result.Plan.Valid = false;
    }
    // Locomotion and standing Idle always require a real main clip. A seated hold cannot be walking/standing.
    if ((Entry.Slot == EAVSAnimationSlot::Walk || Entry.Slot == EAVSAnimationSlot::Run || Entry.Slot == EAVSAnimationSlot::Idle) && !Result.Main)
        Result.Plan.Valid = false;
    return Result;
}
