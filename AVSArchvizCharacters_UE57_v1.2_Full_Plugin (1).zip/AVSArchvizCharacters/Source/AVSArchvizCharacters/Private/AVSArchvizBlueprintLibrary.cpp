#include "AVSArchvizBlueprintLibrary.h"

#include "AVSAnimationProfile.h"
#include "AVSCharacterProfile.h"
#include "AVSCrowdSubsystem.h"
#include "Engine/Engine.h"
#include "Engine/SkeletalMesh.h"

UAVSCrowdSubsystem* UAVSArchvizBlueprintLibrary::GetAVSCrowdSubsystem(const UObject* WorldContextObject)
{
	if (!GEngine || !WorldContextObject)
	{
		return nullptr;
	}
	if (UWorld* World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull))
	{
		return World->GetSubsystem<UAVSCrowdSubsystem>();
	}
	return nullptr;
}

bool UAVSArchvizBlueprintLibrary::DoMeshesUseSameSkeleton(const USkeletalMesh* A, const USkeletalMesh* B)
{
	return A && B && A->GetSkeleton() && A->GetSkeleton() == B->GetSkeleton();
}

bool UAVSArchvizBlueprintLibrary::ValidateCharacterProfile(const UAVSCharacterProfile* Profile, TArray<FText>& OutIssues)
{
	if (!Profile)
	{
		OutIssues.Reset();
		OutIssues.Add(NSLOCTEXT("AVS", "InvalidCharacterProfile", "Character Profile is null."));
		return false;
	}
	return Profile->ValidateProfile(OutIssues);
}

bool UAVSArchvizBlueprintLibrary::ValidateAnimationProfile(const UAVSAnimationProfile* Profile, TArray<FText>& OutIssues)
{
	if (!Profile)
	{
		OutIssues.Reset();
		OutIssues.Add(NSLOCTEXT("AVS", "InvalidAnimationProfile", "Animation Profile is null."));
		return false;
	}
	return Profile->ValidateProfile(OutIssues);
}

FString UAVSArchvizBlueprintLibrary::GetCrowdDebugSummary(const UObject* WorldContextObject)
{
	UAVSCrowdSubsystem* Subsystem = GetAVSCrowdSubsystem(WorldContextObject);
	if (!Subsystem)
	{
		return TEXT("AVS Crowd Subsystem unavailable.");
	}
	FAVSViewerState Viewer;
	const bool bHasViewer = Subsystem->GetPrimaryViewerState(Viewer);
	return FString::Printf(
		TEXT("Viewer: %s | Mode: %s | Zoom: %.0f | Crowd: %s | Active NPCs: %d | Pooled NPCs: %d"),
		bHasViewer ? TEXT("Connected") : TEXT("Missing"),
		bHasViewer ? *UEnum::GetValueAsString(Viewer.Mode) : TEXT("Unknown"),
		bHasViewer ? Viewer.OrbitZoom : 0.0f,
		bHasViewer && Viewer.bCrowdEnabled ? TEXT("Enabled") : TEXT("Disabled"),
		Subsystem->GetActiveNPCCount(),
		Subsystem->GetPooledNPCCount());
}
