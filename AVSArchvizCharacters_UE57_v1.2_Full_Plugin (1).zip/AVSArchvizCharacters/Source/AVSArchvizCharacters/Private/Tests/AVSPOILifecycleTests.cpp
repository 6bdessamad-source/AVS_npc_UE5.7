#if WITH_DEV_AUTOMATION_TESTS
#include "AVSPointOfInterest.h"
#include "AVSArchvizNPCCharacter.h"
#include "Engine/World.h"
#include "Misc/AutomationTest.h"
#include "UObject/UnrealType.h"

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FAVSPOIReservationLifecycleTest,
    "AVS.POI.ReservationLifecycle", EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FAVSPOIReservationLifecycleTest::RunTest(const FString& Parameters)
{
    UWorld* World = UWorld::CreateWorld(EWorldType::Game, false);
    if (!TestNotNull(TEXT("Transient test world"), World)) return false;
    World->InitializeNewWorld(UWorld::InitializationValues()
        .AllowAudioPlayback(false).CreatePhysicsScene(false).CreateNavigation(false).CreateAISystem(false));
    AAVSPointOfInterest* POI = World->SpawnActor<AAVSPointOfInterest>();
    AActor* First = World->SpawnActor<AActor>();
    AActor* Second = World->SpawnActor<AActor>();
    AAVSArchvizNPCCharacter* PooledNPC = World->SpawnActor<AAVSArchvizNPCCharacter>();
    if (!POI || !First || !Second || !PooledNPC)
    {
        AddError(TEXT("Failed to spawn actors for the POI lifecycle test."));
        World->DestroyWorld(false);
        return false;
    }
    POI->bAutoTriggerNearbyNPCs = false;
    POI->Capacity = 1;
    TestFalse(TEXT("Null reservation rejected"), POI->Reserve(nullptr));
    TestTrue(TEXT("First actor reserves"), POI->Reserve(First));
    TestTrue(TEXT("Repeated reservation is idempotent"), POI->Reserve(First));
    TestFalse(TEXT("Capacity is respected"), POI->Reserve(Second));
    TestTrue(TEXT("Full POI can queue"), POI->JoinQueue(Second));
    TestTrue(TEXT("Repeated queue insertion is idempotent"), POI->JoinQueue(Second));
    TestEqual(TEXT("One queued user"), POI->GetQueueIndex(Second), 0);
    POI->Release(First);
    TestTrue(TEXT("Release restores capacity"), POI->HasCapacity());
    TestTrue(TEXT("Queued user can reserve"), POI->Reserve(Second));
    TestEqual(TEXT("Reservation removes queue membership"), POI->GetQueueIndex(Second), INDEX_NONE);
    Second->Destroy();
    const FArrayProperty* Reservations = FindFProperty<FArrayProperty>(POI->GetClass(), TEXT("ReservedUsers"));
    if (TestNotNull(TEXT("Reflected reservation collection"), Reservations))
    {
        FScriptArrayHelper Users(Reservations, Reservations->ContainerPtrToValuePtr<void>(POI));
        TestEqual(TEXT("Destroyed user callback immediately removes reservation"), Users.Num(), 0);
    }
    TestTrue(TEXT("Pooled NPC reserves while visible"), POI->Reserve(PooledNPC));
    PooledNPC->SetActorHiddenInGame(true);
    TestTrue(TEXT("Hidden pool entry does not occupy capacity"), POI->HasCapacity());
    TestFalse(TEXT("Hidden pool entry cannot reserve"), POI->Reserve(PooledNPC));
    PooledNPC->SetActorHiddenInGame(false);
    TestTrue(TEXT("Reactivated pool entry can reserve"), POI->Reserve(PooledNPC));
    POI->Release(PooledNPC);
    TestTrue(TEXT("Pooled release restores capacity"), POI->HasCapacity());
    POI->JoinQueue(First);
    POI->Release(First);
    TestEqual(TEXT("Release also clears stale queue membership"), POI->GetQueueIndex(First), INDEX_NONE);
    World->DestroyWorld(false);
    return true;
}
#endif
