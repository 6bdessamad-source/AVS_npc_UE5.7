#include "AVSComposedAnimationPolicy.h"
#if WITH_DEV_AUTOMATION_TESTS
#include "Misc/AutomationTest.h"
IMPLEMENT_SIMPLE_AUTOMATION_TEST(FAVSComposedAnimationPolicyTest,
    "AVS.Animation.ComposedPolicy", EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FAVSComposedAnimationPolicyTest::RunTest(const FString& Parameters)
{
    using namespace AVS::Composed;
    Options O; O.HoldPosition = .6; O.Rate = 2;
    const Plan P = Resolve({2,0,0}, O);
    TestTrue(TEXT("Start-only hold resolves"), P.Valid && P.Hold);
    Playback S; S.Begin(P); S.Advance(.3);
    const double Position = S.GetPosition(); S.RequestExit();
    TestTrue(TEXT("Cancellation keeps traversed pose"), std::abs(S.GetPosition()-Position) < 1e-8);
    TestFalse(TEXT("Exit blocks movement"), S.CanMove());
    S.Advance(5);
    TestTrue(TEXT("Exit completes before movement"), S.CanMove());
    S.Reset(); TestTrue(TEXT("Pooled policy can reactivate"), S.Begin(P));
    return true;
}
#endif
