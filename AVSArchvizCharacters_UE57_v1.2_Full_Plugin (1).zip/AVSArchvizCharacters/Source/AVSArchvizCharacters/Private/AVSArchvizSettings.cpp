#include "AVSArchvizSettings.h"

UAVSArchvizSettings::UAVSArchvizSettings()
{
	if (QualityTiers.IsEmpty())
	{
		FAVSQualityTier Near;
		Near.MaxDistance = 4000.0f;
		Near.TickInterval = 0.05f;
		QualityTiers.Add(Near);

		FAVSQualityTier Medium;
		Medium.MaxDistance = 9000.0f;
		Medium.TickInterval = 0.25f;
		Medium.bCastShadows = false;
		Medium.bOnlyTickPoseWhenRendered = true;
		Medium.ForcedLOD = 2;
		QualityTiers.Add(Medium);

		FAVSQualityTier Far;
		Far.MaxDistance = 16000.0f;
		Far.TickInterval = 0.75f;
		Far.bEnableMovement = false;
		Far.bCastShadows = false;
		Far.bEnableCollision = false;
		Far.bEnableAvoidance = false;
		Far.bOnlyTickPoseWhenRendered = true;
		Far.ForcedLOD = 3;
		Far.MaxDrawDistance = 16000.0f;
		QualityTiers.Add(Far);
	}
}
