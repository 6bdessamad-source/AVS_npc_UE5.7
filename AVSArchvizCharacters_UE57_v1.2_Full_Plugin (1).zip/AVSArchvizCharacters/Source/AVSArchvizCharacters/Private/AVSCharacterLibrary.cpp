#include "AVSCharacterLibrary.h"

#include "AVSAnimationProfile.h"
#include "AVSArchvizCharacters.h"
#include "AVSCharacterProfile.h"
#include "Animation/Skeleton.h"
#include "Engine/SkeletalMesh.h"

bool UAVSCharacterLibrary::SelectRandom(FRandomStream& Stream, UAVSCharacterProfile*& OutCharacter, UAVSAnimationProfile*& OutAnimation) const
{
	OutCharacter = nullptr;
	OutAnimation = nullptr;
	float TotalWeight = 0.0f;
	for (const FAVSCharacterLibraryEntry& Entry : Characters)
	{
		if (Entry.bEnabled && Entry.CharacterProfile && Entry.AnimationProfile &&
			Entry.AnimationProfile->IsCompatibleWithCharacter(Entry.CharacterProfile) && Entry.Weight > 0.0f)
		{
			TotalWeight += Entry.Weight;
		}
	}
	if (TotalWeight <= 0.0f)
	{
		return false;
	}
	float Choice = Stream.FRandRange(0.0f, TotalWeight);
	for (const FAVSCharacterLibraryEntry& Entry : Characters)
	{
		if (!Entry.bEnabled || !Entry.CharacterProfile || !Entry.AnimationProfile ||
			!Entry.AnimationProfile->IsCompatibleWithCharacter(Entry.CharacterProfile) || Entry.Weight <= 0.0f)
		{
			continue;
		}
		Choice -= Entry.Weight;
		if (Choice <= 0.0f)
		{
			OutCharacter = Entry.CharacterProfile;
			OutAnimation = Entry.AnimationProfile;
			return true;
		}
	}
	return false;
}

bool UAVSCharacterLibrary::ValidateLibrary(TArray<FText>& OutIssues) const
{
	OutIssues.Reset();
	if (Characters.IsEmpty())
	{
		OutIssues.Add(NSLOCTEXT("AVS", "EmptyCharacterLibrary", "Character Library has no entries."));
		return false;
	}
	for (int32 Index = 0; Index < Characters.Num(); ++Index)
	{
		const FAVSCharacterLibraryEntry& Entry = Characters[Index];
		if (!Entry.bEnabled)
		{
			continue;
		}
		if (!Entry.CharacterProfile)
		{
			OutIssues.Add(FText::FromString(FString::Printf(TEXT("Entry %d has no Character Profile."), Index)));
			continue;
		}
		TArray<FText> CharacterIssues;
		if (!Entry.CharacterProfile->ValidateProfile(CharacterIssues))
		{
			for (const FText& Issue : CharacterIssues)
			{
				OutIssues.Add(FText::FromString(FString::Printf(TEXT("Entry %d: %s"), Index, *Issue.ToString())));
			}
		}
		if (!Entry.AnimationProfile)
		{
			OutIssues.Add(FText::FromString(FString::Printf(TEXT("Entry %d has no Animation Profile."), Index)));
		}
		else if (!Entry.AnimationProfile->IsCompatibleWithCharacter(Entry.CharacterProfile))
		{
			OutIssues.Add(FText::FromString(FString::Printf(TEXT("Entry %d pairs incompatible sex, Rig ID, or Skeleton profiles."), Index)));
		}
		else
		{
			TArray<FText> AnimationIssues;
			if (!Entry.AnimationProfile->ValidateProfile(AnimationIssues))
			{
				for (const FText& Issue : AnimationIssues)
				{
					OutIssues.Add(FText::FromString(FString::Printf(TEXT("Entry %d animation: %s"), Index, *Issue.ToString())));
				}
			}
		}
	}
	return OutIssues.IsEmpty();
}

void UAVSCharacterLibrary::ValidateAndLog() const
{
	TArray<FText> Issues;
	if (ValidateLibrary(Issues))
	{
		UE_LOG(LogAVSArchvizCharacters, Display, TEXT("Character Library '%s' is valid."), *GetName());
		return;
	}
	for (const FText& Issue : Issues)
	{
		UE_LOG(LogAVSArchvizCharacters, Warning, TEXT("Character Library '%s': %s"), *GetName(), *Issue.ToString());
	}
}
