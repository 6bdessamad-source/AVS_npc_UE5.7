# AVS ArchViz Characters — Implementation Status

Target: AVSArchvizCharacters **1.2** (descriptor revision 18), Unreal Engine **5.7**. This build-fix package retains the complete v1.10.0 rework. Runtime/Editor modules remain independent of the game module. Source release; no generated `.uasset` assets.

## Build fixes in v1.2

- Added the full behavior-component header in the crowd generator before calling `SetBehaviorState`; addresses the reported C2027 and its C2039 cascade.
- The guarded controller `MoveTo` constructs a default request result and sets `Code = Failed` explicitly; addresses the reported C2440 and its C4390 cascade. Braces make the rejection branch explicit.
- The public Runtime log declaration is exported with `AVSARCHVIZCHARACTERS_API` and directly includes `Logging/LogMacros.h`. This addresses the unresolved `LogAVSArchvizCharacters` used by the Editor module; the existing single Runtime definition and Editor dependency are retained.
- The supplied UE 5.7 compiler log completed UHT processing but failed native compilation on those two source sites. Later feedback reported the unresolved log symbol at link time. The corrected source has not been rebuilt or linked in Unreal here. The portable regression suites and package checks are recorded in BUILD_AND_TEST_LOG.md.

## Implemented in v1.10

- One engine-independent composed policy/state used by ordinary activities, POI runtime and profile-driven POI preview, with an exact Skeleton adapter. Literal Start-only and End-only activities resolve timed contact holds and partial reverse exits. All clip combinations and fallback controls are covered by production-policy tests.
- Activity entry/body/exit owns movement. Partial cancellation, repeated exits and repeated requests cannot reset the traversal or bypass the movement gate. Different supplied exits wait for entry contact. Hold sampling does not leave global pause flags enabled.
- Locomotion uses compatible main Walk/Run rows, relaxed speed/acceleration/braking and velocity-scaled playback. Montage playback requires an actual configured Animation Blueprint containing the compiled Slot; otherwise single-node fallback works. Root-motion activity slots cannot masquerade as walking.
- POIs use navigation, distance/height tolerance, stopped braking, smooth facing, arrival/alignment/queue timeout, Skeleton-filtered runtime overrides, and reservations retained through get-up. Preview shows the same sequence/settings, with legacy editor-only clips explicitly labeled pose-only.
- Conversation Idle/Talk category selection defaults to 50/50 combined Talk weight, then selects weighted compatible variants. Singleton redraws retain playback, alternatives avoid immediate repetition, and changes/departures finish exit transitions. Spatial/height matching, random 2–4 size, independent departures, cooldown and post-chat idle/wander remain.
- Ambient Idle/Smoking/Stretching/Custom weights are independent of conversation formation, zone initial idle share and movement/route decisions. Project, level controller, box and spline zones provide clear controls; legacy activity arrays and social controller settings remain available.
- Expensive leader/quality work rotates through configured budgets. Navigation has duplicate suppression and failed-query backoff; one camera navigation invoker remains centralized. Runtime ticks do not add whole-scene scans.
- Pool placement/profile replacement happens while hidden. Failure remains hidden and acquisition rejects it. Pool return resets paths/brain logic, activity/montage/hold state, behavior memberships/reservations, pending commands and movement mode. Activation restores body/part ticks and quality defaults before visibility. Quality tiers drain active exits before freezing; they cannot move an animation-disabled character.
- Read-only Tools → AVS → Validate Scene / Profiles reports mandatory clips, exact Skeletons, modular/ABP incompatibility, montage Slot setup, POI usability and navigation configuration. Retarget-generated profiles copy new settings. Existing modular head randomization and retarget authoring remain.

## Verified here

- Portable production composed policy: **102 assertions passed**.
- Portable production probability policy: **36 checks passed**, **200,000** deterministic trials, Idle **100270**, Talk **99730**.
- Both also passed g++ AddressSanitizer/UndefinedBehaviorSanitizer with leak detection disabled; LeakSanitizer unavailable in this managed environment.
- Source/diff/metadata/documentation/include/API-compatibility/archive checks are recorded in BUILD_AND_TEST_LOG.md and do not substitute for an engine build.
- UE automation sources added: `AVS.Animation.ComposedPolicy`, `AVS.POI.ReservationLifecycle`. They were **not compiled/run** here.

## Unresolved UE acceptance gates

Unreal Engine/UnrealBuildTool were not found. **UHT, UE 5.7 native Runtime/Editor compilation, editor preview, PIE, packaging and actual asset playback were not performed.** Compile and execute the [acceptance checklist](Docs/ACCEPTANCE_CHECKLIST.md) in the user's target project. This source release is not production-proven or guaranteed unbreakable.

For practical limits and migration differences, see KNOWN_ISSUES.md and [v1.10 setup](Docs/V1_10_MIGRATION_AND_SETUP.md). The historical user report that v1.0.2 built successfully is not a test of this release.
